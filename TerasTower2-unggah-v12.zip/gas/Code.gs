// ===================================================================
// TERAS TOWER 2 - Backend Apps Script (v12 - NOTIFIKASI PUSH + PEMBERSIHAN AKUN)
// ===================================================================

// SUPER ADMIN CREDENTIALS
// Credentials are configured once with setupSuperAdminCredentials_(username, pin)
// and stored as a salted SHA-256 hash in Script Properties. Never hardcode them here.
const PROP_SUPER_ADMIN_USERNAME = 'SUPER_ADMIN_USERNAME';
const PROP_SUPER_ADMIN_PIN_HASH = 'SUPER_ADMIN_PIN_HASH';
const PROP_SUPER_ADMIN_PIN_SALT = 'SUPER_ADMIN_PIN_SALT';
const PROP_PIN_HASH_PEPPER = 'PIN_HASH_PEPPER';
const SESSION_SCHEMA_VERSION = 'TT2-auth-hardening-v1';
const AUDIT_SHEET = 'AuditLog';

const SHEET_DATA = 'Data Aspirasi';
const SHEET_REFDATA = 'RefData';
const SHEET_ADMINS = 'Admins';
const SHEET_APPINFO = 'AppInfo';
const SHEET_SYSTEMCONFIG = 'SystemConfig';
const SHEET_WARGA = 'WargaBaru';
const SHEET_NOMORPENTING = 'NomorPenting';
const SHEET_NOMORDARURAT = 'NomorDarurat';
const SHEET_KEPUASAN = 'Kepuasan';
const SHEET_RESETREQUESTS = 'ResetPinRequests';
const SHEET_APPFEEDBACK = 'AppFeedback';
const SHEET_JELAJAH = 'JelajahRekomendasi';
const SHEET_JELAJAH_KATEGORI = 'JelajahKategori';
const SHEET_JELAJAH_JENIS = 'JelajahJenis';
const SHEET_JELAJAH_ULASAN = 'JelajahUlasan';
const SHEET_AGENDA = 'AgendaTower2';
const SHEET_AGENDA_PROPOSALS = 'UsulanAgenda';
const FLOOR_MIN_8O = 3;
const FLOOR_MAX_8O = 24;
const UNIT_SUFFIX_MIN_8O = 1;
const UNIT_SUFFIX_MAX_8O = 45;
const KATEGORI_KEPUASAN = ['Pengelola Gedung', 'Pengelola Parkir', 'Pengelola Food Court', 'Paguyuban'];
const BANNER_MAX = 5;
const ASPIRATION_STATUSES_8L = ['Baru', 'Dibaca', 'Diselesaikan', 'Ditolak'];
const ASPIRATION_PRIORITIES_8L = ['Sangat Tinggi', 'Tinggi', 'Rendah'];
const ASPIRATION_LOCATION_TYPES = ['Area umum', 'Lantai', 'Unit', 'Tidak diketahui'];
const BANNER_FOLDER = 'Teras Tower 2 - Banners';
const BANNER_CONFIG_KEY = 'BannerList';
const DRIVE_FOLDER_PROPERTY_BY_NAME = {
  'Teras Tower 2 - Bukti Pengaduan': 'FOLDER_EVIDENCE_ID',
  'Teras Tower 2 - Foto Tindak Lanjut': 'FOLDER_FOLLOWUP_ID',
  'Teras Tower 2 - Banners': 'FOLDER_BANNER_ID',
  'Teras Tower 2 - Background Images': 'FOLDER_BACKGROUND_ID'
};

// ===================================================================
// SECURITY HELPERS
// ===================================================================
function legacyHashPin_(pin, salt) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(pin) + String(salt),
    Utilities.Charset.UTF_8
  );
  return bytes.map(function (b) {
    const v = b < 0 ? b + 256 : b;
    return ('0' + v.toString(16)).slice(-2);
  }).join('');
}

function getPinHashPepper_() {
  const props = PropertiesService.getScriptProperties();
  let pepper = props.getProperty(PROP_PIN_HASH_PEPPER);
  if (pepper) return pepper;
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    pepper = props.getProperty(PROP_PIN_HASH_PEPPER);
    if (!pepper) {
      pepper = Utilities.getUuid() + Utilities.getUuid();
      props.setProperty(PROP_PIN_HASH_PEPPER, pepper);
    }
    return pepper;
  } finally { lock.releaseLock(); }
}

function hashPin_(pin, salt) {
  const bytes = Utilities.computeHmacSha256Signature(
    String(pin) + '$' + String(salt), getPinHashPepper_(), Utilities.Charset.UTF_8
  );
  return bytes.map(function (b) {
    const v = b < 0 ? b + 256 : b;
    return ('0' + v.toString(16)).slice(-2);
  }).join('');
}

const PIN_HASH_PREFIX = 'hmac256$';
const LEGACY_PIN_HASH_PREFIX = 'sha256$';
const LOGIN_MAX_FAILURES = 5;
const LOGIN_LOCK_SECONDS = 600;
function makePinHash_(pin) { const salt = Utilities.getUuid(); return PIN_HASH_PREFIX + salt + '$' + hashPin_(pin, salt); }
function verifyStoredPin_(pin, stored) {
  const value = String(stored == null ? '' : stored);
  if (value.indexOf(PIN_HASH_PREFIX) === 0) {
    const parts = value.split('$');
    return parts.length === 3 && hashPin_(pin, parts[1]) === parts[2];
  }
  if (value.indexOf(LEGACY_PIN_HASH_PREFIX) === 0) {
    const parts = value.split('$');
    return parts.length === 3 && legacyHashPin_(pin, parts[1]) === parts[2];
  }
  return value === String(pin);
}
function makeNumericPin_() {
  // Ambil 20 bit dari UUID dan tolak nilai di luar rentang 000000-999999
  // agar distribusi enam digit tidak bias oleh operasi modulo sederhana.
  for (let attempt = 0; attempt < 10; attempt++) {
    const hex = Utilities.getUuid().replace(/-/g, '').substring(0, 5);
    const value = parseInt(hex, 16);
    if (value < 1000000) return ('000000' + value).slice(-6);
  }
  throw new Error('Generator PIN tidak dapat menghasilkan nilai aman.');
}
function upgradePlainPin_(sheetName, username, pin) { const sheet = getSheet_(sheetName); if (!sheet) return; const values = sheet.getDataRange().getValues(); const headers = values[0]; const uc = headers.indexOf('Username'); const pc = headers.indexOf('PIN'); if (uc < 0 || pc < 0) return; for (let i=1;i<values.length;i++) if (String(values[i][uc]||'').toLowerCase() === String(username).toLowerCase() && String(values[i][pc]||'').indexOf(PIN_HASH_PREFIX)!==0) { sheet.getRange(i+1,pc+1).setValue(makePinHash_(pin)); return; } }
function setPinForAccount_(sheetName, username, pin) { const sheet=getSheet_(sheetName); if(!sheet)return false; const values=sheet.getDataRange().getValues(); const headers=values[0]; const uc=headers.indexOf('Username'); const pc=headers.indexOf('PIN'); if(uc<0||pc<0)return false; for(let i=1;i<values.length;i++) if(String(values[i][uc]||'').toLowerCase()===String(username).toLowerCase()){sheet.getRange(i+1,pc+1).setValue(makePinHash_(pin));bumpSessionVersion_(username);return true;} return false; }
function loginRateKey_(username) { return 'login-fail:' + String(username || '').toLowerCase(); }
function isLoginRateLimited_(username) { return Number(CacheService.getScriptCache().get(loginRateKey_(username)) || 0) >= LOGIN_MAX_FAILURES; }
function recordLoginFailure_(username) { const cache=CacheService.getScriptCache(); const key=loginRateKey_(username); cache.put(key,String(Number(cache.get(key)||0)+1),LOGIN_LOCK_SECONDS); }
function clearLoginFailures_(username) { CacheService.getScriptCache().remove(loginRateKey_(username)); }

function setupSuperAdminCredentials_(username, pin) {
  username = String(username || '').trim();
  pin = String(pin || '').trim();
  if (!username || pin.length !== 6 || !/^\d{6}$/.test(pin)) {
    throw new Error('Username dan PIN 6 digit wajib diisi.');
  }
  const encodedPin = makePinHash_(pin);
  const props = PropertiesService.getScriptProperties();
  const previousUsername = props.getProperty(PROP_SUPER_ADMIN_USERNAME) || '';
  props.setProperties({
    [PROP_SUPER_ADMIN_USERNAME]: username,
    [PROP_SUPER_ADMIN_PIN_HASH]: encodedPin,
    [PROP_SUPER_ADMIN_PIN_SALT]: ''
  }, true);
  if (previousUsername) bumpSessionVersion_(previousUsername);
  bumpSessionVersion_(username);
  return 'Credential Super Admin tersimpan memakai HMAC-SHA-256 bergaram. Hapus atau nonaktifkan fungsi setup setelah konfigurasi.';
}

function getSuperAdminConfig_() {
  const props = PropertiesService.getScriptProperties();
  return {
    username: props.getProperty(PROP_SUPER_ADMIN_USERNAME) || '',
    pinHash: props.getProperty(PROP_SUPER_ADMIN_PIN_HASH) || '',
    pinSalt: props.getProperty(PROP_SUPER_ADMIN_PIN_SALT) || ''
  };
}

function verifySuperAdmin_(username, pin) {
  const config = getSuperAdminConfig_();
  if (!config.username || !config.pinHash || String(username).toLowerCase() !== config.username.toLowerCase()) return false;
  if (config.pinHash.indexOf(PIN_HASH_PREFIX) === 0) return verifyStoredPin_(pin, config.pinHash);
  // Compatibility with the prior Script Properties format (plain SHA-256 + separate salt).
  return !!config.pinSalt && legacyHashPin_(pin, config.pinSalt) === config.pinHash;
}

function sessionVersionKey_(username) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(username || '').toLowerCase(), Utilities.Charset.UTF_8);
  const digest = bytes.map(function (b) { const v = b < 0 ? b + 256 : b; return ('0' + v.toString(16)).slice(-2); }).join('');
  return 'SESSION_VERSION_' + digest;
}
function getSessionVersion_(username) {
  return Number(PropertiesService.getScriptProperties().getProperty(sessionVersionKey_(username)) || 0);
}
function bumpSessionVersion_(username) {
  if (!username) return;
  const key = sessionVersionKey_(username);
  const props = PropertiesService.getScriptProperties();
  props.setProperty(key, String(Number(props.getProperty(key) || 0) + 1));
}

// ===================================================================
// SESI PERSISTEN (v11 — persiapan aplikasi Android/iOS)
// -------------------------------------------------------------------
// Sebelumnya sesi hanya ada di CacheService (maks. 6 jam), sehingga
// "Ingat saya" tetap meminta login ulang. Sekarang:
//   • Tanpa "Ingat saya": sesi hanya di cache, berlaku 6 jam (sama seperti dulu).
//   • Dengan "Ingat saya": sesi juga dicatat di sheet SesiAplikasi dan berlaku
//     30 hari sejak terakhir dipakai (diperpanjang otomatis, paling sering 1x/hari).
//   • Sheet hanya menyimpan HASH SHA-256 dari token, bukan tokennya. Orang yang
//     bisa membuka spreadsheet tidak bisa memakai isi sheet untuk masuk.
//   • Pencabutan sesi lama tetap memakai authVersion (bumpSessionVersion_):
//     reset PIN / cabut admin langsung membatalkan semua sesi akun tersebut.
// ===================================================================
const SHEET_SESSIONS = 'SesiAplikasi';
const SESSION_HEADERS = ['TokenHash', 'Username', 'Role', 'AuthVersion', 'SchemaVersion', 'CreatedAt', 'ExpiresAt', 'LastSeenAt'];
const SESSION_CACHE_SECONDS = 21600;                    // batas maksimum CacheService (6 jam)
const SESSION_SHORT_MS = SESSION_CACHE_SECONDS * 1000;  // sesi tanpa "Ingat saya"
const SESSION_LONG_MS = 30 * 24 * 60 * 60 * 1000;       // sesi "Ingat saya": 30 hari
const SESSION_TOUCH_MS = 24 * 60 * 60 * 1000;           // perpanjang masa berlaku paling sering 1x/hari

function sessionTokenHash_(token) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'tt2-session:' + String(token || ''), Utilities.Charset.UTF_8);
  return bytes.map(function (b) { const v = b < 0 ? b + 256 : b; return ('0' + v.toString(16)).slice(-2); }).join('');
}

function getSessionSheet_(createIfMissing) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_SESSIONS);
  if (!sheet && createIfMissing) {
    sheet = ss.insertSheet(SHEET_SESSIONS);
    sheet.getRange(1, 1, 1, SESSION_HEADERS.length).setValues([SESSION_HEADERS]);
    sheet.setFrozenRows(1);
    try { sheet.hideSheet(); } catch (ignore) {}
  }
  return sheet;
}

// Mencari baris sesi berdasarkan hash token. Mengembalikan { rowNumber, values } atau null.
function findPersistentSessionRow_(sheet, tokenHash) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  const cell = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).createTextFinder(tokenHash).matchEntireCell(true).findNext();
  if (!cell) return null;
  const rowNumber = cell.getRow();
  return { rowNumber: rowNumber, values: sheet.getRange(rowNumber, 1, 1, SESSION_HEADERS.length).getValues()[0] };
}

// Menghapus sesi persisten yang sudah lewat masa berlakunya. Dipanggil sesekali saat login.
function pruneExpiredSessions_(sheet) {
  if (!sheet || sheet.getLastRow() < 2) return;
  const now = Date.now();
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, SESSION_HEADERS.length).getValues();
  for (let i = values.length - 1; i >= 0; i--) {
    const expires = new Date(values[i][6]).getTime();
    if (!expires || expires < now) sheet.deleteRow(i + 2);
  }
}

function createSessionUser_(user, remember) {
  const token = Utilities.getUuid() + Utilities.getUuid();
  const now = Date.now();
  const persistent = remember === true;
  const session = {
    username: user.username,
    role: user.isSuperAdmin_ ? 'super_admin' : (user.isAdmin ? 'admin' : 'resident'),
    authVersion: getSessionVersion_(user.username),
    schemaVersion: SESSION_SCHEMA_VERSION,
    createdAt: new Date(now).toISOString(),
    expiresAt: now + (persistent ? SESSION_LONG_MS : SESSION_SHORT_MS),
    persistent: persistent
  };
  CacheService.getScriptCache().put('session:' + token, JSON.stringify(session), SESSION_CACHE_SECONDS);
  if (persistent) {
    try {
      withScriptLock_(function () {
        const sheet = getSessionSheet_(true);
        sheet.appendRow([sessionTokenHash_(token), sheetText_(session.username), session.role, session.authVersion,
          session.schemaVersion, new Date(now), new Date(session.expiresAt), new Date(now)]);
        if (Math.random() < 0.1) pruneExpiredSessions_(sheet);
      });
    } catch (err) {
      // Sesi tetap berlaku 6 jam lewat cache walaupun pencatatan sheet gagal.
      writeApplicationError_('createSessionUser_', err, session.username);
      session.persistent = false;
      session.expiresAt = now + SESSION_SHORT_MS;
      CacheService.getScriptCache().put('session:' + token, JSON.stringify(session), SESSION_CACHE_SECONDS);
    }
  }
  user.sessionToken = token;
  user.sessionExpiresAt = session.expiresAt;
  user.sessionPersistent = session.persistent;
  // Public flags are kept for the frontend; the server-side role remains authoritative.
  user.isAdmin = session.role === 'admin' || session.role === 'super_admin';
  user.isSuperAdmin = session.role === 'super_admin';
  return user;
}

// Dipanggil saat sesi tidak ada di cache: cari di sheet, perpanjang bila perlu,
// lalu simpan lagi ke cache supaya permintaan berikutnya tidak membaca sheet.
function loadPersistentSession_(token) {
  const sheet = getSessionSheet_(false);
  if (!sheet) return null;
  const tokenHash = sessionTokenHash_(token);
  const found = findPersistentSessionRow_(sheet, tokenHash);
  if (!found) return null;
  const row = found.values;
  const now = Date.now();
  let expiresAt = new Date(row[6]).getTime();
  const lastSeen = new Date(row[7]).getTime() || 0;
  // Jangan memakai withScriptLock_ di sini: requireSession_ bisa dipanggil dari
  // dalam callback yang sudah memegang kunci, dan kunci Apps Script tidak bersarang.
  // Baris kedaluwarsa dibersihkan oleh pruneExpiredSessions_ saat login berikutnya.
  if (!expiresAt || expiresAt < now) return null;
  if (now - lastSeen > SESSION_TOUCH_MS) {
    expiresAt = now + SESSION_LONG_MS;
    try { sheet.getRange(found.rowNumber, 7, 1, 2).setValues([[new Date(expiresAt), new Date(now)]]); } catch (ignore) {}
  }
  const session = {
    username: String(row[1] || ''),
    role: String(row[2] || ''),
    authVersion: Number(row[3] || 0),
    schemaVersion: String(row[4] || ''),
    createdAt: new Date(row[5]).toISOString(),
    expiresAt: expiresAt,
    persistent: true
  };
  const ttl = Math.max(60, Math.min(SESSION_CACHE_SECONDS, Math.floor((expiresAt - now) / 1000)));
  CacheService.getScriptCache().put('session:' + String(token), JSON.stringify(session), ttl);
  return session;
}

function requireSession_(token, roles) {
  if (!token) throw new Error('Sesi tidak ditemukan. Silakan login kembali.');
  const raw = CacheService.getScriptCache().get('session:' + String(token));
  let session = raw ? JSON.parse(raw) : loadPersistentSession_(token);
  if (session && session.expiresAt && Number(session.expiresAt) < Date.now()) session = null;
  if (!session) throw new Error('Sesi kedaluwarsa. Silakan login kembali.');
  if (session.schemaVersion !== SESSION_SCHEMA_VERSION) throw new Error('Sesi lama tidak lagi berlaku. Silakan login kembali.');
  if (Number(session.authVersion || 0) !== getSessionVersion_(session.username)) throw new Error('Sesi telah dicabut. Silakan login kembali.');
  if (session.role === 'admin' && !isAdminUsername_(session.username)) throw new Error('Hak Admin sudah dicabut. Silakan login kembali.');
  if (roles && roles.indexOf(session.role) < 0) throw new Error('Anda tidak memiliki akses.');
  return session;
}

function logoutSession(token) {
  if (!token) return { success: true };
  CacheService.getScriptCache().remove('session:' + String(token));
  try {
    const sheet = getSessionSheet_(false);
    if (sheet) withScriptLock_(function () {
      const found = findPersistentSessionRow_(sheet, sessionTokenHash_(token));
      if (found) sheet.deleteRow(found.rowNumber);
    });
  } catch (err) { writeApplicationError_('logoutSession', err, ''); }
  return { success: true };
}

function validateSession(token) {
  try {
    const session = requireSession_(token, ['resident', 'admin', 'super_admin']);
    return { valid: true, username: session.username, role: session.role };
  } catch (err) {
    return { valid: false };
  }
}

function validateString_(value, name, min, max) {
  const text = String(value == null ? '' : value).trim();
  if (text.length < min || text.length > max) throw new Error(name + ' harus ' + min + '-' + max + ' karakter.');
  return text;
}

// WhatsApp is stored as a phone number, not hashed. Accept common Indonesian
// entry formats and return canonical digits for validation/storage.
function normalizeWhatsAppNumber_(value) {
  const raw = String(value == null ? '' : value).trim();
  if (!raw || /[•●*xX]/.test(raw) || !/^\+?[0-9\s().-]+$/.test(raw)) return '';
  let digits = raw.replace(/\D/g, '');
  if (digits.indexOf('00') === 0) digits = digits.substring(2);
  if (digits.indexOf('0') === 0) digits = '62' + digits.substring(1);
  else if (digits.indexOf('62') !== 0 && digits.indexOf('8') === 0) digits = '62' + digits;
  return /^62[0-9]{8,11}$/.test(digits) ? digits : '';
}

// Prefix apostrophe for strings that Google Sheets could parse as formulas.
// The apostrophe is a text marker in Sheets and prevents execution of formulas
// submitted through forms while preserving the displayed text.
function sheetText_(value) {
  const text = String(value == null ? '' : value);
  return /^[\u0000-\u0020]*[=+\-@]/.test(text) ? "'" + text : text;
}

function floorOptions8O_() {
  const values = [];
  for (let i = FLOOR_MIN_8O; i <= FLOOR_MAX_8O; i++) values.push(('0' + i).slice(-2));
  return values;
}
function unitSuffixOptions8O_() {
  const values = [];
  for (let i = UNIT_SUFFIX_MIN_8O; i <= UNIT_SUFFIX_MAX_8O; i++) values.push(('0' + i).slice(-2));
  return values;
}
function normalizeFloorUnit8O_(floorValue, unitValue, statusWisma) {
  const rawFloor = String(floorValue == null ? '' : floorValue).trim();
  const rawUnit = String(unitValue == null ? '' : unitValue).trim();
  if (!rawFloor && !rawUnit) {
    if (statusWisma === 'Penghuni BAST') return { ok: false, reason: 'Lantai dan unit kosong untuk Penghuni BAST.' };
    return { ok: true, floor: '', suffix: '', unit: '', inferred: false };
  }
  let floor = rawFloor.replace(/^0+/, '') ? parseInt(rawFloor, 10) : 0;
  let floorText = '';
  if (floor >= FLOOR_MIN_8O && floor <= FLOOR_MAX_8O && /^\d{1,2}$/.test(rawFloor)) floorText = ('0' + floor).slice(-2);
  if (rawFloor && !floorText) return { ok: false, reason: 'Lantai harus 03–24.' };
  const unitDigits = rawUnit.replace(/[-/\s]/g, '');
  if (!/^\d{1,4}$/.test(unitDigits)) return { ok: false, reason: 'Format unit bukan angka 1–4 digit.' };
  let suffixText = '';
  let inferred = false;
  if (unitDigits.length === 4) {
    const unitFloor = unitDigits.substring(0, 2);
    const unitSuffix = parseInt(unitDigits.substring(2), 10);
    if (unitSuffix < UNIT_SUFFIX_MIN_8O || unitSuffix > UNIT_SUFFIX_MAX_8O) return { ok: false, reason: 'Nomor unit harus berakhiran 01–45.' };
    if (!floorText) { floorText = unitFloor; inferred = true; }
    if (unitFloor !== floorText) return { ok: false, reason: 'Awalan unit tidak sama dengan nomor lantai.' };
    suffixText = ('0' + unitSuffix).slice(-2);
  } else if (unitDigits.length === 3) {
    const unitFloor = ('0' + unitDigits.substring(0, 1)).slice(-2);
    const unitSuffix = parseInt(unitDigits.substring(1), 10);
    if (unitSuffix < UNIT_SUFFIX_MIN_8O || unitSuffix > UNIT_SUFFIX_MAX_8O) return { ok: false, reason: 'Nomor unit harus berakhiran 01–45.' };
    if (!floorText) { floorText = unitFloor; inferred = true; }
    if (unitFloor !== floorText) return { ok: false, reason: 'Awalan unit tidak sama dengan nomor lantai.' };
    suffixText = ('0' + unitSuffix).slice(-2);
  } else {
    if (!floorText) return { ok: false, reason: 'Lantai wajib diisi untuk unit dua digit.' };
    const suffix = parseInt(unitDigits, 10);
    if (suffix < UNIT_SUFFIX_MIN_8O || suffix > UNIT_SUFFIX_MAX_8O) return { ok: false, reason: 'Nomor unit harus 01–45.' };
    suffixText = ('0' + suffix).slice(-2);
  }
  const floorNumber = parseInt(floorText, 10);
  if (floorNumber < FLOOR_MIN_8O || floorNumber > FLOOR_MAX_8O) return { ok: false, reason: 'Lantai harus 03–24.' };
  return { ok: true, floor: floorText, suffix: suffixText, unit: floorText + suffixText, inferred: inferred || rawUnit.length !== 4 || rawUnit !== floorText + suffixText };
}
function validateFloorUnit8O_(statusWisma, floorValue, unitValue) {
  const floor = String(floorValue == null ? '' : floorValue).trim();
  const unit = String(unitValue == null ? '' : unitValue).trim();
  if (statusWisma !== 'Penghuni BAST' && (floor || unit)) throw new Error('Lantai dan unit hanya diisi untuk Penghuni BAST.');
  const normalized = normalizeFloorUnit8O_(floor, unit, statusWisma);
  if (!normalized.ok) throw new Error(normalized.reason);
  return normalized;
}
function getFloorUnitAnomaly8O_(row) {
  if (!String(row.Status_Wisma || '').trim()) return { normalized: { ok: false }, reason: 'Status di Wisma kosong.' };
  const normalized = normalizeFloorUnit8O_(row.Lantai, row.Unit, row.Status_Wisma);
  if (!normalized.ok) return { normalized: normalized, reason: normalized.reason };
  return { normalized: normalized, reason: '' };
}
function getWargaFloorUnitAnomalies_() {
  return getSheetData_(SHEET_WARGA).map(function (row) {
    const anomaly = getFloorUnitAnomaly8O_(row);
    return anomaly.reason ? { username: String(row.Username || ''), nama: String(row.Nama || ''), reason: anomaly.reason } : null;
  }).filter(Boolean);
}

function validateImageSignature_(fileObj) {
  const mime = String(fileObj.mimeType || '').toLowerCase();
  const bytes = Utilities.base64Decode(String(fileObj.base64 || '').replace(/^data:[^,]+,/, ''));
  const startsWith = function (sig) {
    return sig.every(function (value, index) { return (bytes[index] & 0xFF) === value; });
  };
  let valid = false;
  if (mime === 'image/jpeg') valid = startsWith([0xFF, 0xD8, 0xFF]);
  else if (mime === 'image/png') valid = startsWith([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  else if (mime === 'image/webp') {
    valid = startsWith([0x52, 0x49, 0x46, 0x46]) &&
      (bytes[8] & 0xFF) === 0x57 && (bytes[9] & 0xFF) === 0x45 && (bytes[10] & 0xFF) === 0x42 && (bytes[11] & 0xFF) === 0x50;
  }
  if (!valid) throw new Error('Isi file tidak cocok dengan tipe gambar yang diklaim.');
}

function validateFilePayload_(fileObj, required) {
  if (!fileObj) {
    if (required) throw new Error('File bukti wajib diisi.');
    return;
  }
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (allowed.indexOf(String(fileObj.mimeType || '').toLowerCase()) < 0) throw new Error('Bukti harus berupa JPG, PNG, atau WebP.');
  if (!fileObj.base64 || String(fileObj.base64).length > 7 * 1024 * 1024) throw new Error('Ukuran bukti terlalu besar atau tidak valid. Maksimal sekitar 5 MB.');
  validateString_(fileObj.fileName, 'Nama file', 1, 120);
  validateImageSignature_(fileObj);
}

// v12: notifikasi yang diantrekan di dalam kunci (queuePush_) dikirim SETELAH
// kunci dilepas, supaya permintaan HTTP ke Firebase tidak menahan warga lain.
let SCRIPT_LOCK_DEPTH_ = 0;
function withScriptLock_(callback) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  SCRIPT_LOCK_DEPTH_++;
  try { return callback(); } finally {
    SCRIPT_LOCK_DEPTH_--;
    lock.releaseLock();
    if (SCRIPT_LOCK_DEPTH_ === 0) flushPushQueue_();
  }
}

function writeAuditLog_(action, actor, target, detail) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(AUDIT_SHEET);
    if (!sheet) {
      sheet = ss.insertSheet(AUDIT_SHEET);
      sheet.appendRow(['Timestamp', 'Action', 'Actor', 'Target', 'Detail']);
    }
    sheet.appendRow([new Date(), sheetText_(action), sheetText_(actor), sheetText_(target), sheetText_(String(detail || '').substring(0, 2000))]);
  } catch (err) {
    console.error('Audit log gagal: ' + err.message);
  }
}

function getManagementLog(sessionToken, category) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  if (session.role === 'admin' && !isAdminUsername_(session.username)) return { authorized: false, data: [] };
  const categories = {
    warga: ['UPDATE_WARGA', 'DELETE_WARGA', 'ACTIVATE_ADMIN', 'DEACTIVATE_ADMIN'],
    pin: ['RESET_PIN', 'REQUEST_RESET_PIN', 'PROCESS_RESET_PIN'],
    aspirasi: ['SUBMIT_ASPIRASI', 'UPDATE_TINDAK_LANJUT'],
    kepuasan: ['UPDATE_KEPUASAN'],
    agenda: ['SUBMIT_AGENDA_PROPOSAL', 'APPROVE_AGENDA_PROPOSAL', 'REJECT_AGENDA_PROPOSAL', 'CREATE_TOWER_AGENDA', 'UPDATE_TOWER_AGENDA', 'ARCHIVE_TOWER_AGENDA', 'RESTORE_TOWER_AGENDA'],
    nomorPenting: ['UPDATE_NOMOR_PENTING'],
    nomorDarurat: ['UPDATE_NOMOR_DARURAT'],
    admin: ['ADD_ADMIN', 'REMOVE_ADMIN'],
    aplikasi: ['UPDATE_THEME', 'UPDATE_BANNERS', 'UPDATE_APP_FEEDBACK'],
    logSystem: ['LOGIN_FAILED', 'MARK_ERROR_LOG_SEEN']
  };
  const allowed = categories[category] || Object.keys(categories).reduce(function (all, key) { return all.concat(categories[key]); }, []);
  const sheet = getSheet_(AUDIT_SHEET);
  if (!sheet || sheet.getLastRow() < 2) return { authorized: true, data: [] };
  const rows = getSheetData_(AUDIT_SHEET).filter(function (row) {
    const actorMatch = session.role === 'super_admin' || String(row.Actor || '').toLowerCase() === String(session.username || '').toLowerCase();
    return actorMatch && allowed.indexOf(String(row.Action || '')) >= 0;
  }).map(function (row) {
    return { timestamp: formatTanggal_(row.Timestamp), action: row.Action || '', actor: row.Actor || '', target: row.Target || '', detail: row.Detail || '' };
  });
  rows.reverse();
  return { authorized: true, data: rows.slice(0, 300) };
}

function writeApplicationError_(area, err, actor) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName('ErrorLog');
    pruneErrorLog_(sheet);
    if (!sheet) {
      sheet = ss.insertSheet('ErrorLog');
      sheet.appendRow(['Timestamp', 'Area', 'Actor', 'Message']);
    }
    const raw = err && err.message ? err.message : String(err || 'Unknown error');
    const message = raw.replace(/sessionToken[^,\s]*/gi, 'sessionToken=[redacted]').replace(/pin\s*[:=]\s*\d+/gi, 'PIN=[redacted]').substring(0, 500);
    sheet.appendRow([new Date(), String(area || 'unknown'), String(actor || '').substring(0, 100), message]);
  } catch (logErr) {
    console.error('Error log gagal: ' + logErr.message);
  }
}
const ERROR_LOG_RETENTION_DAYS = 60;
function pruneErrorLog_(sheet) {
  if (!sheet || sheet.getLastRow() < 2) return;
  const cutoff = new Date().getTime() - ERROR_LOG_RETENTION_DAYS * 86400000;
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, Math.max(4, sheet.getLastColumn())).getValues();
  for (let i = values.length - 1; i >= 0; i--) {
    const stamp = notificationDate_(values[i][0]);
    if (stamp > 0 && stamp < cutoff) sheet.deleteRow(i + 2);
  }
}
function getErrorLogSummary(sessionToken, periodDays) {
  const session = requireSession_(sessionToken, ['super_admin']);
  const sheet = getSheet_('ErrorLog');
  if (!sheet) return { total: 0, last24: 0, last7: 0, last30: 0, unread: 0, rows: [], retentionDays: ERROR_LOG_RETENTION_DAYS };
  pruneErrorLog_(sheet);
  const rows = getSheetData_('ErrorLog');
  const now = new Date().getTime();
  const lastSeen = getNotificationLastSeen_(session.username, 'errorLog');
  const days = Math.max(1, Math.min(Number(periodDays) || 30, ERROR_LOG_RETENTION_DAYS));
  const filtered = rows.filter(function (row) { return now - notificationDate_(row.Timestamp) <= days * 86400000; });
  return {
    total: filtered.length,
    last24: rows.filter(function (row) { return now - notificationDate_(row.Timestamp) <= 86400000; }).length,
    last7: rows.filter(function (row) { return now - notificationDate_(row.Timestamp) <= 7 * 86400000; }).length,
    last30: rows.filter(function (row) { return now - notificationDate_(row.Timestamp) <= 30 * 86400000; }).length,
    unread: lastSeen === null ? 0 : rows.filter(function (row) { return notificationDate_(row.Timestamp) > lastSeen; }).length,
    retentionDays: ERROR_LOG_RETENTION_DAYS,
    rows: filtered.slice(-100).reverse().map(function (row) {
      return { timestamp: formatTanggal_(row.Timestamp), area: String(row.Area || ''), actor: String(row.Actor || ''), message: String(row.Message || '').substring(0, 500) };
    })
  };
}
function markErrorLogSeen(sessionToken) {
  const session = requireSession_(sessionToken, ['super_admin']);
  setNotificationLastSeen_(session.username, 'errorLog');
  return { success: true };
}
function getDatabaseHealth(sessionToken) {
  requireSession_(sessionToken, ['super_admin']);
  const expected = [
    { name: SHEET_DATA, required: ['ID', 'Timestamp', 'Username', 'Detail_Aspirasi', 'StatusAspirasi', 'DibacaAdmin', 'StatusUpdatedAt', 'StatusUpdatedBy', 'CatatanPenolakan', 'Prioritas', 'Catatan_Tindak_Lanjut', 'Tanggal_Tindak_Lanjut', 'Foto_Tindak_Lanjut', 'Lokasi_Masalah', 'Lokasi_Masalah_Detail'], anyRequired: [['Admin_Penangan', 'Admin_Tindak_Lanjut']] },
    { name: SHEET_WARGA, required: ['Username', 'PIN', 'Nama'] },
    { name: SHEET_ADMINS, required: ['Username', 'PIN'] },
    { name: SHEET_REFDATA, required: [] },
    { name: SHEET_APPINFO, required: [] },
    { name: SHEET_SYSTEMCONFIG, required: [] },
    { name: SHEET_KEPUASAN, required: ['Timestamp'] },
    { name: SHEET_APPFEEDBACK, required: ['Timestamp', 'Username', 'Kategori', 'Masukan', 'Status', 'Dibaca'] }
  ];
  const checks = expected.map(function (item) {
    const sheet = getSheet_(item.name);
    if (!sheet) return { name: item.name, status: 'missing', missing: item.required };
    const headers = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0].map(String);
    const missing = item.required.filter(function (header) { return headers.indexOf(header) < 0; });
    (item.anyRequired || []).forEach(function (options) { if (!options.some(function (header) { return headers.indexOf(header) >= 0; })) missing.push(options.join(' atau ')); });
    return { name: item.name, status: missing.length ? 'warning' : 'ok', missing: missing, rows: Math.max(sheet.getLastRow() - 1, 0) };
  });
  return { checkedAt: formatTanggal_(new Date()), ok: checks.filter(function (x) { return x.status === 'ok'; }).length, warnings: checks.filter(function (x) { return x.status !== 'ok'; }).length, checks: checks };
}

// ===================================================================
// APP VERSION
// Google Apps Script tidak mengekspos nomor versi deployment melalui ScriptApp.
// Nilai APP_VERSION disimpan di Script Properties dan diperbarui saat deployment.
// ===================================================================
function getAppVersion_() {
  return PropertiesService.getScriptProperties().getProperty('APP_VERSION') || 'dev';
}

// ===================================================================
// ENTRY POINT
// ===================================================================
function doGet(e) {
  const template = HtmlService.createTemplateFromFile('Index');
  template.appInfo = getAppInfoData_();
  template.systemConfig = getSystemConfig_();
  template.appUrl = ScriptApp.getService().getUrl();
  template.appVersion = getAppVersion_();

  return template.evaluate()
    .setTitle('Teras Tower 2')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ===================================================================
// API UNTUK APLIKASI ANDROID/iOS/PWA (v11)
// -------------------------------------------------------------------
// Versi web Apps Script tetap memakai doGet + google.script.run seperti biasa.
// Aplikasi terpasang (APK, iPhone, PWA) memanggil doPost lewat fetch dengan
// body JSON { fn: "namaFungsi", args: [...] } dan Content-Type text/plain
// (agar tidak memicu preflight CORS yang tidak didukung Apps Script).
//
// Hanya fungsi di TT2_API yang bisa dipanggil — persis 69 fungsi yang sudah
// dipanggil klien lewat google.script.run, ditambah getBootstrap. Fungsi
// berakhiran garis bawah (_) tidak pernah bisa dipanggil dari luar.
// Pemeriksaan sesi & peran tetap dilakukan di dalam masing-masing fungsi.
// Bila menambah fitur baru yang dipanggil klien, tambahkan namanya di sini.
// ===================================================================
const TT2_API_NAMES = [
  'getBootstrap',
  'logoutSession', 'validateSession', 'getManagementLog', 'getErrorLogSummary', 'markErrorLogSeen', 'getDatabaseHealth',
  'registerUser', 'requestForgotPin', 'loginWithPin', 'updateProfile', 'getProfile', 'getAllWarga',
  'getJelajahSekitar', 'submitJelajahRecommendation', 'submitJelajahReview', 'getJelajahReviews', 'getKelolaJelajah',
  'addJelajahCategory', 'addJelajahType', 'updateJelajahCategory', 'updateJelajahType', 'setJelajahCategoryActive',
  'setJelajahTypeActive', 'setJelajahRecommendationDeleted', 'setJelajahVerification', 'getJelajahReviewsAdmin',
  'setJelajahCommentVisibility', 'toggleAdminFromWarga', 'updateWargaByAdmin', 'deleteWarga', 'resetPin',
  'getPendingWork', 'getNotificationSummary', 'markNotificationSeen', 'markAllNotificationsSeen',
  'getResidentNotificationSummary', 'getMyAppFeedback', 'markResidentNotificationSeen', 'getRefData', 'submitAspirasi',
  'getRiwayatSaya', 'getFollowupPhoto', 'getSemuaAspirasi', 'updateTindakLanjut', 'getNomorPenting', 'getNomorDarurat',
  'saveNomorPenting', 'saveNomorDarurat', 'getAllAdmins', 'addAdmin', 'removeAdmin', 'updateSystemConfig', 'saveBanners',
  'submitAppFeedback', 'getAppFeedback', 'markAppFeedbackSeen', 'updateAppFeedback', 'getRekapKepuasan',
  'getMyKepuasanThisWeek', 'submitKepuasan', 'getAllKepuasanAdmin', 'getKontakData', 'getAppClock', 'getAgendaCalendar',
  'saveAgenda', 'setAgendaActive', 'submitAgendaProposal', 'getAgendaManagementData', 'reviewAgendaProposal',
  // v12
  'registerPushToken', 'unregisterPushToken', 'sendPengumuman', 'getPengumumanTerbaru', 'getPengumumanAdmin'
];

// Peta nama -> fungsi dibuat saat dipanggil, sehingga urutan deklarasi tidak berpengaruh.
function getApiFunction_(name) {
  if (TT2_API_NAMES.indexOf(name) < 0) return null;
  const fn = globalThis[name];
  return typeof fn === 'function' ? fn : null;
}

function jsonOutput_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  let request;
  try {
    request = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return jsonOutput_({ ok: false, error: 'Permintaan tidak valid.' });
  }
  const name = String(request && request.fn || '');
  const fn = getApiFunction_(name);
  if (!fn) return jsonOutput_({ ok: false, error: 'Fungsi tidak dikenal.' });
  const args = Array.isArray(request.args) ? request.args : [];
  try {
    const result = fn.apply(null, args);
    return jsonOutput_({ ok: true, result: result === undefined ? null : result });
  } catch (err) {
    // Sama seperti google.script.run: pesan error diteruskan ke failure handler klien.
    return jsonOutput_({ ok: false, error: String(err && err.message || err || 'Kesalahan server.') });
  }
}

// Data awal yang pada versi web disisipkan doGet ke template Index.html.
// Isinya sama dengan yang sudah terlihat oleh siapa pun yang membuka halaman login.
function getBootstrap() {
  const appInfo = getAppInfoData_();
  return {
    appInfo: { Deskripsi: appInfo.Deskripsi || '', Penutup: appInfo.Penutup || '' },
    systemConfig: getSystemConfig_(),
    appUrl: ScriptApp.getService().getUrl(),
    appVersion: getAppVersion_(),
    serverTime: Date.now()
  };
}

// ===================================================================
// AUTH: REGISTER
// ===================================================================
// -------------------------------------------------------------------
// PEMBATASAN REGISTRASI & LUPA PIN (v11)
// • SystemConfig KEY "RegistrasiDibuka" = "false" menutup pendaftaran akun baru.
//   Kosong / tidak ada / nilai lain = dibuka (perilaku lama).
// • Batas global per jam memakai CacheService (bucket per jam, kedaluwarsa otomatis).
// -------------------------------------------------------------------
const REGISTER_MAX_PER_HOUR = 30;
const FORGOT_PIN_MAX_PER_HOUR = 30;

function isRegistrationOpen_() {
  const raw = getSystemConfig_().RegistrasiDibuka;
  const value = String(raw == null ? '' : raw).trim().toLowerCase();
  return !(value === 'false' || value === 'tidak' || value === 'tutup' || value === '0');
}
function hourlyBucketKey_(name) {
  return 'hourly:' + name + ':' + Math.floor(Date.now() / 3600000);
}
function isHourlyLimitReached_(name, max) {
  return Number(CacheService.getScriptCache().get(hourlyBucketKey_(name)) || 0) >= max;
}
// Panggil dari dalam withScriptLock_ agar penambahan hitungan tidak saling menimpa.
function countHourlyEvent_(name) {
  const cache = CacheService.getScriptCache();
  const key = hourlyBucketKey_(name);
  cache.put(key, String(Number(cache.get(key) || 0) + 1), 3700);
}

function registerUser(payload) {
  try {
    const username = payload.username.trim().toLowerCase();
    const pin = payload.pin.trim();
    const pinConfirm = payload.pinConfirm.trim();

    if (!username || !pin || !pinConfirm) {
      return { success: false, message: 'Semua field wajib diisi.' };
    }
    if (username.length < 3) {
      return { success: false, message: 'Username minimal 3 karakter.' };
    }
    if (!/^[a-z0-9_]+$/.test(username)) {
      return { success: false, message: 'Username hanya boleh huruf kecil, angka, dan underscore (_).' };
    }
    if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
      return { success: false, message: 'PIN harus 6 digit angka.' };
    }
    if (pin !== pinConfirm) {
      return { success: false, message: 'PIN dan konfirmasi PIN tidak cocok.' };
    }

    if (!isRegistrationOpen_()) {
      return { success: false, message: 'Pendaftaran akun baru sedang ditutup. Silakan hubungi pengurus Tower 2.' };
    }
    const pinHash = makePinHash_(pin);
    return withScriptLock_(function () {
      // Batas global: aplikasi terpasang di HP warga, jadi alamat backend tidak lagi
      // tersembunyi. Batas ini mencegah pembuatan akun massal oleh skrip.
      if (isHourlyLimitReached_('register', REGISTER_MAX_PER_HOUR)) {
        return { success: false, message: 'Terlalu banyak pendaftaran dalam satu jam terakhir. Silakan coba lagi nanti.' };
      }
      const wargaData = getSheetData_(SHEET_WARGA);
      if (wargaData.some(function(row) { return String(row.Username || '').toLowerCase() === username; })) {
        return { success: false, message: 'Username sudah terdaftar. Silakan pilih username lain.' };
      }

      const sheet = getSheet_(SHEET_WARGA);
      sheet.appendRow([
        sheetText_(username), pinHash, '', '', '', '', '', 'user', 'false'
      ]);
      // v12: tanggal daftar, dasar pembersihan otomatis akun yang tidak dilengkapi.
      sheet.getRange(sheet.getLastRow(), ensureSheetColumn_(sheet, WARGA_REGISTERED_COL)).setValue(new Date());
      countHourlyEvent_('register');
      writeAuditLog_('REGISTER', username, username, 'new_account');

      return { success: true, message: 'Akun berhasil dibuat! Silakan login.' };
    });
  } catch (err) {
    return { success: false, message: 'Terjadi kesalahan: ' + err.message };
  }
}

function requestForgotPin(payload) {
  try {
    const username = String(payload && payload.username || '').trim().toLowerCase();
    if (!/^[a-z0-9_]{3,80}$/.test(username)) return { success: false, message: 'Username tidak valid.' };
    return withScriptLock_(function () {
      const cooldownKey = 'forgot-pin:' + username;
      const cache = CacheService.getScriptCache();
      if (cache.get(cooldownKey)) return { success: true, message: 'Jika username terdaftar, permintaan reset akan dicatat. Silakan hubungi admin untuk proses selanjutnya.' };
      if (isHourlyLimitReached_('forgot-pin', FORGOT_PIN_MAX_PER_HOUR)) {
        return { success: false, message: 'Terlalu banyak permintaan reset PIN dalam satu jam terakhir. Silakan coba lagi nanti atau hubungi admin.' };
      }
      countHourlyEvent_('forgot-pin');
      let sheet = getSheet_(SHEET_RESETREQUESTS);
      if (!sheet) {
        sheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_RESETREQUESTS);
        sheet.appendRow(['RequestID', 'Timestamp', 'Username', 'Nama', 'Status', 'ProcessedAt', 'ProcessedBy']);
      }
      const warga = getSheetData_(SHEET_WARGA).find(function (row) { return String(row.Username || '').toLowerCase() === username; });
      const admins = getSheetData_(SHEET_ADMINS).find(function (row) { return String(row.Username || '').toLowerCase() === username; });
      const found = warga || admins;
      const displayName = found ? (found.Nama || found.Keterangan || found.Username || username) : username;
      const rows = getSheetData_(SHEET_RESETREQUESTS);
      const duplicate = rows.some(function (row) { return String(row.Username || '').toLowerCase() === username && String(row.Status || '') === 'Menunggu'; });
      if (found && !duplicate) sheet.appendRow([Utilities.getUuid().substring(0, 8), new Date(), sheetText_(username), sheetText_(displayName), 'Menunggu', '', '']);
      if (found) writeAuditLog_('REQUEST_RESET_PIN', username, username, duplicate ? 'duplicate_pending' : 'new_request');
      cache.put(cooldownKey, '1', 120);
      return { success: true, message: 'Jika username terdaftar, permintaan reset akan dicatat. Silakan hubungi admin untuk proses selanjutnya.' };
    });
  } catch (err) { return { success: false, message: 'Permintaan reset tidak dapat diproses.' }; }
}

// ===================================================================
// AUTH: LOGIN
// ===================================================================
function loginWithPin(payload) {
  try {
    const username = payload.username.trim().toLowerCase();
    const pin = payload.pin.trim();
    // "Ingat saya" dari layar login: true -> sesi 30 hari, false -> 6 jam.
    const remember = payload.remember === true;

    if (!username || !pin) {
      return { success: false, message: 'Username dan PIN wajib diisi.' };
    }
    if (isLoginRateLimited_(username)) return { success: false, message: 'Terlalu banyak percobaan login. Coba lagi dalam 10 menit.' };

    // Cek Super Admin dari salted hash di Script Properties.
    const superAdmin = getSuperAdminConfig_();
    if (verifySuperAdmin_(username, pin)) {
      clearLoginFailures_(username);
      return {
        success: true,
        user: createSessionUser_({
          username: superAdmin.username,
          name: superAdmin.username,
          isAdmin: true,
          isSuperAdmin_: true,
          profileComplete: true
        }, remember)
      };
    }

    // Cek di sheet Admins (Username, PIN, Keterangan)
    const adminsData = getSheetData_(SHEET_ADMINS);
    const adminMatch = adminsData.find(function (row) {
      return row.Username && String(row.Username).toLowerCase() === username && verifyStoredPin_(pin, row.PIN);
    });

    if (adminMatch) {
      clearLoginFailures_(username);
      upgradePlainPin_(SHEET_ADMINS, adminMatch.Username, pin);
      return {
        success: true,
        user: createSessionUser_({
          username: adminMatch.Username,
          name: adminMatch.Keterangan || adminMatch.Username,
          isAdmin: true,
          isSuperAdmin_: false,
          profileComplete: true
        }, remember)
      };
    }

    // Cek di sheet Warga
    const wargaData = getSheetData_(SHEET_WARGA);
    const user = wargaData.find(function(row) {
      return String(row.Username || '').toLowerCase() === username;
    });

    if (!user || !verifyStoredPin_(pin, user.PIN)) {
      recordLoginFailure_(username);
      writeAuditLog_('LOGIN_FAILED', username, username, 'invalid_credentials');
      return { success: false, message: 'Username atau PIN salah.' };
    }
    clearLoginFailures_(username);
    upgradePlainPin_(SHEET_WARGA, user.Username, pin);

    const isAdmin = isAdminUsername_(username);

    return {
      success: true,
      user: createSessionUser_({
        username: user.Username,
        name: user.Nama || user.Username,
        isAdmin: isAdmin,
        isSuperAdmin_: false,
        statusWisma: user.Status_Wisma || '',
        lantai: user.Lantai || '',
        unit: user.Unit || '',
        nomorWhatsApp: user.Nomor_WhatsApp || '',
        profileComplete: user.ProfileComplete === 'true' || user.ProfileComplete === true,
        profileDeadline: getProfileDeadline_(user)
      }, remember)
    };
  } catch (err) {
    return { success: false, message: 'Terjadi kesalahan: ' + err.message };
  }
}

// ===================================================================
// AUTH: PROFILE
// ===================================================================
function updateProfile(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  payload.username = session.username;
  payload.adminUsername = session.username;
  try {
    const nama = validateString_(payload.nama, 'Nama', 1, 120);
    const rawWhatsApp = String(payload.nomorWhatsApp || '').trim();
    const nomorWhatsApp = rawWhatsApp ? normalizeWhatsAppNumber_(rawWhatsApp) : '';
    if (rawWhatsApp && !nomorWhatsApp) throw new Error('Format WhatsApp tidak valid. Gunakan 08…, 8…, 62… atau +62…; jangan gunakan nomor yang disamarkan.');

    // Admin and Super Admin do not have a resident profile in WargaBaru.
    // Persist the editable display name for regular admins; Super Admin identity
    // remains controlled by Script Properties and is not written to a sheet.
    if (session.role !== 'resident') {
      if (session.role === 'admin') {
        const adminSheet = getSheet_(SHEET_ADMINS);
        const adminValues = adminSheet.getDataRange().getValues();
        const adminHeaders = adminValues[0];
        const adminUsernameCol = adminHeaders.indexOf('Username');
        const adminDescriptionCol = adminHeaders.indexOf('Keterangan');
        if (adminUsernameCol >= 0 && adminDescriptionCol >= 0) {
          for (let i = 1; i < adminValues.length; i++) {
            if (String(adminValues[i][adminUsernameCol] || '').toLowerCase() === session.username.toLowerCase()) {
              adminSheet.getRange(i + 1, adminDescriptionCol + 1).setValue(sheetText_(nama));
              writeAuditLog_('UPDATE_ADMIN_PROFILE', session.username, session.username, 'display_name');
              return { success: true };
            }
          }
        }
        return { success: false, message: 'Akun admin tidak ditemukan.' };
      }
      writeAuditLog_('UPDATE_SUPER_ADMIN_PROFILE', session.username, session.username, 'display_name_local_only');
      return { success: true };
    }

    const statusWisma = validateString_(payload.statusWisma, 'Status di Wisma', 1, 80);
    const refStatuses = getRefData().Status_Wisma || [];
    if (refStatuses.length && refStatuses.indexOf(statusWisma) < 0) throw new Error('Status di Wisma tidak tersedia pada RefData.');
    const lantai = String(payload.lantai || '').trim();
    const unit = String(payload.unit || '').trim();
    const normalizedFloorUnit = validateFloorUnit8O_(statusWisma, lantai, unit);

    const sheet = getSheet_(SHEET_WARGA);
    const values = sheet.getDataRange().getValues();
    const headers = values[0];
    const usernameCol = headers.indexOf('Username');
    const namaCol = headers.indexOf('Nama');
    const statusCol = headers.indexOf('Status_Wisma');
    const lantaiCol = headers.indexOf('Lantai');
    const unitCol = headers.indexOf('Unit');
    const waCol = headers.indexOf('Nomor_WhatsApp');
    const profileCol = headers.indexOf('ProfileComplete');

    for (let i = 1; i < values.length; i++) {
      if (String(values[i][usernameCol]).toLowerCase() === session.username.toLowerCase()) {
        sheet.getRange(i + 1, namaCol + 1).setValue(sheetText_(nama));
        sheet.getRange(i + 1, statusCol + 1).setValue(sheetText_(statusWisma));
        sheet.getRange(i + 1, lantaiCol + 1).setValue(normalizedFloorUnit.floor);
        sheet.getRange(i + 1, unitCol + 1).setValue(normalizedFloorUnit.unit);
        sheet.getRange(i + 1, waCol + 1).setValue(sheetText_(nomorWhatsApp));
        sheet.getRange(i + 1, profileCol + 1).setValue('true');
        return { success: true };
      }
    }
    return { success: false, message: 'User tidak ditemukan.' };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function getProfile(username, sessionToken) {
  try {
    const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
    username = session.role === 'resident' ? session.username : String(username || '').trim();
    if (!username) return { success: false, message: 'Username warga tidak valid.' };
    const wargaData = getSheetData_(SHEET_WARGA);
    const user = wargaData.find(function(row) {
      return String(row.Username || '').toLowerCase() === username.toLowerCase();
    });
    if (!user) return { success: false, message: 'User tidak ditemukan.' };
    return {
      success: true,
      profile: {
        username: user.Username,
        name: user.Nama || '',
        statusWisma: user.Status_Wisma || '',
        lantai: user.Lantai || '',
        unit: user.Unit || '',
        nomorWhatsApp: user.Nomor_WhatsApp || ''
      }
    };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

// ===================================================================
// KELOLA WARGA (Admin & SuperAdmin)
// ===================================================================
function getWargaAttentionReasons_(row, pendingPinReset, accountOnlyAdmin, floorUnitCheck) {
  const reasons = [];
  if (pendingPinReset) reasons.push('Permintaan reset PIN menunggu');
  if (accountOnlyAdmin) return reasons;
  if (!(row.ProfileComplete === true || String(row.ProfileComplete || '').toLowerCase() === 'true')) reasons.push('Profil belum lengkap');
  if (!String(row.Nama || '').trim()) reasons.push('Nama belum diisi');
  if (!normalizeWhatsAppNumber_(row.Nomor_WhatsApp)) reasons.push('Nomor WhatsApp kosong/tidak valid');
  const floorUnit = floorUnitCheck || getFloorUnitAnomaly8O_(row);
  if (floorUnit.reason) reasons.push('Data hunian: ' + floorUnit.reason);
  return reasons;
}

function getAllWarga(requesterUsername, sessionToken) {
  const requester = requireSession_(sessionToken, ['admin', 'super_admin']);
  requesterUsername = requester.username;
  if (requester.role === 'admin' && !isAdminUsername_(requesterUsername)) return { authorized: false, data: [] };
  const wargaSheet = getSheet_(SHEET_WARGA);
  if (!wargaSheet || wargaSheet.getLastColumn() < 1) return { authorized: true, data: [] };
  const data = getSheetData_(SHEET_WARGA);
  const adminData = getSheetData_(SHEET_ADMINS);
  const adminNames = adminData.map(function (row) { return String(row.Username || '').toLowerCase(); });
  const pendingResetNames = {};
  const resetSheet = getSheet_(SHEET_RESETREQUESTS);
  if (resetSheet) getSheetData_(SHEET_RESETREQUESTS).forEach(function (row) {
    if (String(row.Status || '') === 'Menunggu') pendingResetNames[String(row.Username || '').toLowerCase()] = true;
  });
  // Never send PIN values to the browser, even to an authorized admin UI.
  const safeData = data.filter(function (row) { return !isSuperAdmin_(String(row.Username || '')); }).map(function (row) {
    const floorUnitCheck = getFloorUnitAnomaly8O_(row);
    const pendingPinReset = !!pendingResetNames[String(row.Username || '').toLowerCase()];
    const attentionReasons = getWargaAttentionReasons_(row, pendingPinReset, false, floorUnitCheck);
    return {
      Username: row.Username || '',
      Nama: row.Nama || '',
      Status_Wisma: row.Status_Wisma || '',
      Lantai: row.Lantai || '',
      Unit: row.Unit || '',
      Nomor_WhatsApp: row.Nomor_WhatsApp || '',
      Role: row.Role || '',
      ProfileComplete: row.ProfileComplete || '',
      IsAdmin: adminNames.indexOf(String(row.Username || '').toLowerCase()) >= 0,
      IsSuperAdmin: false,
      AccountOnlyAdmin: false,
      PendingPinReset: pendingPinReset,
      DataAnomaly: !!floorUnitCheck.reason,
      DataAnomalyReason: floorUnitCheck.reason,
      NeedsAttention: attentionReasons.length > 0,
      AttentionReasons: attentionReasons
    };
  });
  const residentNames = {};
  safeData.forEach(function (row) { residentNames[String(row.Username || '').toLowerCase()] = true; });
  adminData.forEach(function (row) {
    const username = String(row.Username || '').trim();
    if (!username || isSuperAdmin_(username) || residentNames[username.toLowerCase()]) return;
    const pendingPinReset = !!pendingResetNames[username.toLowerCase()];
    const attentionReasons = getWargaAttentionReasons_({}, pendingPinReset, true);
    safeData.push({ Username: username, Nama: row.Keterangan || '', Status_Wisma: '', Lantai: '', Unit: '', Nomor_WhatsApp: '', Role: 'admin', ProfileComplete: '', IsAdmin: true, IsSuperAdmin: false, AccountOnlyAdmin: true, PendingPinReset: pendingPinReset, DataAnomaly: false, DataAnomalyReason: '', NeedsAttention: attentionReasons.length > 0, AttentionReasons: attentionReasons });
  });
  return { authorized: true, data: safeData };
}

function ensureJelajahHeaders_(sheet, requiredHeaders) {
  if (!sheet) throw new Error('Sheet Jelajah tidak tersedia.');
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  let headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0].map(function (value) { return String(value || '').trim(); });
  if (!headers[0]) {
    sheet.getRange(1, 1, 1, requiredHeaders.length).setValues([requiredHeaders]);
    return;
  }
  requiredHeaders.forEach(function (header) {
    if (headers.indexOf(header) < 0) {
      const column = sheet.getLastColumn() + 1;
      sheet.getRange(1, column).setValue(header);
      headers.push(header);
    }
  });
}
function getJelajahIconOptions_() {
  return ['🍽️', '🛠️', '🌳', '👮', '🏥', '🛒', '💊', '☕', '🚗', '🏦', '🏪', '🏫', '🐾', '🚌', '🏨', '🎬', '📍', '⚽', '🛍️', '💇', '🏋️', '🎨', '📚', '🧺'];
}
function defaultJelajahCategoryIcon_(category) {
  const name = String(category || '').toLowerCase();
  if (name.indexOf('restoran') >= 0 || name.indexOf('makan') >= 0 || name.indexOf('kuliner') >= 0) return '🍽️';
  if (name.indexOf('bengkel') >= 0 || name.indexOf('servis') >= 0) return '🛠️';
  if (name.indexOf('taman') >= 0 || name.indexOf('hiburan') >= 0) return '🌳';
  if (name.indexOf('polisi') >= 0) return '👮';
  if (name.indexOf('apotek') >= 0 || name.indexOf('farmasi') >= 0 || name.indexOf('klinik') >= 0) return '💊';
  if (name.indexOf('rumah sakit') >= 0 || name.indexOf('kesehatan') >= 0) return '🏥';
  if (name.indexOf('kopi') >= 0 || name.indexOf('kafe') >= 0) return '☕';
  if (name.indexOf('toko') >= 0 || name.indexOf('belanja') >= 0) return '🛒';
  return '📍';
}
function isAllowedJelajahIcon_(icon) {
  const value = String(icon || '').trim();
  if (!value || value.length > 16) return false;
  try { return /^[\p{Extended_Pictographic}\p{Emoji_Component}\p{S}\uFE0F\u200D\u20E3]+$/u.test(value); }
  catch (err) { return getJelajahIconOptions_().indexOf(value) >= 0; }
}
function isJelajahCatalogActive_(value) {
  if (value === false || value === 0) return false;
  const normalized = String(value == null ? '' : value).trim().toUpperCase();
  return !['FALSE', '0', 'TIDAK', 'NO', 'NONAKTIF', 'INACTIVE', 'DISABLED'].includes(normalized);
}
function getJelajahCategorySheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_JELAJAH_KATEGORI);
  const isNew = !sheet;
  if (!sheet) sheet = ss.insertSheet(SHEET_JELAJAH_KATEGORI);
  ensureJelajahHeaders_(sheet, ['Kategori', 'Ikon', 'Aktif']);
  if (isNew || sheet.getLastRow() < 2) {
    if (sheet.getLastRow() < 2) sheet.getRange(2, 1, 4, 2).setValues([['Restoran', '🍽️'], ['Bengkel', '🛠️'], ['Taman/Tempat Hiburan', '🌳'], ['Kantor Polisi', '👮']]);
  }
  return sheet;
}
function getJelajahTypeSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_JELAJAH_JENIS);
  const isNew = !sheet;
  if (!sheet) sheet = ss.insertSheet(SHEET_JELAJAH_JENIS);
  ensureJelajahHeaders_(sheet, ['Kategori', 'Jenis', 'Aktif', 'Ikon']);
  if (isNew || sheet.getLastRow() < 2) {
    if (sheet.getLastRow() < 2) {
      sheet.getRange(2, 1, 21, 3).setValues([
        ['Restoran', 'Bakso', true], ['Restoran', 'Mie Ayam', true], ['Restoran', 'Nasi Padang', true], ['Restoran', 'Sate', true], ['Restoran', 'Seafood', true], ['Restoran', 'Kopi/Kafe', true],
        ['Bengkel', 'Servis Motor', true], ['Bengkel', 'Servis Mobil', true], ['Bengkel', 'Tambal Ban', true], ['Bengkel', 'Servis AC', true],
        ['Taman/Tempat Hiburan', 'Taman', true], ['Taman/Tempat Hiburan', 'Taman Bermain Anak', true], ['Taman/Tempat Hiburan', 'Tempat Olahraga', true], ['Taman/Tempat Hiburan', 'Bioskop', true], ['Taman/Tempat Hiburan', 'Pusat Hiburan', true],
        ['Kantor Polisi', 'Polsek', true], ['Kantor Polisi', 'Polres', true], ['Kantor Polisi', 'Pos Polisi', true], ['Kantor Polisi', 'Layanan Pengaduan', true], ['Kantor Polisi', 'Layanan SIM', true], ['Kantor Polisi', 'Layanan SKCK', true]
      ]);
    }
  }
  return sheet;
}
function getJelajahRecommendationSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_JELAJAH);
  if (!sheet) sheet = ss.insertSheet(SHEET_JELAJAH);
  ensureJelajahHeaders_(sheet, ['ID', 'Timestamp', 'Username', 'NamaPengirim', 'Kategori', 'Jenis', 'NamaLokasi', 'TautanMaps', 'Alamat', 'Keterangan', 'Tagging', 'StatusVerifikasi', 'VerifikasiOleh', 'TanggalVerifikasi', 'StatusRekomendasi']);
  return sheet;
}
function getJelajahReviewSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_JELAJAH_ULASAN);
  if (!sheet) sheet = ss.insertSheet(SHEET_JELAJAH_ULASAN);
  ensureJelajahHeaders_(sheet, ['ID', 'RecommendationID', 'Username', 'NamaPengulas', 'Rating', 'Komentar', 'StatusKomentar', 'CreatedAt', 'UpdatedAt']);
  return sheet;
}
function isAllowedGoogleMapsUrl_(value) {
  const url = String(value || '').trim();
  if (!url || url.length > 1000) return false;
  const match = url.match(/^https:\/\/([^\/?#]+)(\/[^?#]*)?/i);
  if (!match) return false;
  let host = String(match[1] || '').toLowerCase();
  if (host.endsWith(':443')) host = host.slice(0, -4);
  if (host.indexOf(':') >= 0) return false;
  const path = String(match[2] || '/').toLowerCase();
  if (host === 'maps.app.goo.gl') return path !== '/' && path.length > 1;
  if (host === 'maps.google.com' || host === 'maps.google.co.id') return path !== '/' || url.indexOf('?') >= 0;
  if (host === 'goo.gl') return path.indexOf('/maps/') === 0 || path === '/maps';
  if (host === 'google.com' || host === 'www.google.com' || host === 'google.co.id' || host === 'www.google.co.id') return path.indexOf('/maps') === 0;
  return false;
}
function getJelajahCatalog_() {
  getJelajahCategorySheet_();
  getJelajahTypeSheet_();
  const categoryRows = getSheetData_(SHEET_JELAJAH_KATEGORI);
  const allCategories = categoryRows.map(function (row) { return String(row.Kategori || '').trim(); }).filter(function (item, index, all) { return !!item && all.indexOf(item) === index; });
  const categoryActiveByName = {};
  const categoryIcons = {};
  allCategories.forEach(function (category) {
    Object.defineProperty(categoryActiveByName, category, { value: true, writable: true, enumerable: true, configurable: true });
    Object.defineProperty(categoryIcons, category, { value: defaultJelajahCategoryIcon_(category), writable: true, enumerable: true, configurable: true });
  });
  categoryRows.forEach(function (row) {
    const category = String(row.Kategori || '').trim();
    if (!category || !Object.prototype.hasOwnProperty.call(categoryActiveByName, category)) return;
    Object.defineProperty(categoryActiveByName, category, { value: isJelajahCatalogActive_(row.Aktif), writable: true, enumerable: true, configurable: true });
    const icon = String(row.Ikon || '').trim();
    if (isAllowedJelajahIcon_(icon)) Object.defineProperty(categoryIcons, category, { value: icon, writable: true, enumerable: true, configurable: true });
  });
  const activeCategories = allCategories.filter(function (category) { return categoryActiveByName[category] !== false; });
  const allTypesByCategory = {};
  const typeIconsByCategory = {};
  const typeActiveByCategory = {};
  const typesByCategory = {};
  allCategories.forEach(function (category) {
    Object.defineProperty(allTypesByCategory, category, { value: [], writable: true, enumerable: true, configurable: true });
    Object.defineProperty(typeIconsByCategory, category, { value: {}, writable: true, enumerable: true, configurable: true });
    Object.defineProperty(typeActiveByCategory, category, { value: {}, writable: true, enumerable: true, configurable: true });
  });
  activeCategories.forEach(function (category) { Object.defineProperty(typesByCategory, category, { value: [], writable: true, enumerable: true, configurable: true }); });
  const typeRows = getSheetData_(SHEET_JELAJAH_JENIS);
  typeRows.forEach(function (row) {
    const category = String(row.Kategori || '').trim();
    const type = String(row.Jenis || '').trim();
    if (!type || !Object.prototype.hasOwnProperty.call(allTypesByCategory, category)) return;
    const active = isJelajahCatalogActive_(row.Aktif);
    if (allTypesByCategory[category].indexOf(type) < 0) allTypesByCategory[category].push(type);
    Object.defineProperty(typeActiveByCategory[category], type, { value: active, writable: true, enumerable: true, configurable: true });
    const typeIcon = String(row.Ikon || '').trim();
    if (isAllowedJelajahIcon_(typeIcon)) Object.defineProperty(typeIconsByCategory[category], type, { value: typeIcon, writable: true, enumerable: true, configurable: true });
    if (active && Object.prototype.hasOwnProperty.call(typesByCategory, category) && typesByCategory[category].indexOf(type) < 0) typesByCategory[category].push(type);
  });
  Object.keys(allTypesByCategory).forEach(function (category) { allTypesByCategory[category].sort(); });
  Object.keys(typesByCategory).forEach(function (category) { typesByCategory[category].sort(); });
  return { categories: activeCategories, allCategories: allCategories, categoryActiveByName: categoryActiveByName, typesByCategory: typesByCategory, allTypesByCategory: allTypesByCategory, typeActiveByCategory: typeActiveByCategory, categoryIcons: categoryIcons, typeIconsByCategory: typeIconsByCategory, iconOptions: getJelajahIconOptions_() };
}
function getJelajahReviewSummary_(reviewRows) {
  const summary = {};
  reviewRows.forEach(function (row) {
    const recId = String(row.RecommendationID || '');
    const score = Number(row.Rating);
    if (!recId || score < 1 || score > 5 || Math.floor(score) !== score) return;
    if (!summary[recId]) summary[recId] = { total: 0, sum: 0, latestComment: null };
    summary[recId].total++;
    summary[recId].sum += score;
    const comment = String(row.Komentar || '').trim();
    const visible = String(row.StatusKomentar || 'Tampil') !== 'Disembunyikan';
    const stamp = new Date(row.UpdatedAt || row.CreatedAt || 0).getTime() || 0;
    if (comment && visible && (!summary[recId].latestComment || stamp >= summary[recId].latestComment._stamp)) {
      summary[recId].latestComment = { text: comment, name: String(row.NamaPengulas || 'Warga'), rating: score, _stamp: stamp };
    }
  });
  Object.keys(summary).forEach(function (id) {
    summary[id].average = summary[id].total ? Math.round(summary[id].sum / summary[id].total * 10) / 10 : 0;
    if (summary[id].latestComment) delete summary[id].latestComment._stamp;
  });
  return summary;
}
function getJelajahRecommendationRows_() {
  getJelajahRecommendationSheet_();
  return getSheetData_(SHEET_JELAJAH);
}
function buildJelajahRecommendationPublic_(row, summary) {
  const id = String(row.ID || '');
  const score = summary[id] || { total: 0, sum: 0, average: 0, latestComment: null };
  return {
    id: id, timestamp: row.Timestamp ? formatTanggal_(row.Timestamp) : '',
    namaPengirim: String(row.NamaPengirim || ''), kategori: String(row.Kategori || ''), jenis: String(row.Jenis || ''),
    namaLokasi: String(row.NamaLokasi || ''), tautanMaps: String(row.TautanMaps || ''), alamat: String(row.Alamat || ''),
    keterangan: String(row.Keterangan || ''), tags: String(row.Tagging || ''),
    verified: String(row.StatusVerifikasi || '') === 'Terverifikasi',
    ratingAverage: score.average || 0, ratingCount: score.total || 0,
    featuredComment: score.latestComment ? score.latestComment.text : '',
    featuredCommentName: score.latestComment ? score.latestComment.name : '', featuredCommentRating: score.latestComment ? score.latestComment.rating : 0
  };
}
function getJelajahSekitar(sessionToken) {
  requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  withScriptLock_(function () { getJelajahCategorySheet_(); getJelajahTypeSheet_(); getJelajahRecommendationSheet_(); getJelajahReviewSheet_(); });
  const catalog = getJelajahCatalog_();
  const reviews = getSheetData_(SHEET_JELAJAH_ULASAN);
  const summary = getJelajahReviewSummary_(reviews);
  const recommendations = getJelajahRecommendationRows_().filter(function (row) { return String(row.StatusRekomendasi || 'Aktif') !== 'Dihapus'; })
    .map(function (row) { return buildJelajahRecommendationPublic_(row, summary); }).reverse();
  return { success: true, categories: catalog.categories, allCategories: catalog.allCategories, categoryActiveByName: catalog.categoryActiveByName, typesByCategory: catalog.typesByCategory, allTypesByCategory: catalog.allTypesByCategory, typeActiveByCategory: catalog.typeActiveByCategory, categoryIcons: catalog.categoryIcons, typeIconsByCategory: catalog.typeIconsByCategory, iconOptions: catalog.iconOptions, recommendations: recommendations };
}
function submitJelajahRecommendation(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  payload = payload || {};
  const category = String(payload.kategori || '').trim();
  const type = String(payload.jenis || '').trim();
  const placeName = String(payload.namaLokasi || '').trim();
  const mapsUrl = String(payload.tautanMaps || '').trim();
  const address = String(payload.alamat || '').trim();
  const details = String(payload.keterangan || '').trim();
  const tags = Array.isArray(payload.tags) ? payload.tags : String(payload.tags || '').split(',');
  const cleanTags = tags.map(function (tag) { return String(tag || '').trim().replace(/^#/, ''); }).filter(Boolean);
    if (!category || category.length > 60) return { success: false, message: 'Kategori wajib dipilih.' };
    if (!type || type.length > 80) return { success: false, message: 'Jenis rekomendasi wajib dipilih.' };
    if (!placeName || placeName.length > 140) return { success: false, message: 'Nama lokasi wajib diisi (maksimal 140 karakter).' };
    if (!isAllowedGoogleMapsUrl_(mapsUrl)) return { success: false, message: 'Tautan harus berupa link Google Maps atau Maps Short Link yang valid.' };
    if (address.length > 240 || details.length > 1200 || cleanTags.length > 8 || cleanTags.some(function (tag) { return tag.length > 32; })) return { success: false, message: 'Alamat/keterangan/tag terlalu panjang atau jumlah tag melebihi batas.' };
  try {
    const warga = getSheetData_(SHEET_WARGA).find(function (row) { return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase(); });
    const senderName = String(warga && warga.Nama || session.username);
    return withScriptLock_(function () {
      const catalog = getJelajahCatalog_();
      if (catalog.categories.indexOf(category) < 0 || (catalog.typesByCategory[category] || []).indexOf(type) < 0) return { success: false, message: 'Kategori atau jenis sudah tidak tersedia. Muat ulang halaman dan pilih kembali.' };
      const id = Utilities.getUuid();
      getJelajahRecommendationSheet_().appendRow([id, new Date(), sheetText_(session.username), sheetText_(senderName), sheetText_(category), sheetText_(type), sheetText_(placeName), sheetText_(mapsUrl), sheetText_(address), sheetText_(details), sheetText_(cleanTags.join(', ')), 'Menunggu', '', '']);
      writeAuditLog_('SUBMIT_JELAJAH_RECOMMENDATION', session.username, id, 'category=' + category);
      return { success: true, message: 'Rekomendasi berhasil disimpan dan langsung tersedia untuk warga.' };
    });
  } catch (err) {
    writeApplicationError_('submitJelajahRecommendation', err, session.username);
    return { success: false, message: 'Rekomendasi belum tersimpan. Coba lagi sebentar.' };
  }
}
function submitJelajahReview(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  payload = payload || {};
  const recommendationId = String(payload.recommendationId || '').trim();
  const rating = Number(payload.rating);
  const comment = String(payload.comment || '').trim();
  if (!recommendationId) return { success: false, message: 'Rekomendasi tidak valid.' };
  if (rating < 1 || rating > 5 || Math.floor(rating) !== rating) return { success: false, message: 'Pilih rating 1 sampai 5 bintang.' };
  if (comment.length > 500) return { success: false, message: 'Komentar maksimal 500 karakter.' };
  try {
    const resident = getSheetData_(SHEET_WARGA).find(function (row) { return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase(); });
    const reviewerName = String(resident && resident.Nama || session.username);
    return withScriptLock_(function () {
      const recRows = getJelajahRecommendationRows_();
      const targetRecommendation = recRows.find(function (row) { return String(row.ID || '') === recommendationId; });
      if (!targetRecommendation || String(targetRecommendation.StatusRekomendasi || 'Aktif') === 'Dihapus') return { success: false, message: 'Rekomendasi tidak ditemukan atau sedang diarsipkan.' };
      const sheet = getJelajahReviewSheet_();
      const values = sheet.getDataRange().getValues();
      const headers = values[0].map(function (h) { return String(h || ''); });
      const index = {};
      headers.forEach(function (h, i) { index[h] = i; });
      let rowIndex = -1;
      for (let i = 1; i < values.length; i++) {
        if (String(values[i][index.RecommendationID] || '') === recommendationId && String(values[i][index.Username] || '').toLowerCase() === String(session.username).toLowerCase()) { rowIndex = i; break; }
      }
      const now = new Date();
      if (rowIndex >= 0) {
        const sheetRow = rowIndex + 1;
        sheet.getRange(sheetRow, index.Rating + 1).setValue(rating);
        sheet.getRange(sheetRow, index.Komentar + 1).setValue(sheetText_(comment));
        sheet.getRange(sheetRow, index.NamaPengulas + 1).setValue(sheetText_(reviewerName));
        sheet.getRange(sheetRow, index.UpdatedAt + 1).setValue(now);
      } else {
        sheet.appendRow([Utilities.getUuid(), recommendationId, sheetText_(session.username), sheetText_(reviewerName), rating, sheetText_(comment), 'Tampil', now, now]);
      }
      writeAuditLog_('UPSERT_JELAJAH_REVIEW', session.username, recommendationId, 'rating=' + rating);
      return { success: true, message: 'Rating dan komentar berhasil disimpan.' };
    });
  } catch (err) { writeApplicationError_('submitJelajahReview', err, session.username); return { success: false, message: 'Rating belum tersimpan. Coba lagi.' }; }
}
function getJelajahReviews(recommendationId, sessionToken) {
  const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  const id = String(recommendationId || '').trim();
  const rec = getJelajahRecommendationRows_().find(function (row) { return String(row.ID || '') === id; });
  if (!rec || String(rec.StatusRekomendasi || 'Aktif') === 'Dihapus') return { success: false, message: 'Rekomendasi tidak ditemukan atau sedang diarsipkan.' };
  getJelajahReviewSheet_();
  const rows = getSheetData_(SHEET_JELAJAH_ULASAN).filter(function (row) { return String(row.RecommendationID || '') === id; });
  const summary = getJelajahReviewSummary_(rows)[id] || { total: 0, sum: 0, average: 0 };
  const own = rows.find(function (row) { return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase(); });
  const comments = rows.filter(function (row) { return String(row.Komentar || '').trim() && String(row.StatusKomentar || 'Tampil') !== 'Disembunyikan'; })
    .sort(function (a, b) { return new Date(b.UpdatedAt || b.CreatedAt || 0).getTime() - new Date(a.UpdatedAt || a.CreatedAt || 0).getTime(); })
    .slice(0, 100).map(function (row) { return { nama: String(row.NamaPengulas || 'Warga'), rating: Number(row.Rating) || 0, komentar: String(row.Komentar || ''), tanggal: row.UpdatedAt || row.CreatedAt ? formatTanggal_(row.UpdatedAt || row.CreatedAt) : '' }; });
  return { success: true, recommendation: buildJelajahRecommendationPublic_(rec, (function () { const obj = {}; obj[id] = summary; return obj; })()), ratingAverage: summary.average || 0, ratingCount: summary.total || 0, ownReview: own ? { rating: Number(own.Rating) || 0, comment: String(own.Komentar || ''), commentHidden: String(own.StatusKomentar || '') === 'Disembunyikan' } : null, comments: comments };
}
function requireJelajahAdmin_(token) {
  const session = requireSession_(token, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) throw new Error('Anda tidak memiliki akses Admin.');
  return session;
}
function getKelolaJelajah(sessionToken) {
  const session = requireJelajahAdmin_(sessionToken);
  withScriptLock_(function () { getJelajahCategorySheet_(); getJelajahTypeSheet_(); getJelajahRecommendationSheet_(); getJelajahReviewSheet_(); });
  const catalog = getJelajahCatalog_();
  const reviews = getSheetData_(SHEET_JELAJAH_ULASAN);
  const summary = getJelajahReviewSummary_(reviews);
  const recommendations = getJelajahRecommendationRows_().map(function (row) {
    const item = buildJelajahRecommendationPublic_(row, summary);
    item.username = String(row.Username || ''); item.statusVerifikasi = String(row.StatusVerifikasi || 'Menunggu'); item.verifikasiOleh = String(row.VerifikasiOleh || '');
    item.statusRekomendasi = String(row.StatusRekomendasi || 'Aktif');
    return item;
  }).reverse();
  return { success: true, actor: session.username, categories: catalog.allCategories, typesByCategory: catalog.allTypesByCategory, categoryActiveByName: catalog.categoryActiveByName, typeActiveByCategory: catalog.typeActiveByCategory, categoryIcons: catalog.categoryIcons, typeIconsByCategory: catalog.typeIconsByCategory, iconOptions: catalog.iconOptions, recommendations: recommendations };
}
function addJelajahCategory(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const category = String(payload && payload.category || '').trim();
  const icon = String(payload && payload.icon || '').trim() || defaultJelajahCategoryIcon_(category);
  if (category.length < 2 || category.length > 60) return { success: false, message: 'Nama kategori harus 2–60 karakter.' };
  if (!isAllowedJelajahIcon_(icon)) return { success: false, message: 'Masukkan satu emoji atau simbol yang valid (maksimal 16 karakter).' }
  try {
    return withScriptLock_(function () {
      const sheet = getJelajahCategorySheet_();
      const all = getSheetData_(SHEET_JELAJAH_KATEGORI);
      if (all.some(function (row) { return String(row.Kategori || '').trim().toLowerCase() === category.toLowerCase(); })) return { success: false, message: 'Kategori itu sudah ada.' };
      const categoryHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (h) { return String(h || '').trim(); });
      const newCategoryRow = Array(categoryHeaders.length).fill('');
      newCategoryRow[categoryHeaders.indexOf('Kategori')] = sheetText_(category);
      newCategoryRow[categoryHeaders.indexOf('Ikon')] = icon;
      newCategoryRow[categoryHeaders.indexOf('Aktif')] = true;
      sheet.appendRow(newCategoryRow);
      writeAuditLog_('ADD_JELAJAH_CATEGORY', session.username, category, '');
      return { success: true, message: 'Kategori berhasil ditambahkan.' };
    });
  } catch (err) { return { success: false, message: 'Kategori belum tersimpan: ' + err.message }; }
}
function addJelajahType(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const category = String(payload && payload.category || '').trim();
  const type = String(payload && payload.type || '').trim();
  const icon = String(payload && payload.icon || '').trim() || defaultJelajahCategoryIcon_(category);
  if (!category || type.length < 2 || type.length > 80) return { success: false, message: 'Pilih kategori dan isi jenis 2–80 karakter.' };
  if (!isAllowedJelajahIcon_(icon)) return { success: false, message: 'Masukkan satu emoji atau simbol yang valid (maksimal 16 karakter).' };
  try {
    return withScriptLock_(function () {
      const catalog = getJelajahCatalog_();
      if (catalog.categories.indexOf(category) < 0) return { success: false, message: 'Kategori tidak ditemukan atau sedang dinonaktifkan.' };
      if ((catalog.typesByCategory[category] || []).some(function (item) { return item.toLowerCase() === type.toLowerCase(); })) return { success: false, message: 'Jenis tersebut sudah ada pada kategori ini.' };
      const sheet = getJelajahTypeSheet_();
      const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (h) { return String(h || '').trim(); });
      const row = Array(headers.length).fill('');
      row[headers.indexOf('Kategori')] = sheetText_(category);
      row[headers.indexOf('Jenis')] = sheetText_(type);
      row[headers.indexOf('Aktif')] = true;
      row[headers.indexOf('Ikon')] = icon;
      sheet.appendRow(row);
      writeAuditLog_('ADD_JELAJAH_TYPE', session.username, category + ' / ' + type, 'icon=' + icon);
      return { success: true, message: 'Jenis berhasil ditambahkan.' };
    });
  } catch (err) { return { success: false, message: 'Jenis belum tersimpan: ' + err.message }; }
}

function updateJelajahCategory(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const oldCategory = String(payload && payload.oldCategory || '').trim();
  const newCategory = String(payload && payload.category || '').trim();
  const icon = String(payload && payload.icon || '').trim();
  if (!oldCategory || newCategory.length < 2 || newCategory.length > 60) return { success: false, message: 'Nama kategori harus 2–60 karakter.' };
  try {
    return withScriptLock_(function () {
      const categorySheet = getJelajahCategorySheet_();
      const categoryRows = categorySheet.getDataRange().getValues();
      const categoryHeaders = categoryRows[0].map(function (value) { return String(value || '').trim(); });
      const categoryCol = categoryHeaders.indexOf('Kategori');
      const iconCol = categoryHeaders.indexOf('Ikon');
      if (categoryCol < 0) return { success: false, message: 'Kolom kategori tidak ditemukan.' };
      let found = false;
      for (let i = 1; i < categoryRows.length; i++) {
        const current = String(categoryRows[i][categoryCol] || '').trim();
        if (current.toLowerCase() === oldCategory.toLowerCase()) found = true;
        if (current.toLowerCase() === newCategory.toLowerCase() && current.toLowerCase() !== oldCategory.toLowerCase()) return { success: false, message: 'Nama kategori itu sudah digunakan.' };
      }
      if (!found) return { success: false, message: 'Kategori yang akan diedit tidak ditemukan.' };
      if (icon && !isAllowedJelajahIcon_(icon)) return { success: false, message: 'Masukkan satu emoji atau simbol yang valid (maksimal 16 karakter).' }
      const oldExact = categoryRows.slice(1).map(function (row) { return String(row[categoryCol] || '').trim(); }).find(function (value) { return value.toLowerCase() === oldCategory.toLowerCase(); });
      const safeNew = sheetText_(newCategory);
      for (let i = 1; i < categoryRows.length; i++) {
        if (String(categoryRows[i][categoryCol] || '').trim() === oldExact) {
          categorySheet.getRange(i + 1, categoryCol + 1).setValue(safeNew);
          if (icon && iconCol >= 0) categorySheet.getRange(i + 1, iconCol + 1).setValue(icon);
        }
      }
      const typeSheet = getJelajahTypeSheet_();
      const typeRows = typeSheet.getDataRange().getValues();
      const typeHeaders = typeRows[0].map(function (value) { return String(value || '').trim(); });
      const typeCategoryCol = typeHeaders.indexOf('Kategori');
      if (typeCategoryCol >= 0) {
        for (let i = 1; i < typeRows.length; i++) {
          if (String(typeRows[i][typeCategoryCol] || '').trim() === oldExact) typeSheet.getRange(i + 1, typeCategoryCol + 1).setValue(safeNew);
        }
      }
      const recommendationSheet = getJelajahRecommendationSheet_();
      const recommendationRows = recommendationSheet.getDataRange().getValues();
      const recommendationHeaders = recommendationRows[0].map(function (value) { return String(value || '').trim(); });
      const recommendationCategoryCol = recommendationHeaders.indexOf('Kategori');
      if (recommendationCategoryCol >= 0) {
        for (let i = 1; i < recommendationRows.length; i++) {
          if (String(recommendationRows[i][recommendationCategoryCol] || '').trim() === oldExact) recommendationSheet.getRange(i + 1, recommendationCategoryCol + 1).setValue(safeNew);
        }
      }
      writeAuditLog_('UPDATE_JELAJAH_CATEGORY', session.username, oldExact, 'new=' + newCategory);
      return { success: true, message: 'Nama kategori diperbarui. Jenis dan rekomendasi lama ikut disesuaikan.' };
    });
  } catch (err) { return { success: false, message: 'Kategori belum diperbarui: ' + err.message }; }
}
function updateJelajahType(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const category = String(payload && payload.category || '').trim();
  const oldType = String(payload && payload.oldType || '').trim();
  const newType = String(payload && payload.type || '').trim();
  const icon = String(payload && payload.icon || '').trim();
  if (!category || !oldType || newType.length < 2 || newType.length > 80) return { success: false, message: 'Nama jenis harus 2–80 karakter.' };
  if (icon && !isAllowedJelajahIcon_(icon)) return { success: false, message: 'Masukkan satu emoji atau simbol yang valid (maksimal 16 karakter).' };
  try {
    return withScriptLock_(function () {
      const catalog = getJelajahCatalog_();
      const actualCategory = catalog.allCategories.find(function (item) { return item.toLowerCase() === category.toLowerCase(); });
      if (!actualCategory) return { success: false, message: 'Kategori tidak ditemukan.' };
      const availableTypes = catalog.allTypesByCategory[actualCategory] || [];
      const actualType = availableTypes.find(function (item) { return item.toLowerCase() === oldType.toLowerCase(); });
      if (!actualType) return { success: false, message: 'Jenis yang akan diedit tidak ditemukan atau sudah tidak aktif.' };
      if (availableTypes.some(function (item) { return item.toLowerCase() === newType.toLowerCase() && item.toLowerCase() !== actualType.toLowerCase(); })) return { success: false, message: 'Jenis itu sudah ada pada kategori ini.' };
      const typeSheet = getJelajahTypeSheet_();
      const typeRows = typeSheet.getDataRange().getValues();
      const typeHeaders = typeRows[0].map(function (value) { return String(value || '').trim(); });
      const typeCategoryCol = typeHeaders.indexOf('Kategori');
      const typeNameCol = typeHeaders.indexOf('Jenis');
      const typeIconCol = typeHeaders.indexOf('Ikon');
      let changed = false;
      for (let i = 1; i < typeRows.length; i++) {
        if (String(typeRows[i][typeCategoryCol] || '').trim() === actualCategory && String(typeRows[i][typeNameCol] || '').trim() === actualType) {
          typeSheet.getRange(i + 1, typeNameCol + 1).setValue(sheetText_(newType));
          if (icon && typeIconCol >= 0) typeSheet.getRange(i + 1, typeIconCol + 1).setValue(icon);
          changed = true;
        }
      }
      if (!changed) return { success: false, message: 'Jenis yang akan diedit tidak ditemukan.' };
      const recommendationSheet = getJelajahRecommendationSheet_();
      const recommendationRows = recommendationSheet.getDataRange().getValues();
      const recommendationHeaders = recommendationRows[0].map(function (value) { return String(value || '').trim(); });
      const recCategoryCol = recommendationHeaders.indexOf('Kategori');
      const recTypeCol = recommendationHeaders.indexOf('Jenis');
      if (recCategoryCol >= 0 && recTypeCol >= 0) {
        for (let i = 1; i < recommendationRows.length; i++) {
          if (String(recommendationRows[i][recCategoryCol] || '').trim() === actualCategory && String(recommendationRows[i][recTypeCol] || '').trim() === actualType) recommendationSheet.getRange(i + 1, recTypeCol + 1).setValue(sheetText_(newType));
        }
      }
      writeAuditLog_('UPDATE_JELAJAH_TYPE', session.username, actualCategory + ' / ' + actualType, 'new=' + newType);
      return { success: true, message: 'Jenis diperbarui. Rekomendasi lama ikut disesuaikan.' };
    });
  } catch (err) { return { success: false, message: 'Jenis belum diperbarui: ' + err.message }; }
}
function setJelajahCategoryActive(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const category = String(payload && payload.category || '').trim();
  const active = payload && payload.active === true;
  if (!category) return { success: false, message: 'Kategori tidak valid.' };
  try {
    return withScriptLock_(function () {
      const sheet = getJelajahCategorySheet_();
      const values = sheet.getDataRange().getValues();
      const headers = values[0].map(function (h) { return String(h || '').trim(); });
      const categoryCol = headers.indexOf('Kategori'); const activeCol = headers.indexOf('Aktif');
      if (categoryCol < 0 || activeCol < 0) return { success: false, message: 'Kolom status kategori tidak tersedia.' };
      let changed = 0;
      for (let i = 1; i < values.length; i++) if (String(values[i][categoryCol] || '').trim().toLowerCase() === category.toLowerCase()) { sheet.getRange(i + 1, activeCol + 1).setValue(active); changed++; }
      if (!changed) return { success: false, message: 'Kategori tidak ditemukan.' };
      writeAuditLog_(active ? 'ENABLE_JELAJAH_CATEGORY' : 'DISABLE_JELAJAH_CATEGORY', session.username, category, 'history=preserved');
      return { success: true, message: active ? 'Kategori diaktifkan kembali. Jenis yang masih aktif tersedia untuk rekomendasi baru.' : 'Kategori dinonaktifkan. Kategori tersembunyi dari pilihan baru; rekomendasi dan ulasan lama tetap tersimpan dan tampil.' };
    });
  } catch (err) { return { success: false, message: 'Status kategori belum berubah: ' + err.message }; }
}
function setJelajahTypeActive(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const category = String(payload && payload.category || '').trim();
  const type = String(payload && payload.type || '').trim();
  const active = payload && payload.active === true;
  if (!category || !type) return { success: false, message: 'Kategori atau jenis tidak valid.' };
  try {
    return withScriptLock_(function () {
      const catalog = getJelajahCatalog_();
      const actualCategory = catalog.allCategories.find(function (item) { return item.toLowerCase() === category.toLowerCase(); });
      if (!actualCategory) return { success: false, message: 'Kategori tidak ditemukan.' };
      const actualType = (catalog.allTypesByCategory[actualCategory] || []).find(function (item) { return item.toLowerCase() === type.toLowerCase(); });
      if (!actualType) return { success: false, message: 'Jenis tidak ditemukan.' };
      const sheet = getJelajahTypeSheet_();
      const values = sheet.getDataRange().getValues();
      const headers = values[0].map(function (h) { return String(h || '').trim(); });
      const categoryCol = headers.indexOf('Kategori'); const typeCol = headers.indexOf('Jenis'); const activeCol = headers.indexOf('Aktif');
      if (categoryCol < 0 || typeCol < 0 || activeCol < 0) return { success: false, message: 'Kolom status jenis tidak tersedia.' };
      let changed = 0;
      for (let i = 1; i < values.length; i++) if (String(values[i][categoryCol] || '').trim() === actualCategory && String(values[i][typeCol] || '').trim() === actualType) { sheet.getRange(i + 1, activeCol + 1).setValue(active); changed++; }
      if (!changed) return { success: false, message: 'Jenis tidak ditemukan.' };
      writeAuditLog_(active ? 'ENABLE_JELAJAH_TYPE' : 'DISABLE_JELAJAH_TYPE', session.username, actualCategory + ' / ' + actualType, 'history=preserved');
      return { success: true, message: active ? (catalog.categoryActiveByName[actualCategory] ? 'Jenis diaktifkan kembali dan tersedia untuk rekomendasi baru.' : 'Jenis diaktifkan kembali, tetapi tetap tersembunyi sampai kategorinya diaktifkan.') : 'Jenis dinonaktifkan dari pilihan baru; rekomendasi dan ulasan lama tetap tersimpan dan tampil.' };
    });
  } catch (err) { return { success: false, message: 'Status jenis belum berubah: ' + err.message }; }
}

function setJelajahRecommendationDeleted(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const id = String(payload && payload.recommendationId || '').trim();
  const deleted = payload && payload.deleted === true;
  if (!id || (payload.deleted !== true && payload.deleted !== false)) return { success: false, message: 'Rekomendasi atau status tidak valid.' };
  try {
    return withScriptLock_(function () {
      const sheet = getJelajahRecommendationSheet_();
      const values = sheet.getDataRange().getValues();
      if (!values.length) return { success: false, message: 'Rekomendasi tidak ditemukan.' };
      const headers = values[0].map(function (h) { return String(h || '').trim(); });
      const idCol = headers.indexOf('ID');
      const statusCol = headers.indexOf('StatusRekomendasi');
      if (idCol < 0 || statusCol < 0) return { success: false, message: 'Kolom status rekomendasi tidak tersedia.' };
      for (let i = 1; i < values.length; i++) {
        if (String(values[i][idCol] || '') !== id) continue;
        sheet.getRange(i + 1, statusCol + 1).setValue(deleted ? 'Dihapus' : 'Aktif');
        writeAuditLog_(deleted ? 'HIDE_JELAJAH_RECOMMENDATION' : 'RESTORE_JELAJAH_RECOMMENDATION', session.username, id, 'reviews=preserved');
        return { success: true, message: deleted ? 'Rekomendasi disembunyikan dari tampilan warga. Riwayat rating dan komentar tetap tersimpan.' : 'Rekomendasi dipulihkan dan ditampilkan kembali kepada warga.' };
      }
      return { success: false, message: 'Rekomendasi tidak ditemukan.' };
    });
  } catch (err) {
    writeApplicationError_('setJelajahRecommendationDeleted', err, session.username);
    return { success: false, message: 'Status rekomendasi belum berubah. Coba lagi.' };
  }
}

function setJelajahVerification(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const id = String(payload && payload.recommendationId || '').trim();
  const verified = !!(payload && payload.verified);
  if (!id) return { success: false, message: 'Rekomendasi tidak valid.' };
  try {
    return withScriptLock_(function () {
      const sheet = getJelajahRecommendationSheet_();
      const values = sheet.getDataRange().getValues();
      const headers = values[0].map(function (h) { return String(h || ''); });
      const idCol = headers.indexOf('ID') + 1;
      const statusCol = headers.indexOf('StatusVerifikasi') + 1;
      const byCol = headers.indexOf('VerifikasiOleh') + 1;
      const dateCol = headers.indexOf('TanggalVerifikasi') + 1;
      for (let i = 1; i < values.length; i++) {
        if (String(values[i][idCol - 1] || '') !== id) continue;
        sheet.getRange(i + 1, statusCol).setValue(verified ? 'Terverifikasi' : 'Menunggu');
        sheet.getRange(i + 1, byCol).setValue(verified ? sheetText_(session.username) : '');
        sheet.getRange(i + 1, dateCol).setValue(verified ? new Date() : '');
        writeAuditLog_('VERIFY_JELAJAH_RECOMMENDATION', session.username, id, verified ? 'Terverifikasi' : 'Menunggu');
        return { success: true, message: verified ? 'Rekomendasi ditandai terverifikasi.' : 'Status verifikasi dikembalikan ke Menunggu.' };
      }
      return { success: false, message: 'Rekomendasi tidak ditemukan.' };
    });
  } catch (err) { return { success: false, message: 'Status verifikasi belum diperbarui.' }; }
}
function getJelajahReviewsAdmin(recommendationId, sessionToken) {
  requireJelajahAdmin_(sessionToken);
  const id = String(recommendationId || '').trim();
  const rec = getJelajahRecommendationRows_().find(function (row) { return String(row.ID || '') === id; });
  if (!rec) return { success: false, message: 'Rekomendasi tidak ditemukan.' };
  getJelajahReviewSheet_();
  const rows = getSheetData_(SHEET_JELAJAH_ULASAN).filter(function (row) { return String(row.RecommendationID || '') === id; })
    .sort(function (a, b) { return new Date(b.UpdatedAt || b.CreatedAt || 0).getTime() - new Date(a.UpdatedAt || a.CreatedAt || 0).getTime(); })
    .map(function (row) { return { id: String(row.ID || ''), nama: String(row.NamaPengulas || row.Username || 'Warga'), rating: Number(row.Rating) || 0, komentar: String(row.Komentar || ''), hidden: String(row.StatusKomentar || '') === 'Disembunyikan', tanggal: row.UpdatedAt || row.CreatedAt ? formatTanggal_(row.UpdatedAt || row.CreatedAt) : '' }; });
  return { success: true, reviews: rows };
}
function setJelajahCommentVisibility(payload) {
  const session = requireJelajahAdmin_(payload && payload.sessionToken);
  const reviewId = String(payload && payload.reviewId || '').trim();
  const visible = !!(payload && payload.visible);
  if (!reviewId) return { success: false, message: 'Komentar tidak valid.' };
  try {
    return withScriptLock_(function () {
      const sheet = getJelajahReviewSheet_();
      const values = sheet.getDataRange().getValues();
      const headers = values[0].map(function (h) { return String(h || ''); });
      const idCol = headers.indexOf('ID') + 1;
      const commentCol = headers.indexOf('Komentar') + 1;
      const statusCol = headers.indexOf('StatusKomentar') + 1;
      for (let i = 1; i < values.length; i++) {
        if (String(values[i][idCol - 1] || '') !== reviewId) continue;
        if (!String(values[i][commentCol - 1] || '').trim()) return { success: false, message: 'Ulasan ini tidak memiliki komentar.' };
        sheet.getRange(i + 1, statusCol).setValue(visible ? 'Tampil' : 'Disembunyikan');
        writeAuditLog_('MODERATE_JELAJAH_COMMENT', session.username, reviewId, visible ? 'Tampil' : 'Disembunyikan');
        return { success: true, message: visible ? 'Komentar ditampilkan kembali.' : 'Komentar disembunyikan; rating tetap dihitung.' };
      }
      return { success: false, message: 'Komentar tidak ditemukan.' };
    });
  } catch (err) { return { success: false, message: 'Status komentar belum diperbarui.' }; }
}

function toggleAdminFromWarga(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['super_admin']);
  const actor = session.username;
  const username = String(payload && payload.username || '').trim();
  if (!isSuperAdmin_(actor)) return { success: false, message: 'Hanya SuperAdmin yang dapat mengubah status Admin.' };
  if (!username) return { success: false, message: 'Username warga tidak valid.' };
  if (username.toLowerCase() === actor.toLowerCase()) return { success: false, message: 'SuperAdmin tidak perlu diaktifkan sebagai Admin.' };
  try {
    return withScriptLock_(function () {
      const wargaSheet = getSheet_(SHEET_WARGA);
      const wargaValues = wargaSheet.getDataRange().getValues();
      const wargaHeaders = wargaValues[0] || [];
      const wargaUsernameCol = wargaHeaders.indexOf('Username');
      const wargaPinCol = wargaHeaders.indexOf('PIN');
      const wargaRow = wargaValues.find(function (row, index) { return index > 0 && String(row[wargaUsernameCol] || '').toLowerCase() === username.toLowerCase(); });
      if (!wargaRow) return { success: false, message: 'Warga tidak ditemukan.' };
      const adminSheet = getSheet_(SHEET_ADMINS);
      if (!adminSheet) return { success: false, message: 'Sheet Admins belum tersedia.' };
      const adminValues = adminSheet.getDataRange().getValues();
      const headers = adminValues[0] || [];
      const usernameCol = headers.indexOf('Username');
      let rowIndex = -1;
      for (let i = 1; i < adminValues.length; i++) if (String(adminValues[i][usernameCol] || '').toLowerCase() === username.toLowerCase()) { rowIndex = i + 1; break; }
      if (rowIndex > 0) {
        adminSheet.deleteRow(rowIndex);
        bumpSessionVersion_(username);
        writeAuditLog_('DEACTIVATE_ADMIN', actor, username, 'Dari Kelola Warga');
        return { success: true, isAdmin: false, message: 'Status Admin dinonaktifkan.' };
      }
      const pinCol = headers.indexOf('PIN');
      if (pinCol < 0 || wargaPinCol < 0 || !wargaRow[wargaPinCol]) return { success: false, message: 'PIN warga tidak ditemukan.' };
      const newRow = headers.map(function (header) {
        if (header === 'Username') return username;
        if (header === 'PIN') return wargaRow[wargaPinCol];
        if (header === 'Keterangan') return String(wargaRow[wargaHeaders.indexOf('Nama')] || 'Admin');
        return '';
      });
      adminSheet.appendRow(newRow);
      bumpSessionVersion_(username);
      writeAuditLog_('ACTIVATE_ADMIN', actor, username, 'Dari Kelola Warga');
      return { success: true, isAdmin: true, message: 'Warga diangkat menjadi Admin.' };
    });
  } catch (err) { return { success: false, message: err.message }; }
}

function updateWargaByAdmin(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  payload.adminUsername = session.username;
  const targetUsername = String(payload && payload.username || '').trim();
  if (!isAdminUsername_(payload.adminUsername)) {
    return { success: false, message: 'Anda tidak memiliki akses.' };
  }
  if (!targetUsername) return { success: false, message: 'Username warga tidak valid.' };
  try {
    const nama = validateString_(payload.nama, 'Nama', 1, 120);
    const statusWisma = validateString_(payload.statusWisma, 'Status di Wisma', 1, 80);
    const lantai = String(payload.lantai || '').trim();
    const unit = String(payload.unit || '').trim();
    const normalizedFloorUnit = validateFloorUnit8O_(statusWisma, lantai, unit);
    const refStatus = getRefData().Status_Wisma || [];
    if (refStatus.length && refStatus.indexOf(statusWisma) < 0) throw new Error('Status di Wisma tidak tersedia pada RefData.');
    const sheet = getSheet_(SHEET_WARGA);
    const values = sheet.getDataRange().getValues();
    const headers = values[0];
    const usernameCol = headers.indexOf('Username');
    const namaCol = headers.indexOf('Nama');
    const statusCol = headers.indexOf('Status_Wisma');
    const lantaiCol = headers.indexOf('Lantai');
    const unitCol = headers.indexOf('Unit');

    for (let i = 1; i < values.length; i++) {
      if (String(values[i][usernameCol]).toLowerCase() === targetUsername.toLowerCase()) {
        if (namaCol >= 0) sheet.getRange(i + 1, namaCol + 1).setValue(sheetText_(nama));
        if (statusCol >= 0) sheet.getRange(i + 1, statusCol + 1).setValue(sheetText_(statusWisma));
        if (lantaiCol >= 0) sheet.getRange(i + 1, lantaiCol + 1).setValue(normalizedFloorUnit.floor);
        if (unitCol >= 0) sheet.getRange(i + 1, unitCol + 1).setValue(normalizedFloorUnit.unit);
        writeAuditLog_('UPDATE_WARGA', payload.adminUsername, targetUsername, 'Verifikasi nama/status/lantai/unit');
        return { success: true };
      }
    }
    return { success: false, message: 'User tidak ditemukan.' };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function deleteWarga(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  payload.adminUsername = session.username;
  if (!isAdminUsername_(payload.adminUsername)) {
    return { success: false, message: 'Anda tidak memiliki akses.' };
  }
  try {
    const sheet = getSheet_(SHEET_WARGA);
    const values = sheet.getDataRange().getValues();
    const headers = values[0];
    const usernameCol = headers.indexOf('Username');
    for (let i = values.length - 1; i >= 1; i--) {
      if (String(values[i][usernameCol]).toLowerCase() === payload.username.toLowerCase()) {
        sheet.deleteRow(i + 1);
        bumpSessionVersion_(payload.username);
        removePushTokensForUser_(payload.username);
        writeAuditLog_('DELETE_WARGA', payload.adminUsername, payload.username, '');
      }
    }
    return { success: true };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function resetPin(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  const adminUsername = session.username;
  if (!isAdminUsername_(adminUsername)) return { success: false, message: 'Anda tidak memiliki akses.' };
  const username = String(payload && payload.username || '').trim();
  if (!username) return { success: false, message: 'Username tidak valid.' };
  try {
    const newPin = makeNumericPin_();
    const newHash = makePinHash_(newPin);
    return withScriptLock_(function () {
      const wargaSheet = getSheet_(SHEET_WARGA);
      const wargaValues = wargaSheet.getDataRange().getValues();
      const wargaHeaders = wargaValues[0] || [];
      const wargaUserCol = wargaHeaders.indexOf('Username');
      const wargaPinCol = wargaHeaders.indexOf('PIN');
      let found = false;
      if (wargaUserCol >= 0 && wargaPinCol >= 0) {
        for (let i = 1; i < wargaValues.length; i++) {
          if (String(wargaValues[i][wargaUserCol] || '').toLowerCase() === username.toLowerCase()) {
            wargaSheet.getRange(i + 1, wargaPinCol + 1).setValue(newHash);
            found = true;
            break;
          }
        }
      }
      // A promoted resident has a mirrored PIN row in Admins. Keep both hashes in sync;
      // admin-only accounts can also be reset from the same UI.
      const adminSheet = getSheet_(SHEET_ADMINS);
      if (adminSheet) {
        const adminValues = adminSheet.getDataRange().getValues();
        const adminHeaders = adminValues[0] || [];
        const adminUserCol = adminHeaders.indexOf('Username');
        const adminPinCol = adminHeaders.indexOf('PIN');
        if (adminUserCol >= 0 && adminPinCol >= 0) {
          for (let i = 1; i < adminValues.length; i++) {
            if (String(adminValues[i][adminUserCol] || '').toLowerCase() === username.toLowerCase()) {
              adminSheet.getRange(i + 1, adminPinCol + 1).setValue(newHash);
              found = true;
              break;
            }
          }
        }
      }
      if (!found) return { success: false, message: 'Username tidak ditemukan.' };
      completePendingResetRequests_(username, adminUsername);
      bumpSessionVersion_(username);
      writeAuditLog_('RESET_PIN', adminUsername, username, 'PIN diganti; sesi sebelumnya dicabut');
      return { success: true, pin: newPin, message: 'PIN baru: ' + newPin };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}

// ===================================================================
// HELPER
// ===================================================================
function completePendingResetRequests_(username, processedBy) {
  const sheet = getSheet_(SHEET_RESETREQUESTS);
  if (!sheet) return;
  const values = sheet.getDataRange().getValues();
  const headers = values[0] || [];
  const usernameCol = headers.indexOf('Username');
  const statusCol = headers.indexOf('Status');
  const processedAtCol = headers.indexOf('ProcessedAt');
  const processedByCol = headers.indexOf('ProcessedBy');
  if (usernameCol < 0 || statusCol < 0) return;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][usernameCol] || '').toLowerCase() === String(username || '').toLowerCase() && String(values[i][statusCol] || '') === 'Menunggu') {
      sheet.getRange(i + 1, statusCol + 1).setValue('Selesai');
      if (processedAtCol >= 0) sheet.getRange(i + 1, processedAtCol + 1).setValue(new Date());
      if (processedByCol >= 0) sheet.getRange(i + 1, processedByCol + 1).setValue(processedBy || '');
    }
  }
}

function getSheet_(sheetName) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
}

function getNotificationStateSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName('NotificationState');
  if (!sheet) {
    sheet = ss.insertSheet('NotificationState');
    sheet.appendRow(['Username', 'Menu', 'LastSeenAt']);
  }
  return sheet;
}
function notificationDate_(value) {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return isNaN(time) ? 0 : time;
}
function getNotificationLastSeen_(username, menu) {
  const sheet = getNotificationStateSheet_();
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0] || '').toLowerCase() === String(username || '').toLowerCase() && String(values[i][1] || '') === menu) return notificationDate_(values[i][2]);
  }
  return null;
}
function setNotificationLastSeen_(username, menu) {
  const sheet = getNotificationStateSheet_();
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0] || '').toLowerCase() === String(username || '').toLowerCase() && String(values[i][1] || '') === menu) {
      sheet.getRange(i + 1, 3).setValue(new Date());
      return;
    }
  }
  sheet.appendRow([username, menu, new Date()]);
}
function countNewNotificationRows_(rows, lastSeen, dateFields) {
  if (lastSeen === null) return 0;
  return rows.filter(function (row) {
    return dateFields.some(function (field) { return notificationDate_(row[field]) > lastSeen; });
  }).length;
}
function notificationSummaryCacheKey_(username) {
  return 'notification-summary:' + String(username || '').toLowerCase().replace(/[^a-z0-9_.-]/g, '_').substring(0, 80);
}
function invalidateNotificationSummaryCache_(username) {
  if (username) CacheService.getScriptCache().remove(notificationSummaryCacheKey_(username));
}
function getPendingWork(sessionToken) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  const cache = CacheService.getScriptCache();
  const cacheKey = 'pending-work-v1:' + (session.role === 'super_admin' ? 'super' : 'admin');
  const cached = cache.get(cacheKey);
  if (cached) {
    try { return JSON.parse(cached); } catch (ignore) { cache.remove(cacheKey); }
  }

  const now = Date.now();
  const limit = 15;
  function ageDays(value) {
    const timestamp = notificationDate_(value);
    return timestamp ? Math.max(0, Math.floor((now - timestamp) / 86400000)) : 0;
  }
  function pack(items) {
    items.sort(function (a, b) { return (b.rank - a.rank) || (b.ageDays - a.ageDays); });
    return {
      total: items.length,
      items: items.slice(0, limit).map(function (item) {
        const safeItem = {};
        Object.keys(item).forEach(function (key) { if (key !== 'rank') safeItem[key] = item[key]; });
        return safeItem;
      })
    };
  }

  try {
    const aspirasi = [];
    const aspirasiSheet = getSheet_(SHEET_DATA);
    (aspirasiSheet ? getSheetData_(SHEET_DATA) : []).forEach(function (row) {
      if (!row.ID) return;
      const rawStatus = String(row.StatusAspirasi || '');
      const status = ['Baru', 'Dibaca', 'Diselesaikan', 'Ditolak'].indexOf(rawStatus) >= 0
        ? rawStatus
        : (String(row.Sudah_Ditindaklanjuti || 'Belum') === 'Sudah' ? 'Diselesaikan' : 'Dibaca');
      if (status !== 'Baru' && status !== 'Dibaca') return;
      const priority = String(row.Prioritas || '');
      aspirasi.push({
        id: String(row.ID), jenis: String(row.Jenis_Aspirasi || ''), kategori: String(row.Kategori || ''),
        status: status, prioritas: priority, ageDays: ageDays(row.Timestamp),
        rank: priority === 'Sangat Tinggi' || priority === 'Tinggi' ? 1 : 0
      });
    });

    const resetPin = [];
    const resetSheet = getSheet_(SHEET_RESETREQUESTS);
    if (resetSheet) {
      const wargaNames = {};
      const wargaSheet = getSheet_(SHEET_WARGA);
      (wargaSheet ? getSheetData_(SHEET_WARGA) : []).forEach(function (row) {
        const username = String(row.Username || '').toLowerCase();
        if (username) wargaNames[username] = String(row.Nama || '');
      });
      getSheetData_(SHEET_RESETREQUESTS).forEach(function (row) {
        if (String(row.Status || '') !== 'Menunggu') return;
        const username = String(row.Username || '').trim();
        if (!username) return;
        resetPin.push({ username: username, nama: wargaNames[username.toLowerCase()] || '', ageDays: ageDays(row.Timestamp), rank: 0 });
      });
    }

    const feedback = [];
    if (session.role === 'super_admin') {
      const feedbackSheet = getSheet_(SHEET_APPFEEDBACK);
      if (feedbackSheet) getSheetData_(SHEET_APPFEEDBACK).forEach(function (row) {
        if (!row.Masukan || String(row.Status || 'Baru') !== 'Baru') return;
        feedback.push({ username: String(row.Username || ''), kategori: String(row.Kategori || ''), ageDays: ageDays(row.Timestamp), rank: 0 });
      });
    }

    const result = { aspirasi: pack(aspirasi), resetPin: pack(resetPin), feedback: pack(feedback) };
    cache.put(cacheKey, JSON.stringify(result), 30);
    return result;
  } catch (err) {
    writeApplicationError_('getPendingWork', err, session.username);
    return { error: true, aspirasi: { total: 0, items: [] }, resetPin: { total: 0, items: [] }, feedback: { total: 0, items: [] } };
  }
}
function getNotificationSummary(sessionToken) {
  let actor = '';
  try {
    const session = requireSession_(sessionToken, ['admin', 'super_admin']);
    actor = session.username;
    const username = session.username;
    const cached = CacheService.getScriptCache().get(notificationSummaryCacheKey_(username));
    if (cached) {
      try { return JSON.parse(cached); } catch (ignore) { invalidateNotificationSummaryCache_(username); }
    }
    const now = new Date().getTime();
    const result = { aspirasi: 0, kepuasan: 0, warga: 0, admin: 0, nomorPenting: 0, nomorDarurat: 0, resetPin: 0, anomaliWarga: 0 };
    result.anomaliWarga = getWargaFloorUnitAnomalies_().length;
  const aspirasiSheet = getSheet_(SHEET_DATA);
  if (aspirasiSheet) {
    const aspirasiRows = getSheetData_(SHEET_DATA);
    result.aspirasiTotal = aspirasiRows.length;
    result.aspirasiSudahSelesai = aspirasiRows.filter(function (row) { return String(row.Sudah_Ditindaklanjuti || 'Belum') === 'Sudah'; }).length;
    result.aspirasiBelumSelesai = aspirasiRows.filter(function (row) {
      return String(row.Sudah_Ditindaklanjuti || 'Belum') !== 'Sudah';
    }).length;
    result.aspirasiPrioritasTinggi = aspirasiRows.filter(function (row) {
      if (String(row.Sudah_Ditindaklanjuti || 'Belum') === 'Sudah') return false;
      if (String(row.Prioritas || '') === 'Tinggi') return true;
      const created = notificationDate_(row.Timestamp);
      return created > 0 && (now - created) >= 7 * 86400000;
    }).length;
  }
  const sources = [
    ['aspirasi', SHEET_DATA, ['Timestamp', 'UpdatedAt', 'LastUpdatedAt', 'Tanggal_Tindak_Lanjut']],
    ['kepuasan', SHEET_KEPUASAN, ['Timestamp']],
    ['warga', SHEET_WARGA, ['CreatedAt', 'ProfileUpdatedAt']],
    ['admin', SHEET_ADMINS, ['CreatedAt', 'UpdatedAt']],
    ['nomorPenting', SHEET_NOMORPENTING, ['CreatedAt', 'UpdatedAt']],
    ['nomorDarurat', SHEET_NOMORDARURAT, ['CreatedAt', 'UpdatedAt']]
  ];
  sources.forEach(function (source) {
    const menu = source[0];
    const sheet = getSheet_(source[1]);
    if (!sheet) return;
    const lastSeen = getNotificationLastSeen_(username, menu);
    if (lastSeen === null) { setNotificationLastSeen_(username, menu); return; }
    result[menu] = countNewNotificationRows_(getSheetData_(source[1]), lastSeen, source[2]);
  });
  const resetSheet = getSheet_(SHEET_RESETREQUESTS);
  if (resetSheet) {
    const resetLastSeen = getNotificationLastSeen_(username, 'resetPin');
    if (resetLastSeen === null) {
      setNotificationLastSeen_(username, 'resetPin');
    } else {
      result.resetPin = getSheetData_(SHEET_RESETREQUESTS).filter(function (row) {
        return String(row.Status || '') === 'Menunggu' && notificationDate_(row.Timestamp) > resetLastSeen;
      }).length;
    }
  }
    result.generatedAt = now;
    CacheService.getScriptCache().put(notificationSummaryCacheKey_(username), JSON.stringify(result), 30);
    return result;
  } catch (err) {
    writeApplicationError_('getNotificationSummary', err, actor);
    throw err;
  }
}
function markNotificationSeen(sessionToken, menu) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  const allowed = ['aspirasi', 'kepuasan', 'warga', 'admin', 'nomorPenting', 'nomorDarurat', 'resetPin', 'residentAspirasi'];
  if (allowed.indexOf(String(menu || '')) < 0) return { success: false, message: 'Menu notifikasi tidak valid.' };
  setNotificationLastSeen_(session.username, String(menu));
  invalidateNotificationSummaryCache_(session.username);
  return { success: true };
}
function markAllNotificationsSeen(sessionToken) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  ['aspirasi', 'kepuasan', 'warga', 'admin', 'nomorPenting', 'nomorDarurat', 'resetPin'].forEach(function (menu) {
    setNotificationLastSeen_(session.username, menu);
  });
  invalidateNotificationSummaryCache_(session.username);
  return { success: true };
}
function getResidentNotificationSummary(sessionToken) {
  const session = requireSession_(sessionToken, ['resident']);
  const username = session.username;
  const lastSeen = getNotificationLastSeen_(username, 'residentAspirasi');
  if (lastSeen === null) {
    setNotificationLastSeen_(username, 'residentAspirasi');
    return { updates: 0 };
  }
  const rows = getSheetData_(SHEET_DATA).filter(function (row) {
    const owner = String(row.Email_Pengisi || row.Username || row.Username_Pengisi || '').toLowerCase();
    return owner === String(username || '').toLowerCase();
  });
  const aspirationUpdates = rows.filter(function (row) {
    return Math.max(notificationDate_(row.LastUpdatedAt), notificationDate_(row.UpdatedAt), notificationDate_(row.Tanggal_Tindak_Lanjut)) > lastSeen;
  }).length;
  let feedbackUpdates = 0;
  const feedbackSheet = getSheet_(SHEET_APPFEEDBACK);
  if (feedbackSheet) {
    feedbackUpdates = getSheetData_(SHEET_APPFEEDBACK).filter(function (row) {
      return String(row.Username || '').toLowerCase() === String(username || '').toLowerCase() &&
        notificationDate_(row.UpdatedAt || row.Timestamp) > lastSeen;
    }).length;
  }
  return { updates: aspirationUpdates + feedbackUpdates, aspirationUpdates: aspirationUpdates, feedbackUpdates: feedbackUpdates };
}
function getMyAppFeedback(sessionToken) {
  const session = requireSession_(sessionToken, ['resident']);
  getAppFeedbackSheet_();
  const rows = getSheetData_(SHEET_APPFEEDBACK);
  return rows.filter(function (row) {
    return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase();
  }).map(function (row) {
    return {
      timestamp: formatTanggal_(row.Timestamp),
      kategori: String(row.Kategori || ''),
      masukan: String(row.Masukan || ''),
      status: String(row.Status || 'Baru'),
      catatanAdmin: String(row['Catatan Admin'] || ''),
      updatedAt: formatTanggal_(row.UpdatedAt || row.Timestamp)
    };
  }).reverse();
}
function markResidentNotificationSeen(sessionToken) {
  const session = requireSession_(sessionToken, ['resident']);
  setNotificationLastSeen_(session.username, 'residentAspirasi');
  return { success: true };
}

function getSheetData_(sheetName) {
  const sheet = getSheet_(sheetName);

  if (!sheet) {
    throw new Error('Sheet "' + sheetName + '" tidak ditemukan. Pastikan sudah dibuat di Google Sheets dengan nama persis sama.');
  }

  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const rows = values.slice(1);
  return rows
    .filter(function (row) { return row.some(function (cell) { return cell !== ''; }); })
    .map(function (row) {
      const obj = {};
      headers.forEach(function (header, i) { obj[header] = row[i]; });
      return obj;
    });
}
function ensureSheetColumn_(sheet, headerName) {
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  const headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0];
  const existing = headers.indexOf(headerName);
  if (existing >= 0) return existing + 1;
  const nextColumn = lastColumn + 1;
  sheet.getRange(1, nextColumn).setValue(headerName);
  return nextColumn;
}
function ensureAspirasiBookColumns_() {
  return withScriptLock_(function () {
    const sheet = getSheet_(SHEET_DATA);
    if (!sheet) throw new Error('Sheet Data Aspirasi tidak ditemukan.');
    ensureSheetColumn_(sheet, 'Lokasi_Masalah');
    ensureSheetColumn_(sheet, 'Lokasi_Masalah_Detail');
    return true;
  });
}

function isAdminUsername_(username) {
  if (!username) return false;
  if (username.toLowerCase() === String(getSuperAdminConfig_().username).toLowerCase()) return true;
  const admins = getSheetData_(SHEET_ADMINS);
  return admins.some(function (row) { return row.Username && String(row.Username).toLowerCase() === username.toLowerCase(); });
}

function isSuperAdmin_(username) {
  return !!username && username.toLowerCase() === String(getSuperAdminConfig_().username).toLowerCase();
}

function getAppInfoData_() {
  const data = getSheetData_(SHEET_APPINFO);
  return data[0] || {};
}

function getSystemConfig_() {
  try {
    const data = getSheetData_(SHEET_SYSTEMCONFIG);
    const config = {};
    data.forEach(function (row) { config[row.KEY] = row.VALUE; });
    return config;
  } catch (e) { return {}; }
}

// ===================================================================
// REF DATA
// ===================================================================
function getRefData() {
  const data = getSheetData_(SHEET_REFDATA);
  const columns = ['Status_Wisma', 'Lantai', 'Unit', 'Jenis_Aspirasi', 'Kategori', 'Status_Tindak_Lanjut'];
  const result = {};
  columns.forEach(function (col) {
    const values = data
      .map(function (row) { return row[col]; })
      .filter(function (v) { return v !== '' && v !== undefined && v !== null; });
    result[col] = values;
  });
  result.LokasiMasalah = ASPIRATION_LOCATION_TYPES.slice();
  result.Lantai = floorOptions8O_();
  result.Unit = unitSuffixOptions8O_();
  return result;
}

function migrateFloorUnit8O_() {
  return withScriptLock_(function () {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmmss');
    const report = { success: true, backups: [], migrated: 0, alreadyValid: 0, anomalies: [] };
    [SHEET_WARGA, SHEET_DATA].forEach(function (sheetName) {
      const sheet = getSheet_(sheetName);
      if (!sheet || sheet.getLastRow() < 2) return;
      const backup = sheet.copyTo(ss);
      const backupName = sheetName + '_Backup_8O_' + stamp;
      backup.setName(backupName.substring(0, 99));
      report.backups.push(backup.getName());
      const range = sheet.getDataRange();
      const values = range.getValues();
      const headers = values[0] || [];
      const usernameCol = headers.indexOf('Username');
      const namaCol = headers.indexOf('Nama');
      const statusCol = headers.indexOf('Status_Wisma');
      const lantaiCol = headers.indexOf('Lantai');
      const unitCol = headers.indexOf('Unit');
      if (lantaiCol < 0 || unitCol < 0) return;
      for (let i = 1; i < values.length; i++) {
        const username = usernameCol >= 0 ? String(values[i][usernameCol] || '') : '';
        const nama = namaCol >= 0 ? String(values[i][namaCol] || '') : '';
        const status = statusCol >= 0 ? String(values[i][statusCol] || '') : '';
        const normalized = normalizeFloorUnit8O_(values[i][lantaiCol], values[i][unitCol], status);
        if (!normalized.ok) {
          report.anomalies.push({ sheet: sheetName, row: i + 1, username: username, nama: nama, reason: normalized.reason });
          continue;
        }
        const oldFloor = String(values[i][lantaiCol] == null ? '' : values[i][lantaiCol]).trim();
        const oldUnit = String(values[i][unitCol] == null ? '' : values[i][unitCol]).trim();
        if (oldFloor === normalized.floor && oldUnit === normalized.unit) report.alreadyValid++;
        else {
          sheet.getRange(i + 1, lantaiCol + 1).setValue(normalized.floor);
          sheet.getRange(i + 1, unitCol + 1).setValue(normalized.unit);
          report.migrated++;
        }
      }
    });
    const log = ss.getSheetByName('FloorUnitMigrationLog') || ss.insertSheet('FloorUnitMigrationLog');
    if (log.getLastRow() < 1) log.appendRow(['Timestamp', 'Sheet', 'Row', 'Username', 'Nama', 'Reason']);
    report.anomalies.forEach(function (item) { log.appendRow([new Date(), item.sheet, item.row, item.username, item.nama, item.reason]); });
    writeAuditLog_('MIGRATE_FLOOR_UNIT_8O', 'SYSTEM', 'WargaBaru/Data Aspirasi', 'migrated=' + report.migrated + ', anomalies=' + report.anomalies.length);
    report.message = 'Migrasi selesai. Data anomali tidak diubah dan perlu diverifikasi Admin.';
    return report;
  });
}

// ===================================================================
// FORM ASPIRASI
// ===================================================================
function migrateAspirasiStatus8L_() {
  return withScriptLock_(function () {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheet_(SHEET_DATA);
  if (!sheet) throw new Error('Sheet Data Aspirasi tidak ditemukan.');
  const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmmss');
  const backup = sheet.copyTo(ss);
  backup.setName('Data Aspirasi_Backup_8L_' + stamp);
  const required = ['StatusAspirasi', 'DibacaAdmin', 'StatusUpdatedAt', 'StatusUpdatedBy', 'CatatanPenolakan', 'Prioritas', 'Lokasi_Masalah', 'Lokasi_Masalah_Detail'];
  required.forEach(function (h) { ensureSheetColumn_(sheet, h); });
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const col = {}; headers.forEach(function (h, i) { col[h] = i; });
  let migrated = 0;
  for (let i = 1; i < values.length; i++) {
    if (!values[i].some(function (v) { return v !== ''; })) continue;
    const oldStatus = String(values[i][col.Sudah_Ditindaklanjuti] || 'Belum');
    const current = String(values[i][col.StatusAspirasi] || '');
    if (!current) sheet.getRange(i + 1, col.StatusAspirasi + 1).setValue(oldStatus === 'Sudah' ? 'Diselesaikan' : 'Dibaca');
    if (!String(values[i][col.DibacaAdmin] || '')) sheet.getRange(i + 1, col.DibacaAdmin + 1).setValue('Sudah Dibaca');
    if (!String(values[i][col.Prioritas] || '') && String(values[i][col.Jenis_Aspirasi] || '') === 'Pengaduan') sheet.getRange(i + 1, col.Prioritas + 1).setValue('Rendah');
    migrated++;
  }
  return { success: true, backupSheet: backup.getName(), migrated: migrated, message: 'Migrasi Tahap 8L selesai. Backup dibuat.' };  });
}

function submitAspirasi(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident']);
  payload = payload || {};
  const username = session.username;
  try {
    const profile = getSheetData_(SHEET_WARGA).find(function (row) {
      return String(row.Username || '').toLowerCase() === String(username || '').toLowerCase();
    });
    if (!profile || !(profile.ProfileComplete === true || String(profile.ProfileComplete || '').toLowerCase() === 'true')) {
      throw new Error('Profil warga belum lengkap. Lengkapi profil sebelum mengirim aspirasi.');
    }
    const nama = validateString_(profile.Nama, 'Nama profil', 1, 120);
    const statusWisma = validateString_(profile.Status_Wisma, 'Status di Wisma', 1, 80);
    const normalizedFloorUnit = validateFloorUnit8O_(statusWisma, profile.Lantai, profile.Unit);
    const nomorWhatsApp = normalizeWhatsAppNumber_(profile.Nomor_WhatsApp);
    if (!nomorWhatsApp) throw new Error('Nomor WhatsApp pada profil tidak valid. Gunakan 08…, 8…, 62… atau +62…, lalu perbarui Profil Saya.');

    const jenis = validateString_(payload.jenisAspirasi, 'Jenis aspirasi', 1, 30);
    if (['Masukan', 'Kritik', 'Pengaduan'].indexOf(jenis) < 0) throw new Error('Jenis aspirasi tidak valid.');
    const kategori = validateString_(payload.kategori, 'Kategori', 1, 120);
    const categories = getRefData().Kategori || [];
    if (categories.length && categories.indexOf(kategori) < 0) throw new Error('Kategori tidak tersedia pada RefData.');
    const detail = validateString_(payload.detailAspirasi, 'Detail aspirasi', 10, 5000);
    const issueLocation = String(payload.lokasiMasalah || '').trim();
    const issueLocationDetail = String(payload.lokasiMasalahDetail || '').trim();
    if (issueLocation && ASPIRATION_LOCATION_TYPES.indexOf(issueLocation) < 0) throw new Error('Jenis lokasi masalah tidak valid.');
    if (issueLocationDetail.length > 160) throw new Error('Rincian lokasi masalah maksimal 160 karakter.');
    if (issueLocationDetail && !issueLocation) throw new Error('Pilih jenis lokasi masalah terlebih dahulu.');
    if (jenis === 'Pengaduan' && !issueLocation) throw new Error('Pilih jenis lokasi masalah atau pilih Tidak diketahui.');
    const priority = String(payload.prioritas || '').trim();
    if (jenis === 'Pengaduan' && ASPIRATION_PRIORITIES_8L.indexOf(priority) < 0) throw new Error('Prioritas wajib dipilih untuk Pengaduan.');
    if (jenis !== 'Pengaduan' && priority) throw new Error('Prioritas hanya berlaku untuk Pengaduan.');
    const kesediaan = String(payload.kesediaanSwadaya || '').trim();
    if (['Ya', 'Tidak'].indexOf(kesediaan) < 0) throw new Error('Kesediaan swadaya tidak valid.');
    validateFilePayload_(payload.bukti, false);

    ensureAspirasiBookColumns_();

    return withScriptLock_(function () {
      const sheet = getSheet_(SHEET_DATA);
      const id = Utilities.getUuid().substring(0, 8);
      const timestamp = new Date();
      let buktiLink = '';
      if (payload.bukti) buktiLink = uploadBuktiToDrive_(payload.bukti, id);
      const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
      const rowValues = {
        ID: id, Timestamp: timestamp, Username: sheetText_(username), Email_Pengisi: sheetText_(username),
        Nama: sheetText_(nama), Status_Wisma: sheetText_(statusWisma),
        Lantai: normalizedFloorUnit.floor, Unit: normalizedFloorUnit.unit,
        Nomor_WhatsApp: sheetText_(nomorWhatsApp), Jenis_Aspirasi: sheetText_(jenis),
        Kategori: sheetText_(kategori), Detail_Aspirasi: sheetText_(detail), Bukti_Pengaduan: buktiLink,
        Lokasi_Masalah: sheetText_(issueLocation), Lokasi_Masalah_Detail: sheetText_(issueLocationDetail),
        Kesediaan_Swadaya: sheetText_(kesediaan), Sudah_Ditindaklanjuti: 'Belum',
        StatusAspirasi: 'Baru', DibacaAdmin: 'Belum Dibaca', StatusUpdatedAt: timestamp,
        StatusUpdatedBy: '', CatatanPenolakan: '', Prioritas: priority
      };
      sheet.appendRow(headers.map(function (header) { return Object.prototype.hasOwnProperty.call(rowValues, header) ? rowValues[header] : ''; }));
      writeAuditLog_('SUBMIT_ASPIRASI', username, id, kategori);
      // v12: notifikasi ke admin. Isi dibuat umum (tanpa nama warga) karena tampil di layar kunci.
      queuePush_({ admins: true }, { title: 'Aspirasi baru masuk', body: 'Kategori: ' + kategori + '. Ketuk untuk menindaklanjuti.', page: 'admin' });
      return { success: true, id: id };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}
function uploadBuktiToDrive_(bukti, id) {
  return uploadFileToDrive_(bukti, id, 'Teras Tower 2 - Bukti Pengaduan');
}

function getManagedDriveFolder_(folderName) {
  const propertyKey = DRIVE_FOLDER_PROPERTY_BY_NAME[folderName];
  const props = PropertiesService.getScriptProperties();
  const storedId = propertyKey ? props.getProperty(propertyKey) : '';
  if (storedId) {
    try { return DriveApp.getFolderById(storedId); } catch (err) { props.deleteProperty(propertyKey); }
  }
  const existing = DriveApp.getFoldersByName(folderName);
  const folder = existing.hasNext() ? existing.next() : DriveApp.createFolder(folderName);
  if (propertyKey) props.setProperty(propertyKey, folder.getId());
  return folder;
}

function uploadFileToDrive_(fileObj, id, folderName) {
  const folder = getManagedDriveFolder_(folderName);
  const decoded = Utilities.base64Decode(fileObj.base64);
  const blob = Utilities.newBlob(decoded, fileObj.mimeType, id + '_' + fileObj.fileName);
  const file = folder.createFile(blob);
  return file.getUrl();
}

// ===================================================================
// RIWAYAT
// ===================================================================
function getRiwayatSaya(username, sessionToken) {
  const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  username = session.username;
  const data = getSheetData_(SHEET_DATA);
  return data
    .filter(function (row) {
      // Backward-compatible lookup: older sheets use Email_Pengisi while
      // newer versions may use Username for the same logical owner field.
      const owner = String(row.Email_Pengisi || row.Username || row.Username_Pengisi || '').toLowerCase();
      return owner === String(username || '').toLowerCase();
    })
    .sort(function (a, b) { return new Date(b.Timestamp) - new Date(a.Timestamp); })
    .map(function (row) {
      return {
        id: row.ID,
        timestamp: formatTanggal_(row.Timestamp),
        jenisAspirasi: row.Jenis_Aspirasi,
        kategori: row.Kategori,
        detailAspirasi: row.Detail_Aspirasi,
        lokasiMasalah: String(row.Lokasi_Masalah || ''),
        lokasiMasalahDetail: String(row.Lokasi_Masalah_Detail || ''),
        kesediaanSwadaya: row.Kesediaan_Swadaya || '',
        sudahDitindaklanjuti: row.Sudah_Ditindaklanjuti || 'Belum',
        statusAspirasi: ['Baru', 'Dibaca', 'Diselesaikan', 'Ditolak'].indexOf(String(row.StatusAspirasi || '')) >= 0 ? String(row.StatusAspirasi) : (String(row.Sudah_Ditindaklanjuti || 'Belum') === 'Sudah' ? 'Diselesaikan' : 'Dibaca'),
        prioritas: row.Prioritas || '',
        catatanPenolakan: row.CatatanPenolakan || '',
        catatanTindakLanjut: row.Catatan_Tindak_Lanjut || '',
        tanggalTindakLanjut: row.Tanggal_Tindak_Lanjut ? formatTanggal_(row.Tanggal_Tindak_Lanjut) : '',
        fotoTindakLanjut: !!String(row.Foto_Tindak_Lanjut || '').trim(),
        lastUpdatedAt: row.LastUpdatedAt ? formatTanggal_(row.LastUpdatedAt) : '',
        lastUpdatedBy: row.LastUpdatedBy || '',
        lastUpdateType: row.LastUpdateType || ''
      };
    });
}

function getFollowupPhoto(sessionToken, aspirationId) {
  const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  const targetId = String(aspirationId || '').trim();
  if (!targetId) throw new Error('ID aspirasi tidak valid.');
  const rows = getSheetData_(SHEET_DATA);
  const row = rows.find(function (item) { return String(item.ID || '').trim() === targetId; });
  if (!row) throw new Error('Aspirasi tidak ditemukan.');
  const owner = String(row.Email_Pengisi || row.Username || row.Username_Pengisi || '').toLowerCase();
  if (session.role === 'resident' && owner !== String(session.username || '').toLowerCase()) {
    throw new Error('Anda tidak memiliki akses ke foto ini.');
  }
  const storedUrl = String(row.Foto_Tindak_Lanjut || '').trim();
  const fileIdMatch = storedUrl.match(/[-\w]{25,}/);
  if (!fileIdMatch) throw new Error('Foto tindak lanjut tidak tersedia.');
  const file = DriveApp.getFileById(fileIdMatch[0]);
  const blob = file.getBlob();
  const mime = String(blob.getContentType() || '').toLowerCase();
  if (['image/jpeg', 'image/png', 'image/webp'].indexOf(mime) < 0) throw new Error('Tipe foto tidak didukung.');
  const bytes = blob.getBytes();
  if (bytes.length > 6 * 1024 * 1024) throw new Error('Foto terlalu besar untuk ditampilkan.');
  return { success: true, mimeType: mime, base64: Utilities.base64Encode(bytes) };
}

function formatTanggal_(dateValue) {
  if (!dateValue) return '';
  const date = new Date(dateValue);
  if (isNaN(date.getTime())) return String(dateValue);
  return Utilities.formatDate(date, Session.getScriptTimeZone(), 'd MMMM yyyy');
}
function formatTanggalISO_(dateValue) {
  if (!dateValue) return '';
  const date = new Date(dateValue);
  return isNaN(date.getTime()) ? '' : Utilities.formatDate(date, 'UTC', 'yyyy-MM-dd');
}

// ===================================================================
// DASHBOARD ADMIN
// ===================================================================
function getSemuaAspirasi(requesterUsername, sessionToken) {
  requireSession_(sessionToken, ['admin', 'super_admin']);
  const requester = requireSession_(sessionToken, ['admin', 'super_admin']);
  requesterUsername = requester.username;
  if (!isAdminUsername_(requesterUsername)) {
    return { authorized: false, data: [] };
  }
  ensureAspirasiBookColumns_();
  const data = getSheetData_(SHEET_DATA);
  const mapped = data.map(function (row) {
    return {
      id: row.ID,
      timestamp: formatTanggal_(row.Timestamp),
      nama: row.Nama,
      statusWisma: row.Status_Wisma,
      lantai: row.Lantai,
      unit: row.Unit,
      nomorWhatsApp: row.Nomor_WhatsApp,
      jenisAspirasi: row.Jenis_Aspirasi,
      kategori: row.Kategori,
      detailAspirasi: row.Detail_Aspirasi,
      lokasiMasalah: String(row.Lokasi_Masalah || ''),
      lokasiMasalahDetail: String(row.Lokasi_Masalah_Detail || ''),
      buktiPengaduan: row.Bukti_Pengaduan || '',
      kesediaanSwadaya: row.Kesediaan_Swadaya || '',
      sudahDitindaklanjuti: row.Sudah_Ditindaklanjuti || 'Belum',
      catatanTindakLanjut: row.Catatan_Tindak_Lanjut || '',
      fotoTindakLanjut: !!String(row.Foto_Tindak_Lanjut || '').trim(),
      adminPenangan: row.Admin_Penangan || row.Admin_Tindak_Lanjut || '',
      statusAspirasi: ['Baru', 'Dibaca', 'Diselesaikan', 'Ditolak'].indexOf(String(row.StatusAspirasi || '')) >= 0 ? String(row.StatusAspirasi) : (String(row.Sudah_Ditindaklanjuti || 'Belum') === 'Sudah' ? 'Diselesaikan' : 'Dibaca'),
      catatanPenolakan: row.CatatanPenolakan || '',
      lastUpdatedAt: row.LastUpdatedAt ? formatTanggal_(row.LastUpdatedAt) : '',
      lastUpdatedBy: row.LastUpdatedBy || '',
      lastUpdateType: row.LastUpdateType || '',
      tanggalISO: formatTanggalISO_(row.Timestamp),
      prioritas: row.Prioritas || ''
    };
  });
  const now = new Date();
  mapped.forEach(function (item) {
    if (!item.prioritas) {
      const created = item.tanggalISO ? new Date(item.tanggalISO) : null;
      const ageDays = created && !isNaN(created.getTime()) ? Math.floor((now - created) / 86400000) : 0;
      item.prioritas = item.jenisAspirasi === 'Pengaduan' ? 'Rendah' : (item.sudahDitindaklanjuti !== 'Sudah' && ageDays >= 7 ? 'Tinggi' : 'Normal');
    }
  });
  mapped.sort(function (a, b) {
    if (a.sudahDitindaklanjuti !== b.sudahDitindaklanjuti) {
      return a.sudahDitindaklanjuti === 'Sudah' ? 1 : -1;
    }
    return 0;
  });
  const summary = { total: mapped.length, baru: 0, dibaca: 0, diselesaikan: 0, ditolak: 0, belum: 0, sudah: 0, prioritasTinggi: 0, kategori: {} };
  mapped.forEach(function (item) {
    summary[item.statusAspirasi === 'Diselesaikan' ? 'diselesaikan' : item.statusAspirasi === 'Ditolak' ? 'ditolak' : item.statusAspirasi === 'Baru' ? 'baru' : 'dibaca']++;
    if (item.sudahDitindaklanjuti === 'Sudah') summary.sudah++; else summary.belum++;
    if (item.prioritas === 'Sangat Tinggi' || item.prioritas === 'Tinggi') summary.prioritasTinggi++;
    const key = item.kategori || 'Tanpa kategori';
    summary.kategori[key] = (summary.kategori[key] || 0) + 1;
  });
  return { authorized: true, data: mapped, summary: summary };
}

function updateTindakLanjut(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  payload.username = session.username;
  payload.adminUsername = session.username;
  if (!isAdminUsername_(payload.adminUsername)) {
    return { success: false, message: 'Anda tidak memiliki akses admin.' };
  }
  const targetId = String(payload && payload.id != null ? payload.id : '').trim();
  if (!targetId) return { success: false, message: 'ID data tidak valid.' };
  const updateLock = LockService.getScriptLock();
  try {
    updateLock.waitLock(10000);
    const sheet = getSheet_(SHEET_DATA);
    const values = sheet.getDataRange().getValues();
    let headers = values[0];
    const idCol = headers.indexOf('ID');
    const statusCol = headers.indexOf('Sudah_Ditindaklanjuti');
    const status8Col = ensureSheetColumn_(sheet, 'StatusAspirasi');
    const readCol = ensureSheetColumn_(sheet, 'DibacaAdmin');
    const statusUpdatedCol = ensureSheetColumn_(sheet, 'StatusUpdatedAt');
    const statusUpdatedByCol = ensureSheetColumn_(sheet, 'StatusUpdatedBy');
    const rejectionCol = ensureSheetColumn_(sheet, 'CatatanPenolakan');
    const catatanColNumber = ensureSheetColumn_(sheet, 'Catatan_Tindak_Lanjut');
    const tanggalColNumber = ensureSheetColumn_(sheet, 'Tanggal_Tindak_Lanjut');
    const fotoTlColNumber = ensureSheetColumn_(sheet, 'Foto_Tindak_Lanjut');
    const adminColNumber = headers.indexOf('Admin_Penangan') >= 0
      ? headers.indexOf('Admin_Penangan') + 1
      : headers.indexOf('Admin_Tindak_Lanjut') >= 0
        ? headers.indexOf('Admin_Tindak_Lanjut') + 1
        : ensureSheetColumn_(sheet, 'Admin_Penangan');
    headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    const lastUpdatedCol = ensureSheetColumn_(sheet, 'LastUpdatedAt');
    const lastUpdatedByCol = ensureSheetColumn_(sheet, 'LastUpdatedBy');
    const lastUpdateTypeCol = ensureSheetColumn_(sheet, 'LastUpdateType');

    for (let i = 1; i < values.length; i++) {
      if (String(values[i][idCol] == null ? '' : values[i][idCol]).trim() === targetId) {
        const previousStatus = String(values[i][statusCol] || 'Belum');
        const nextStatus = String(payload.status || 'Dibaca');
        if (['Diselesaikan', 'Ditolak', 'Dibaca'].indexOf(nextStatus) < 0) return { success: false, message: 'Status tindak lanjut tidak valid.' };
        if (nextStatus === 'Ditolak' && !String(payload.catatan || '').trim()) return { success: false, message: 'Catatan wajib diisi jika aspirasi Ditolak.' };
        const status8 = nextStatus === 'Diselesaikan' ? 'Diselesaikan' : nextStatus === 'Ditolak' ? 'Ditolak' : 'Dibaca';
        const updateType = previousStatus !== nextStatus
          ? 'Status ' + previousStatus + ' menjadi ' + nextStatus
          : (String(payload.catatan || '').trim() ? 'Catatan tindak lanjut diperbarui' : 'Data tindak lanjut diperbarui');
        sheet.getRange(i + 1, statusCol + 1).setValue(nextStatus === 'Diselesaikan' ? 'Sudah' : 'Belum');
        sheet.getRange(i + 1, status8Col).setValue(status8);
        sheet.getRange(i + 1, readCol).setValue('Sudah Dibaca');
        sheet.getRange(i + 1, statusUpdatedCol).setValue(new Date());
        sheet.getRange(i + 1, statusUpdatedByCol).setValue(payload.adminUsername);
        if (rejectionCol > 0) sheet.getRange(i + 1, rejectionCol).setValue(nextStatus === 'Ditolak' ? sheetText_(String(payload.catatan || '')) : '');
        sheet.getRange(i + 1, catatanColNumber).setValue(sheetText_(payload.catatan));
        sheet.getRange(i + 1, tanggalColNumber).setValue(nextStatus === 'Diselesaikan' ? new Date() : '');
        if (adminColNumber > 0) sheet.getRange(i + 1, adminColNumber).setValue(nextStatus === 'Diselesaikan' ? payload.adminUsername : '');
        if (payload.foto) {
          validateFilePayload_(payload.foto, false);
          const fotoLink = uploadFileToDrive_(payload.foto, targetId + '_TL', 'Teras Tower 2 - Foto Tindak Lanjut');
          sheet.getRange(i + 1, fotoTlColNumber).setValue(fotoLink);
        }
        sheet.getRange(i + 1, lastUpdatedCol).setValue(new Date());
        sheet.getRange(i + 1, lastUpdatedByCol).setValue(payload.adminUsername);
        sheet.getRange(i + 1, lastUpdateTypeCol).setValue(updateType);
        writeAuditLog_('UPDATE_TINDAK_LANJUT', payload.adminUsername, targetId, updateType);
        // v12: kabari warga pengirim hanya bila statusnya benar-benar berubah.
        const ownerCol = headers.indexOf('Username');
        const owner = ownerCol >= 0 ? String(values[i][ownerCol] || '').trim() : '';
        // Bandingkan dengan StatusAspirasi lama (bukan kolom Sudah/Belum), dibaca sebelum diubah.
        const previousStatus8 = String(values[i][status8Col - 1] || '').trim();
        if (owner && previousStatus8 !== status8) {
          const pushBody = nextStatus === 'Diselesaikan' ? 'Aspirasi Anda telah diselesaikan pengurus.'
            : nextStatus === 'Ditolak' ? 'Aspirasi Anda tidak dapat ditindaklanjuti. Ketuk untuk melihat catatan pengurus.'
            : 'Aspirasi Anda sudah dibaca pengurus.';
          queuePush_({ usernames: [owner] }, { title: 'Aspirasi Anda diperbarui', body: pushBody, page: 'riwayat' });
        }
        // The update changes LastUpdatedAt, so invalidate the cached admin
        // notification summary before the client refreshes its badge.
        invalidateNotificationSummaryCache_(session.username);
        return { success: true };
      }
    }
    return { success: false, message: 'Data tidak ditemukan.' };
  } catch (err) {
    return { success: false, message: err.message };
  } finally {
    try { updateLock.releaseLock(); } catch (ignore) {}
  }
}

// ===================================================================
// NOMOR PENTING & DARURAT
// ===================================================================
function getNomorPenting() { return getSheetData_(SHEET_NOMORPENTING); }
function getNomorDarurat() { return getSheetData_(SHEET_NOMORDARURAT); }

function saveNomorPenting(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) return { success: false, message: 'Anda tidak memiliki akses admin.' };
  try {
    const input = Array.isArray(payload && payload.data) ? payload.data : [];
    if (input.length > 100) throw new Error('Maksimal 100 nomor penting.');
    const rows = input.map(function (item) {
      return [sheetText_(validateString_(item && item.nama, 'Nama kontak', 1, 120)), sheetText_(validateString_(item && item.nomor, 'Nomor kontak', 1, 250))];
    });
    return withScriptLock_(function () {
      const sheet = getSheet_(SHEET_NOMORPENTING);
      const lastRow = sheet.getLastRow();
      if (lastRow > 1) sheet.getRange(2, 1, lastRow - 1, 2).clearContent();
      if (rows.length) sheet.getRange(2, 1, rows.length, 2).setValues(rows);
      writeAuditLog_('UPDATE_NOMOR_PENTING', session.username, SHEET_NOMORPENTING, 'rows=' + rows.length);
      return { success: true };
    });
  } catch (err) { return { success: false, message: err.message }; }
}

function saveNomorDarurat(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) return { success: false, message: 'Anda tidak memiliki akses admin.' };
  try {
    const input = Array.isArray(payload && payload.data) ? payload.data : [];
    if (input.length > 100) throw new Error('Maksimal 100 nomor darurat.');
    const rows = input.map(function (item) {
      const kategori = validateString_(item && item.kategori, 'Kategori kontak', 1, 80);
      return [sheetText_(kategori), sheetText_(validateString_(item && item.nama, 'Nama kontak', 1, 120)), sheetText_(validateString_(item && item.nomor, 'Nomor kontak', 1, 250))];
    });
    return withScriptLock_(function () {
      const sheet = getSheet_(SHEET_NOMORDARURAT);
      const lastRow = sheet.getLastRow();
      if (lastRow > 1) sheet.getRange(2, 1, lastRow - 1, 3).clearContent();
      if (rows.length) sheet.getRange(2, 1, rows.length, 3).setValues(rows);
      writeAuditLog_('UPDATE_NOMOR_DARURAT', session.username, SHEET_NOMORDARURAT, 'rows=' + rows.length);
      return { success: true };
    });
  } catch (err) { return { success: false, message: err.message }; }
}

// ===================================================================
// KELOLA ADMIN (HANYA SUPERADMIN)
// ===================================================================
function getAllAdmins(requesterUsername, sessionToken) {
  const requester = requireSession_(sessionToken, ['super_admin']);
  requesterUsername = requester.username;
  if (!isSuperAdmin_(requesterUsername)) {
    return { authorized: false, data: [] };
  }
  const data = getSheetData_(SHEET_ADMINS);
  // The admin-management page only needs identity and description, not PINs.
  const safeData = data.filter(function (row) { return !isSuperAdmin_(String(row.Username || '')); }).map(function (row) {
    return { Username: row.Username || '', Keterangan: row.Keterangan || '' };
  });
  return { authorized: true, data: safeData };
}

function addAdmin(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['super_admin']);
  payload.adminUsername = session.username;
  if (!isSuperAdmin_(payload.adminUsername)) {
    return { success: false, message: 'Hanya SuperAdmin yang dapat menambah admin.' };
  }
  const username = String(payload.username || '').trim().toLowerCase();
  const pin = String(payload.pin || '').trim();
  const keterangan = String(payload.keterangan || '').trim();

  if (!/^[a-z0-9][a-z0-9_.@+-]{2,79}$/.test(username)) return { success: false, message: 'Username Admin tidak valid.' };
  if (keterangan.length > 120) return { success: false, message: 'Keterangan maksimal 120 karakter.' };
  if (!username || !pin) {
    return { success: false, message: 'Username/Email dan PIN wajib diisi.' };
  }
  if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
    return { success: false, message: 'PIN harus 6 digit angka.' };
  }

  try {
    const pinHash = makePinHash_(pin);
    return withScriptLock_(function () {
      const existing = getSheetData_(SHEET_ADMINS);
      if (existing.some(function (row) { return row.Username && String(row.Username).toLowerCase() === username.toLowerCase(); })) {
        return { success: false, message: 'Username tersebut sudah terdaftar sebagai admin.' };
      }
      const sheet = getSheet_(SHEET_ADMINS);
      const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
      const newRow = headers.map(function (h) {
        if (h === 'Username') return sheetText_(username);
        if (h === 'PIN') return pinHash;
        if (h === 'Keterangan') return sheetText_(keterangan);
        return '';
      });
      sheet.appendRow(newRow);
      bumpSessionVersion_(username);
      writeAuditLog_('ADD_ADMIN', payload.adminUsername, username, keterangan);
      return { success: true };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function removeAdmin(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['super_admin']);
  const adminUsername = session.username;
  if (!isSuperAdmin_(adminUsername)) return { success: false, message: 'Hanya SuperAdmin yang dapat menghapus admin.' };
  const target = String(payload && payload.username || '').trim();
  if (!target) return { success: false, message: 'Username admin tidak valid.' };
  try {
    return withScriptLock_(function () {
      const sheet = getSheet_(SHEET_ADMINS);
      const values = sheet.getDataRange().getValues();
      const headers = values[0] || [];
      const usernameCol = headers.indexOf('Username');
      if (usernameCol < 0) return { success: false, message: 'Kolom Username tidak ditemukan.' };
      let removed = false;
      for (let i = values.length - 1; i >= 1; i--) {
        if (String(values[i][usernameCol] || '').toLowerCase() === target.toLowerCase()) {
          sheet.deleteRow(i + 1);
          removed = true;
        }
      }
      if (removed) {
        bumpSessionVersion_(target);
        writeAuditLog_('REMOVE_ADMIN', adminUsername, target, 'Dari Kelola Admin; sesi dicabut');
      }
      return { success: true, removed: removed };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}

// ===================================================================
// KUSTOMISASI (FIXED - with bgImage upload support)
// ===================================================================
function updateSystemConfig(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) {
    return { success: false, message: 'Anda tidak memiliki akses admin.' };
  }
  try {
    return withScriptLock_(function () {
      const cfg = payload.config || {};

      // Upload background image (jika ada) -> file publik agar bisa dipakai sebagai gambar
      let bgImageUrl = '';
      if (payload.bgImage) {
        validateFilePayload_(payload.bgImage, true);
        bgImageUrl = uploadPublicImage_(payload.bgImage, 'bg_' + Date.now(), 'Teras Tower 2 - Background Images');
        cfg.BackgroundImage = bgImageUrl;
      }

      const color = String(cfg.PrimaryColor || '').trim();
      if (color && !/^#[0-9a-fA-F]{6}$/.test(color)) throw new Error('Warna utama harus berformat #RRGGBB.');
      const bg = String(cfg.BackgroundImage || '').trim();
      if (bg && !/^https:\/\/[^\s"'()<>\\]+$/i.test(bg)) {
        throw new Error('URL background harus diawali https:// dan tidak boleh mengandung spasi atau tanda kutip.');
      }

      // upsert: baris dibuat otomatis kalau belum ada di sheet SystemConfig
      if (color) upsertSystemConfigValue_('PrimaryColor', color);
      upsertSystemConfigValue_('BackgroundImage', bg);
      writeAuditLog_('UPDATE_THEME', session.username, 'SystemConfig', 'Warna/background diperbarui');

      const result = { success: true };
      if (bgImageUrl) result.bgImageUrl = bgImageUrl;
      return result;
    });
  } catch (err) {
    writeApplicationError_('updateSystemConfig', err, session.username);
    return { success: false, message: err.message };
  }
}

// ===================================================================
// BANNER CAROUSEL (Beranda)
// Disimpan sebagai JSON di SystemConfig, key = BannerList
// ===================================================================
function uploadPublicImage_(fileObj, id, folderName) {
  const folder = getManagedDriveFolder_(folderName);
  const decoded = Utilities.base64Decode(fileObj.base64);
  const blob = Utilities.newBlob(decoded, fileObj.mimeType, id + '_' + fileObj.fileName);
  const file = folder.createFile(blob);
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (e) {
    file.setTrashed(true);
    throw new Error('Drive tidak mengizinkan berbagi publik untuk banner (kebijakan akun/Workspace).');
  }
  return 'https://lh3.googleusercontent.com/d/' + file.getId();
}

function upsertSystemConfigValue_(key, value) {
  const sheet = getSheet_(SHEET_SYSTEMCONFIG);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const keyCol = headers.indexOf('KEY');
  const valCol = headers.indexOf('VALUE');
  if (keyCol < 0 || valCol < 0) throw new Error('Sheet SystemConfig harus memiliki kolom KEY dan VALUE.');
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][keyCol]) === key) { sheet.getRange(i + 1, valCol + 1).setValue(value); return; }
  }
  const row = new Array(headers.length).fill('');
  row[keyCol] = key;
  row[valCol] = value;
  sheet.appendRow(row);
}

function saveBanners(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) return { success: false, message: 'Anda tidak memiliki akses admin.' };
  try {
    return withScriptLock_(function () {
      const items = Array.isArray(payload.banners) ? payload.banners : [];
      if (items.length > BANNER_MAX) throw new Error('Maksimal ' + BANNER_MAX + ' banner.');
      const saved = items.map(function (item, i) {
        let url = String(item.url || '');
        const id = 'b' + Date.now().toString(36) + i;
        if (item.upload) {
          validateFilePayload_(item.upload, true);
          url = uploadPublicImage_(item.upload, id, BANNER_FOLDER);
        } else if (!/^https:\/\/lh3\.googleusercontent\.com\/d\/[A-Za-z0-9_-]+$/.test(url)) {
          throw new Error('URL banner ke-' + (i + 1) + ' tidak valid.');
        }
        const link = String(item.link || '').trim();
        if (link && !/^https?:\/\/[^\s<>"'\\]+$/i.test(link)) {
          throw new Error('Link banner ke-' + (i + 1) + ' harus diawali http:// atau https://');
        }
        return { id: id, url: url, link: link.substring(0, 500), aktif: item.aktif !== false };
      });
      const json = JSON.stringify(saved);
      upsertSystemConfigValue_(BANNER_CONFIG_KEY, json);
      writeAuditLog_('UPDATE_BANNERS', session.username, 'SystemConfig', saved.length + ' banner');
      return { success: true, bannerList: json };
    });
  } catch (err) {
    writeApplicationError_('saveBanners', err, session.username);
    return { success: false, message: err.message };
  }
}

// ===================================================================
// MASUKAN PENGEMBANGAN APLIKASI
// ===================================================================
function getAppFeedbackSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_APPFEEDBACK);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_APPFEEDBACK);
    sheet.appendRow(['Timestamp', 'Username', 'Nama', 'Kategori', 'Masukan', 'Status', 'Catatan Admin', 'UpdatedAt', 'UpdatedBy', 'Dibaca']);
  } else {
    const lastColumn = Math.max(sheet.getLastColumn(), 1);
    const headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0].map(String);
    if (headers.indexOf('Dibaca') < 0) {
      const readCol = lastColumn + 1;
      sheet.getRange(1, readCol).setValue('Dibaca');
      if (sheet.getLastRow() > 1) sheet.getRange(2, readCol, sheet.getLastRow() - 1, 1).setValue('Sudah Dibaca');
    }
  }
  return sheet;
}

function submitAppFeedback(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident']);
  const kategori = validateString_(payload && payload.kategori, 'Kategori', 1, 40);
  const masukan = validateString_(payload && payload.masukan, 'Masukan', 10, 1000);
  const nama = String(payload && payload.nama || '').trim().substring(0, 120);
  const sheet = getAppFeedbackSheet_();
  sheet.appendRow([new Date(), sheetText_(session.username), sheetText_(nama), sheetText_(kategori), sheetText_(masukan), 'Dipertimbangkan', '', new Date(), sheetText_(session.username), 'Belum Dibaca']);
  return { success: true };
}

function getAppFeedback(sessionToken) {
  const session = requireSession_(sessionToken, ['super_admin']);
  const sheet = getAppFeedbackSheet_();
  const rows = getSheetData_(SHEET_APPFEEDBACK);
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const readCol = headers.indexOf('Dibaca');
  const data = rows.map(function (row, index) {
    const unread = String(row.Dibaca || 'Belum Dibaca') !== 'Sudah Dibaca';
    return {
      timestamp: formatTanggal_(row.Timestamp),
      username: String(row.Username || ''),
      nama: String(row.Nama || ''),
      kategori: String(row.Kategori || ''),
      masukan: String(row.Masukan || ''),
      status: String(row.Status || 'Dipertimbangkan'),
      catatanAdmin: String(row['Catatan Admin'] || ''),
      unread: unread,
      rowNumber: index + 2
    };
  });
  return { authorized: true, data: data.reverse() };
}

function markAppFeedbackSeen(sessionToken) {
  requireSession_(sessionToken, ['super_admin']);
  const sheet = getAppFeedbackSheet_();
  const headers = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0].map(String);
  const readCol = headers.indexOf('Dibaca');
  const rows = Math.max(0, sheet.getLastRow() - 1);
  if (readCol >= 0 && rows > 0) sheet.getRange(2, readCol + 1, rows, 1).setValues(Array.from({ length: rows }, function () { return ['Sudah Dibaca']; }));
  return { success: true, marked: rows };
}

function updateAppFeedback(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['super_admin']);
  const rowNumber = Number(payload && payload.rowNumber);
  const status = validateString_(payload && payload.status, 'Status', 1, 30);
  const catatan = sheetText_(String(payload && payload.catatanAdmin || '').trim().substring(0, 500));
  if (!Number.isInteger(rowNumber) || rowNumber < 2) return { success: false, message: 'Baris masukan tidak valid.' };
  return withScriptLock_(function () {
    const sheet = getAppFeedbackSheet_();
    if (rowNumber > sheet.getLastRow()) return { success: false, message: 'Masukan tidak ditemukan.' };
    const headers = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0];
    const usernameCol = headers.indexOf('Username');
    const feedbackOwner = usernameCol >= 0 ? String(sheet.getRange(rowNumber, usernameCol + 1).getValue() || '') : '';
    if (['Dipertimbangkan', 'Diterapkan', 'Ditolak'].indexOf(status) < 0) return { success: false, message: 'Status masukan tidak valid.' };
    const statusCol = headers.indexOf('Status');
    const noteCol = headers.indexOf('Catatan Admin');
    const updatedAtCol = headers.indexOf('UpdatedAt');
    const updatedByCol = headers.indexOf('UpdatedBy');
    if (statusCol < 0 || noteCol < 0) return { success: false, message: 'Struktur sheet AppFeedback belum lengkap.' };
    sheet.getRange(rowNumber, statusCol + 1).setValue(status);
    sheet.getRange(rowNumber, noteCol + 1).setValue(catatan);
    if (updatedAtCol >= 0) sheet.getRange(rowNumber, updatedAtCol + 1).setValue(new Date());
    if (updatedByCol >= 0) sheet.getRange(rowNumber, updatedByCol + 1).setValue(session.username);
    writeAuditLog_('UPDATE_APP_FEEDBACK', session.username, String(rowNumber), status);
    invalidateNotificationSummaryCache_(feedbackOwner);
    return { success: true };
  });
}

// ===================================================================
// KEPUASAN LAYANAN (NEW)
// ===================================================================

function getMingguIni_() {
  const now = new Date();
  const day = now.getDay(); // 0=Minggu, 1=Senin...
  const diff = now.getDate() - day;
  const mingguStart = new Date(now);
  mingguStart.setDate(diff);
  mingguStart.setHours(0, 0, 0, 0);
  return mingguStart;
}

function isSameMinggu_(date1, date2) {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);
  const day1 = d1.getDay();
  const day2 = d2.getDay();
  const start1 = new Date(d1);
  start1.setDate(d1.getDate() - day1);
  const start2 = new Date(d2);
  start2.setDate(d2.getDate() - day2);
  return start1.getTime() === start2.getTime();
}

function getKepuasanData_() {
  try {
    return getSheetData_(SHEET_KEPUASAN);
  } catch (e) {
    return [];
  }
}

function getRekapKepuasan() {
  const data = getKepuasanData_();
  const result = {};
  KATEGORI_KEPUASAN.forEach(function (kat) {
    const items = data.filter(function (row) { return row.Kategori === kat; });
    const total = items.reduce(function (sum, row) { return sum + (Number(row.Skor) || 0); }, 0);
    result[kat] = items.length > 0 ? total / items.length : 0;
  });
  // Rata-rata global
  const allSkor = data.map(function (row) { return Number(row.Skor) || 0; });
  result.global = allSkor.length > 0 ? allSkor.reduce(function (a, b) { return a + b; }, 0) / allSkor.length : 0;
  result.jumlahResponden = [...new Set(data.map(function (row) { return row.Username; }))].length;
  return result;
}

function getMyKepuasanThisWeek(username, sessionToken) {
  const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  username = session.username;
  const data = getKepuasanData_();
  const now = new Date();
  return data.filter(function (row) {
    return String(row.Username || '').toLowerCase() === username.toLowerCase() &&
      isSameMinggu_(row.TimeStamp, now);
  }).map(function (row) { return row.Kategori; });
}

function submitKepuasan(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  try {
    const kategori = String(payload && payload.kategori || '').trim();
    const skor = Number(payload && payload.skor);
    const komentar = String(payload && payload.komentar || '').trim();
    if (KATEGORI_KEPUASAN.indexOf(kategori) < 0) throw new Error('Kategori kepuasan tidak valid.');
    if (!Number.isFinite(skor) || skor < 0 || skor > 100) throw new Error('Skor harus antara 0-100.');
    if (komentar.length > 1000) throw new Error('Komentar maksimal 1000 karakter.');
    return withScriptLock_(function () {
      const alreadySubmitted = getKepuasanData_().some(function (row) {
        return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase() &&
          row.Kategori === kategori && isSameMinggu_(row.TimeStamp, new Date());
      });
      if (alreadySubmitted) return { success: false, message: 'Anda sudah memberikan penilaian untuk ' + kategori + ' minggu ini. Silakan coba lagi minggu depan.' };
      const sheet = getSheet_(SHEET_KEPUASAN);
      sheet.appendRow([new Date(), sheetText_(session.username), sheetText_(kategori), skor, sheetText_(komentar)]);
      if (session.role !== 'resident') writeAuditLog_('UPDATE_KEPUASAN', session.username, kategori, 'Penilaian kepuasan diperbarui');
      return { success: true };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}
function getAllKepuasanAdmin(requesterUsername, sessionToken) {
  const requester = requireSession_(sessionToken, ['admin', 'super_admin']);
  requesterUsername = requester.username;
  if (!isAdminUsername_(requesterUsername)) {
    return { authorized: false, data: [], rekap: {} };
  }
  const data = getKepuasanData_();
  const rekap = getRekapKepuasan();
  // Masking nama: huruf pertama + bintang + huruf terakhir
  const masked = data.map(function (row) {
    const name = String(row.Username || '');
    let maskedName = name;
    if (name.length > 2) {
      maskedName = name.charAt(0) + '*'.repeat(name.length - 2) + name.charAt(name.length - 1);
    } else if (name.length === 2) {
      maskedName = name.charAt(0) + '*';
    }
    return {
      timestamp: formatTanggal_(row.TimeStamp),
      username: maskedName,
      kategori: row.Kategori,
      skor: Number(row.Skor) || 0,
      skorSkala5: ((Number(row.Skor) || 0) / 20).toFixed(2),
      komentar: row.Komentar || ''
    };
  });
  return { authorized: true, data: masked, rekap: rekap };
}

// ===================================================================
// TEST
// ===================================================================
function testKoneksi_() {
  Logger.log('--- Test AppInfo ---');
  Logger.log(getSheetData_(SHEET_APPINFO));
  Logger.log('--- Test RefData ---');
  Logger.log(getSheetData_(SHEET_REFDATA));
  Logger.log('--- Test Admins ---');
  Logger.log(getSheetData_(SHEET_ADMINS));
  Logger.log('--- Test Data Aspirasi ---');
  Logger.log(getSheetData_(SHEET_DATA));
  Logger.log('--- Test SystemConfig ---');
  Logger.log(getSheetData_(SHEET_SYSTEMCONFIG));
  Logger.log('--- Test Warga ---');
  Logger.log(getSheetData_(SHEET_WARGA));
  Logger.log('--- Test Kepuasan ---');
  Logger.log(getSheetData_(SHEET_KEPUASAN));
}

function getKontakData() {
  return {
    nomorPenting: getNomorPenting(),
    nomorDarurat: getNomorDarurat()
  };
}

// ===================================================================
// KALENDER KERJA — hanya agenda disimpan; grid kalender dan jam berjalan
// dirender di klien. Waktu server dipakai sebagai acuan Asia/Jakarta.
// ===================================================================
function getAppClock(sessionToken) {
  requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  const now = new Date();
  return {
    epochMs: now.getTime(),
    timeZone: 'Asia/Jakarta',
    today: Utilities.formatDate(now, 'Asia/Jakarta', 'yyyy-MM-dd')
  };
}

function getAgendaSheet_() {
  const headers = ['ID', 'Tanggal', 'JamMulai', 'JamSelesai', 'Judul', 'Lokasi', 'Detail', 'StatusAgenda', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
  return withScriptLock_(function () {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_AGENDA);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_AGENDA);
      sheet.appendRow(headers);
      return sheet;
    }
    headers.forEach(function (header) { ensureSheetColumn_(sheet, header); });
    return sheet;
  });
}

function agendaSpreadsheetTimeZone_() {
  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    return spreadsheet && typeof spreadsheet.getSpreadsheetTimeZone === 'function'
      ? (spreadsheet.getSpreadsheetTimeZone() || 'Asia/Jakarta')
      : 'Asia/Jakarta';
  } catch (ignore) { return 'Asia/Jakarta'; }
}
function agendaDateKey_(value) {
  if (!value) return '';
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) {
    // Legacy sheet cells may have been auto-parsed using the Spreadsheet's
    // timezone. Format in that same timezone to preserve the entered date.
    return Utilities.formatDate(value, agendaSpreadsheetTimeZone_(), 'yyyy-MM-dd');
  }
  const text = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
  const parsed = new Date(text);
  return isNaN(parsed.getTime()) ? '' : Utilities.formatDate(parsed, agendaSpreadsheetTimeZone_(), 'yyyy-MM-dd');
}
function agendaTimeKey_(value) {
  if (!value) return '';
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) {
    // Legacy time cells may be Date objects at midnight in the sheet's zone.
    return Utilities.formatDate(value, agendaSpreadsheetTimeZone_(), 'HH:mm');
  }
  const text = String(value).trim();
  const match = text.match(/(?:^|\s)(\d{1,2}):(\d{2})(?::\d{2})?/);
  return match ? ('0' + match[1]).slice(-2) + ':' + match[2] : '';
}

function writeAgendaRow_(sheet, headers, row, existingRowNumber) {
  const rowNumber = existingRowNumber || Math.max(sheet.getLastRow() + 1, 2);
  if (rowNumber > sheet.getMaxRows()) sheet.insertRowsAfter(sheet.getMaxRows(), rowNumber - sheet.getMaxRows());
  ['Tanggal', 'JamMulai', 'JamSelesai'].forEach(function (header) {
    const col = headers.indexOf(header) + 1;
    if (col > 0) sheet.getRange(rowNumber, col).setNumberFormat('@');
  });
  sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  return rowNumber;
}

function isValidAgendaDate_(value) {
  const text = String(value || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
  const parts = text.split('-').map(Number);
  if (parts[0] < 2000 || parts[0] > 2100) return false;
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  return date.getUTCFullYear() === parts[0] && date.getUTCMonth() === parts[1] - 1 && date.getUTCDate() === parts[2];
}

function agendaMonthCacheKey_(year, month, isAdmin) {
  return 'tower-agenda-v3:' + year + '-' + ('0' + month).slice(-2) + ':' + (isAdmin ? 'admin' : 'public');
}
function invalidateAgendaCacheForDate_(dateValue) {
  const date = agendaDateKey_(dateValue);
  if (!date) return;
  const parts = date.split('-');
  const year = Number(parts[0]), month = Number(parts[1]);
  const cache = CacheService.getScriptCache();
  cache.remove(agendaMonthCacheKey_(year, month, false));
  cache.remove(agendaMonthCacheKey_(year, month, true));
}

function getAgendaCalendar(sessionToken, yearValue, monthValue) {
  const session = requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  const agendaSheet = getSheet_(SHEET_AGENDA);
  const now = new Date();
  let year, month;
  if ((yearValue === null || yearValue === undefined || yearValue === '') && (monthValue === null || monthValue === undefined || monthValue === '')) {
    const current = Utilities.formatDate(now, 'Asia/Jakarta', 'yyyy-MM').split('-');
    year = Number(current[0]); month = Number(current[1]);
  } else {
    year = Number(yearValue); month = Number(monthValue);
    if (!Number.isInteger(year) || year < 2000 || year > 2100 || !Number.isInteger(month) || month < 1 || month > 12) throw new Error('Bulan kalender tidak valid.');
  }
  const monthKey = String(year) + '-' + ('0' + month).slice(-2);
  const isAdmin = session.role === 'admin' || session.role === 'super_admin';
  const cache = CacheService.getScriptCache();
  const cacheKey = agendaMonthCacheKey_(year, month, isAdmin);
  let events = null;
  const cached = cache.get(cacheKey);
  if (cached) {
    try { const parsed = JSON.parse(cached); if (Array.isArray(parsed)) events = parsed; } catch (ignore) {}
  }
  if (!events) {
    events = (agendaSheet ? getSheetData_(SHEET_AGENDA) : []).map(function (row) {
      const date = agendaDateKey_(row.Tanggal);
      const active = String(row.StatusAgenda || 'Aktif') !== 'Diarsipkan';
      return {
        id: String(row.ID || ''), date: date, startTime: agendaTimeKey_(row.JamMulai), endTime: agendaTimeKey_(row.JamSelesai),
        title: String(row.Judul || ''), location: String(row.Lokasi || ''), detail: String(row.Detail || ''), active: active
      };
    }).filter(function (event) {
      return event.id && event.date.indexOf(monthKey) === 0 && event.active;
    }).sort(function (a, b) {
      return a.date.localeCompare(b.date) || a.startTime.localeCompare(b.startTime) || a.title.localeCompare(b.title);
    });
    try { cache.put(cacheKey, JSON.stringify(events), 60); } catch (ignore) {}
  }
  return {
    success: true, year: year, month: month, monthKey: monthKey, events: events,
    isAdmin: isAdmin, serverTimeMs: now.getTime(), serverToday: Utilities.formatDate(now, 'Asia/Jakarta', 'yyyy-MM-dd'), timeZone: 'Asia/Jakarta'
  };
}

function saveAgenda(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  payload = payload || {};
  const id = String(payload.id || '').trim();
  const date = String(payload.date || '').trim();
  const startTime = String(payload.startTime || '').trim();
  const endTime = String(payload.endTime || '').trim();
  const title = validateString_(payload.title, 'Judul agenda', 1, 120);
  const location = String(payload.location || '').trim();
  const detail = String(payload.detail || '').trim();
  if (id.length > 80) return { success: false, message: 'ID agenda tidak valid.' };
  if (!isValidAgendaDate_(date)) return { success: false, message: 'Tanggal agenda tidak valid.' };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) return { success: false, message: 'Jam mulai harus diisi dengan format HH:mm.' };
  if (endTime && !/^([01]\d|2[0-3]):[0-5]\d$/.test(endTime)) return { success: false, message: 'Jam selesai tidak valid.' };
  if (endTime && endTime <= startTime) return { success: false, message: 'Jam selesai harus setelah jam mulai pada tanggal yang sama.' };
  if (location.length > 120 || detail.length > 1200) return { success: false, message: 'Lokasi atau rincian agenda melebihi batas karakter.' };
  const sheet = getAgendaSheet_();
  return withScriptLock_(function () {
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
    const sheetValues = sheet.getDataRange().getValues();
    const idCol = headers.indexOf('ID');
    let index = -1;
    if (id && idCol >= 0) {
      for (let i = 1; i < sheetValues.length; i++) if (String(sheetValues[i][idCol] || '') === id) { index = i - 1; break; }
    }
    if (id && index < 0) return { success: false, message: 'Agenda tidak ditemukan.' };
    const existing = {};
    if (index >= 0) headers.forEach(function (header, col) { existing[header] = sheetValues[index + 1][col]; });
    const eventId = id || Utilities.getUuid();
    const now = new Date();
    const rowData = {
      ID: eventId, Tanggal: sheetText_(date), JamMulai: sheetText_(startTime), JamSelesai: sheetText_(endTime),
      Judul: sheetText_(title), Lokasi: sheetText_(location), Detail: sheetText_(detail),
      StatusAgenda: String(existing.StatusAgenda || 'Aktif'),
      CreatedAt: existing.CreatedAt || now, CreatedBy: existing.CreatedBy || sheetText_(session.username),
      UpdatedAt: now, UpdatedBy: sheetText_(session.username)
    };
    const row = headers.map(function (header) {
      return Object.prototype.hasOwnProperty.call(rowData, header) ? rowData[header] : (existing[header] === undefined ? '' : existing[header]);
    });
    writeAgendaRow_(sheet, headers, row, index >= 0 ? index + 2 : null);
    if (index >= 0) invalidateAgendaCacheForDate_(existing.Tanggal);
    invalidateAgendaCacheForDate_(date);
    writeAuditLog_(id ? 'UPDATE_TOWER_AGENDA' : 'CREATE_TOWER_AGENDA', session.username, eventId, title);
    if (!id) queuePush_({ all: true }, { title: 'Agenda baru Tower 2', body: title + ' — ' + formatAgendaDateForPush_(date, startTime), page: 'kalenderKerja' });
    return { success: true, id: eventId, message: id ? 'Agenda berhasil diperbarui.' : 'Agenda berhasil ditambahkan.' };
  });
}

function setAgendaActive(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  const id = String(payload && payload.id || '').trim();
  const active = payload && payload.active === true;
  if (!id || id.length > 80) return { success: false, message: 'ID agenda tidak valid.' };
  const sheet = getAgendaSheet_();
  return withScriptLock_(function () {
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
    const values = sheet.getDataRange().getValues();
    const idCol = headers.indexOf('ID');
    const dateCol = headers.indexOf('Tanggal');
    let rowNumber = -1;
    for (let i = 1; i < values.length; i++) if (String(values[i][idCol] || '') === id) { rowNumber = i + 1; break; }
    const index = rowNumber < 0 ? -1 : rowNumber - 2;
    if (index < 0) return { success: false, message: 'Agenda tidak ditemukan.' };
    const targetDate = values[rowNumber - 1][dateCol];
    const statusCol = headers.indexOf('StatusAgenda') + 1;
    const updatedAtCol = headers.indexOf('UpdatedAt') + 1;
    const updatedByCol = headers.indexOf('UpdatedBy') + 1;
    sheet.getRange(rowNumber, statusCol).setValue(active ? 'Aktif' : 'Diarsipkan');
    sheet.getRange(rowNumber, updatedAtCol).setValue(new Date());
    sheet.getRange(rowNumber, updatedByCol).setValue(sheetText_(session.username));
    invalidateAgendaCacheForDate_(targetDate);
    writeAuditLog_(active ? 'RESTORE_TOWER_AGENDA' : 'ARCHIVE_TOWER_AGENDA', session.username, id, active ? 'Aktif' : 'Diarsipkan');
    return { success: true, message: active ? 'Agenda dipulihkan.' : 'Agenda diarsipkan; riwayat tetap tersimpan.' };
  });
}

function getAgendaProposalSheet_() {
  const headers = ['ID', 'Timestamp', 'Username', 'Nama', 'Judul', 'Tanggal', 'JamMulai', 'JamSelesai', 'Lokasi', 'Detail', 'Status', 'CatatanReview', 'ReviewedAt', 'ReviewedBy', 'AgendaID'];
  return withScriptLock_(function () {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_AGENDA_PROPOSALS);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_AGENDA_PROPOSALS);
      sheet.appendRow(headers);
    } else {
      headers.forEach(function (header) { ensureSheetColumn_(sheet, header); });
    }
    return sheet;
  });
}

function submitAgendaProposal(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident']);
  payload = payload || {};
  const title = validateString_(payload.title, 'Judul agenda', 3, 120);
  const date = String(payload.date || '').trim();
  const startTime = String(payload.startTime || '').trim();
  const endTime = String(payload.endTime || '').trim();
  const location = String(payload.location || '').trim();
  const detail = String(payload.detail || '').trim();
  if (!isValidAgendaDate_(date)) return { success: false, message: 'Tanggal usulan tidak valid.' };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) return { success: false, message: 'Jam mulai harus diisi dengan format HH:mm.' };
  if (endTime && !/^([01]\d|2[0-3]):[0-5]\d$/.test(endTime)) return { success: false, message: 'Jam selesai tidak valid.' };
  if (endTime && endTime <= startTime) return { success: false, message: 'Jam selesai harus setelah jam mulai.' };
  if (location.length > 120 || detail.length > 1200) return { success: false, message: 'Lokasi atau rincian usulan melebihi batas karakter.' };
  const profile = getSheetData_(SHEET_WARGA).find(function (row) {
    return String(row.Username || '').toLowerCase() === String(session.username || '').toLowerCase();
  });
  if (!profile) return { success: false, message: 'Profil warga tidak ditemukan. Lengkapi profil terlebih dahulu.' };
  const name = validateString_(profile.Nama || session.username, 'Nama profil', 1, 120);
  const cache = CacheService.getScriptCache();
  const rateKey = 'agenda-proposal-rate:' + String(session.username || '').toLowerCase();
  if (cache.get(rateKey)) return { success: false, message: 'Tunggu sebentar sebelum mengirim usulan agenda berikutnya.' };
  const sheet = getAgendaProposalSheet_();
  return withScriptLock_(function () {
    if (cache.get(rateKey)) return { success: false, message: 'Tunggu sebentar sebelum mengirim usulan agenda berikutnya.' };
    const id = Utilities.getUuid();
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
    const proposalRecord = {
      ID: sheetText_(id), Timestamp: new Date(), Username: sheetText_(session.username), Nama: sheetText_(name), Judul: sheetText_(title),
      Tanggal: sheetText_(date), JamMulai: sheetText_(startTime), JamSelesai: sheetText_(endTime), Lokasi: sheetText_(location), Detail: sheetText_(detail),
      Status: 'Menunggu Verifikasi', CatatanReview: '', ReviewedAt: '', ReviewedBy: '', AgendaID: ''
    };
    writeAgendaRow_(sheet, headers, headers.map(function (header) { return Object.prototype.hasOwnProperty.call(proposalRecord, header) ? proposalRecord[header] : ''; }));
    cache.put(rateKey, '1', 20);
    writeAuditLog_('SUBMIT_AGENDA_PROPOSAL', session.username, id, title);
    return { success: true, id: id, message: 'Usulan agenda terkirim dan menunggu pemeriksaan Admin. Agenda belum tampil di kalender.' };
  });
}

function getAgendaManagementData(sessionToken) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  const agendaSheet = getSheet_(SHEET_AGENDA);
  const proposalSheet = getSheet_(SHEET_AGENDA_PROPOSALS);
  const agenda = (agendaSheet ? getSheetData_(SHEET_AGENDA) : []).map(function (row) {
    return {
      id: String(row.ID || ''), date: agendaDateKey_(row.Tanggal), startTime: agendaTimeKey_(row.JamMulai), endTime: agendaTimeKey_(row.JamSelesai),
      title: String(row.Judul || ''), location: String(row.Lokasi || ''), detail: String(row.Detail || ''), active: String(row.StatusAgenda || 'Aktif') !== 'Diarsipkan'
    };
  }).filter(function (item) { return !!item.id; }).sort(function (a, b) {
    return (a.active === b.active ? 0 : (a.active ? -1 : 1)) || a.date.localeCompare(b.date) || a.startTime.localeCompare(b.startTime);
  });
  const proposals = (proposalSheet ? getSheetData_(SHEET_AGENDA_PROPOSALS) : []).map(function (row) {
    return {
      id: String(row.ID || ''), username: String(row.Username || ''), name: String(row.Nama || ''), title: String(row.Judul || ''),
      date: agendaDateKey_(row.Tanggal), startTime: agendaTimeKey_(row.JamMulai), endTime: agendaTimeKey_(row.JamSelesai),
      location: String(row.Lokasi || ''), detail: String(row.Detail || ''), status: String(row.Status || 'Menunggu Verifikasi'),
      reviewNote: String(row.CatatanReview || ''), submittedAt: row.Timestamp ? formatTanggal_(row.Timestamp) : '',
      sortTime: row.Timestamp ? new Date(row.Timestamp).getTime() : 0
    };
  }).filter(function (item) { return !!item.id; }).sort(function (a, b) {
    return (a.status === b.status ? 0 : (a.status === 'Menunggu Verifikasi' ? -1 : 1)) || b.sortTime - a.sortTime;
  });
  proposals.forEach(function (item) { delete item.sortTime; });
  return {
    success: true, isSuperAdmin: session.role === 'super_admin', agenda: agenda, proposals: proposals,
    pendingCount: proposals.filter(function (item) { return item.status === 'Menunggu Verifikasi'; }).length
  };
}

function reviewAgendaProposal(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  payload = payload || {};
  const id = validateString_(payload.id, 'ID usulan', 1, 80);
  const decision = String(payload.decision || '').trim();
  const note = String(payload.note || '').trim();
  if (['approve', 'reject'].indexOf(decision) < 0) return { success: false, message: 'Keputusan usulan tidak valid.' };
  if (note.length > 500) return { success: false, message: 'Catatan pemeriksaan maksimal 500 karakter.' };
  const proposalSheet = getSheet_(SHEET_AGENDA_PROPOSALS);
  if (!proposalSheet) return { success: false, message: 'Usulan agenda tidak ditemukan.' };
  const agendaSheet = decision === 'approve' ? getAgendaSheet_() : null;
  return withScriptLock_(function () {
    const proposalHeaders = proposalSheet.getRange(1, 1, 1, proposalSheet.getLastColumn()).getValues()[0].map(String);
    const proposalValues = proposalSheet.getDataRange().getValues();
    const idCol = proposalHeaders.indexOf('ID');
    let rowNumber = -1;
    for (let i = 1; i < proposalValues.length; i++) if (String(proposalValues[i][idCol] || '') === id) { rowNumber = i + 1; break; }
    if (rowNumber < 0) return { success: false, message: 'Usulan agenda tidak ditemukan.' };
    const proposal = {};
    proposalHeaders.forEach(function (header, col) { proposal[header] = proposalValues[rowNumber - 1][col]; });
    if (String(proposal.Status || '') !== 'Menunggu Verifikasi') return { success: false, message: 'Usulan ini sudah pernah diperiksa.' };
    let agendaId = '';
    if (decision === 'approve') {
      const date = agendaDateKey_(proposal.Tanggal);
      const startTime = agendaTimeKey_(proposal.JamMulai);
      const endTime = agendaTimeKey_(proposal.JamSelesai);
      const title = validateString_(proposal.Judul, 'Judul agenda', 3, 120);
      if (!isValidAgendaDate_(date) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime) || (endTime && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(endTime) || endTime <= startTime))) {
        return { success: false, message: 'Data tanggal atau jam pada usulan tidak valid; agenda tidak dipublikasikan.' };
      }
      agendaId = 'proposal-' + id;
      const agendaHeaders = agendaSheet.getRange(1, 1, 1, agendaSheet.getLastColumn()).getValues()[0].map(String);
      const agendaIdCol = agendaHeaders.indexOf('ID');
      const agendaValues = agendaSheet.getDataRange().getValues();
      const alreadyPublished = agendaIdCol >= 0 && agendaValues.slice(1).some(function (row) { return String(row[agendaIdCol] || '') === agendaId; });
      if (!alreadyPublished) {
        const now = new Date();
        const agendaRecord = {
          ID: agendaId, Tanggal: sheetText_(date), JamMulai: sheetText_(startTime), JamSelesai: sheetText_(endTime),
          Judul: sheetText_(title), Lokasi: sheetText_(proposal.Lokasi || ''), Detail: sheetText_(proposal.Detail || ''), StatusAgenda: 'Aktif',
          CreatedAt: now, CreatedBy: sheetText_(session.username), UpdatedAt: now, UpdatedBy: sheetText_(session.username)
        };
        writeAgendaRow_(agendaSheet, agendaHeaders, agendaHeaders.map(function (header) {
          return Object.prototype.hasOwnProperty.call(agendaRecord, header) ? agendaRecord[header] : '';
        }));
      }
      invalidateAgendaCacheForDate_(date);
    }
    const statusCol = proposalHeaders.indexOf('Status') + 1;
    const noteCol = proposalHeaders.indexOf('CatatanReview') + 1;
    const reviewedAtCol = proposalHeaders.indexOf('ReviewedAt') + 1;
    const reviewedByCol = proposalHeaders.indexOf('ReviewedBy') + 1;
    const agendaIdCol = proposalHeaders.indexOf('AgendaID') + 1;
    proposalSheet.getRange(rowNumber, statusCol).setValue(decision === 'approve' ? 'Disetujui' : 'Ditolak');
    proposalSheet.getRange(rowNumber, noteCol).setValue(sheetText_(note));
    proposalSheet.getRange(rowNumber, reviewedAtCol).setValue(new Date());
    proposalSheet.getRange(rowNumber, reviewedByCol).setValue(sheetText_(session.username));
    if (agendaIdCol > 0) proposalSheet.getRange(rowNumber, agendaIdCol).setValue(agendaId);
    writeAuditLog_(decision === 'approve' ? 'APPROVE_AGENDA_PROPOSAL' : 'REJECT_AGENDA_PROPOSAL', session.username, id, note || String(proposal.Judul || ''));
    if (decision === 'approve') queuePush_({ all: true }, { title: 'Agenda baru Tower 2', body: String(proposal.Judul || '') + ' — ' + formatAgendaDateForPush_(agendaDateKey_(proposal.Tanggal), agendaTimeKey_(proposal.JamMulai)), page: 'kalenderKerja' });
    return { success: true, agendaId: agendaId, message: decision === 'approve' ? 'Usulan disetujui dan agenda sekarang tampil di kalender.' : 'Usulan agenda ditolak.' };
  });
}

// ===================================================================
// v12 — PEMBERSIHAN OTOMATIS AKUN YANG TIDAK DILENGKAPI
// -------------------------------------------------------------------
// • Akun warga yang profilnya belum lengkap 7 hari setelah daftar dihapus
//   otomatis setiap hari sekitar pukul 02.00 WIB.
// • Hari ke-5: pengingat lewat notifikasi push (bila warga memasang APK).
// • Sebelum dihapus, baris akun disalin utuh ke sheet tersembunyi
//   ArsipAkunDihapus, sehingga bisa dipulihkan manual bila keliru.
// • Akun Admin/SuperAdmin dan akun yang profilnya lengkap tidak pernah disentuh.
// • Akun lama tanpa tanggal daftar diberi tanggal saat pembersihan pertama
//   berjalan, jadi mereka tetap mendapat 7 hari penuh.
// • SystemConfig KEY "PembersihanAkun": aktif (bawaan) | uji (hanya mencatat,
//   tidak menghapus) | mati.
// Aktifkan sekali: jalankan fungsi aktifkanOtomatisasiTT2 dari editor Apps Script.
// ===================================================================
const WARGA_REGISTERED_COL = 'TerdaftarPada';
const WARGA_REMINDER_COL = 'PengingatProfil';
const SHEET_ACCOUNT_ARCHIVE = 'ArsipAkunDihapus';
const ACCOUNT_CLEANUP_DAYS = 7;
const ACCOUNT_REMINDER_DAYS = 5;
const DAY_MS_ = 24 * 60 * 60 * 1000;

function isProfileCompleteValue_(value) {
  return value === true || String(value || '').trim().toLowerCase() === 'true';
}

function getCleanupMode_() {
  const raw = String(getSystemConfig_().PembersihanAkun || '').trim().toLowerCase();
  if (raw === 'mati' || raw === 'off' || raw === 'false') return 'mati';
  if (raw === 'uji' || raw === 'test') return 'uji';
  return 'aktif';
}

// Batas waktu melengkapi profil (ISO) untuk ditampilkan saat login; '' bila tidak berlaku.
function getProfileDeadline_(userRow) {
  if (!userRow || isProfileCompleteValue_(userRow.ProfileComplete)) return '';
  if (getCleanupMode_() !== 'aktif') return '';
  const registered = new Date(userRow[WARGA_REGISTERED_COL]);
  if (!userRow[WARGA_REGISTERED_COL] || isNaN(registered.getTime())) return '';
  return new Date(registered.getTime() + ACCOUNT_CLEANUP_DAYS * DAY_MS_).toISOString();
}

function getAdminUsernameSet_() {
  const set = {};
  set[String(getSuperAdminConfig_().username || '').toLowerCase()] = true;
  const sheet = getSheet_(SHEET_ADMINS);
  if (sheet) {
    getSheetData_(SHEET_ADMINS).forEach(function (row) {
      if (row.Username) set[String(row.Username).toLowerCase()] = true;
    });
  }
  return set;
}

function getAccountArchiveSheet_(headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_ACCOUNT_ARCHIVE);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_ACCOUNT_ARCHIVE);
    sheet.getRange(1, 1, 1, headers.length + 2).setValues([['DihapusPada', 'Alasan'].concat(headers)]);
    sheet.setFrozenRows(1);
    try { sheet.hideSheet(); } catch (ignore) {}
  }
  return sheet;
}

// Inti pembersihan. options.now (ms) hanya untuk pengujian.
function runAccountCleanup_(options) {
  const mode = getCleanupMode_();
  const report = { mode: mode, stamped: 0, reminded: 0, deleted: [], wouldDelete: [] };
  if (mode === 'mati') return report;
  const now = (options && options.now) || Date.now();
  withScriptLock_(function () {
    const sheet = getSheet_(SHEET_WARGA);
    const registeredCol = ensureSheetColumn_(sheet, WARGA_REGISTERED_COL);
    const reminderCol = ensureSheetColumn_(sheet, WARGA_REMINDER_COL);
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const userCol = headers.indexOf('Username');
    const completeCol = headers.indexOf('ProfileComplete');
    if (userCol < 0 || completeCol < 0) throw new Error('Kolom Username/ProfileComplete tidak ditemukan di WargaBaru.');
    const admins = getAdminUsernameSet_();
    const toDelete = [];
    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = String(row[userCol] || '').trim();
      if (!username || admins[username.toLowerCase()] || isProfileCompleteValue_(row[completeCol])) continue;
      const registeredValue = row[registeredCol - 1];
      const registered = registeredValue ? new Date(registeredValue).getTime() : NaN;
      if (!registeredValue || isNaN(registered)) {
        sheet.getRange(i + 1, registeredCol).setValue(new Date(now));
        report.stamped++;
        continue;
      }
      const ageDays = (now - registered) / DAY_MS_;
      if (ageDays >= ACCOUNT_CLEANUP_DAYS) {
        toDelete.push({ rowNumber: i + 1, username: username, row: row });
      } else if (ageDays >= ACCOUNT_REMINDER_DAYS && !row[reminderCol - 1] && mode === 'aktif') {
        const deadline = new Date(registered + ACCOUNT_CLEANUP_DAYS * DAY_MS_);
        queuePush_({ usernames: [username] }, {
          title: 'Lengkapi profil Anda',
          body: 'Akun Teras Tower 2 Anda akan dihapus otomatis pada ' +
            Utilities.formatDate(deadline, 'Asia/Jakarta', 'dd/MM/yyyy') + ' bila profil belum dilengkapi.',
          page: 'profil'
        });
        sheet.getRange(i + 1, reminderCol).setValue(new Date(now));
        report.reminded++;
      }
    }
    if (mode === 'uji') {
      report.wouldDelete = toDelete.map(function (item) { return item.username; });
      if (toDelete.length) writeAuditLog_('CLEANUP_UJI', 'sistem', '', 'Akan dihapus: ' + report.wouldDelete.join(', '));
      return;
    }
    if (!toDelete.length) return;
    const archive = getAccountArchiveSheet_(values[0]);
    // Hapus dari baris paling bawah agar nomor baris di atasnya tidak bergeser.
    toDelete.sort(function (a, b) { return b.rowNumber - a.rowNumber; }).forEach(function (item) {
      archive.appendRow([new Date(now), 'Profil tidak dilengkapi dalam ' + ACCOUNT_CLEANUP_DAYS + ' hari'].concat(item.row));
      sheet.deleteRow(item.rowNumber);
      bumpSessionVersion_(item.username);
      removePushTokensForUser_(item.username);
      writeAuditLog_('CLEANUP_HAPUS_AKUN', 'sistem', item.username, 'Profil tidak dilengkapi dalam ' + ACCOUNT_CLEANUP_DAYS + ' hari');
      report.deleted.push(item.username);
    });
  });
  return report;
}

// Dipanggil pemicu harian. Aman bila terpanggil lebih dari sekali sehari: hasilnya sama.
function jalankanPembersihanAkunHarian() {
  try {
    const report = runAccountCleanup_();
    console.log('Pembersihan akun: ' + JSON.stringify(report));
    return report;
  } catch (err) {
    writeApplicationError_('jalankanPembersihanAkunHarian', err, 'sistem');
    throw err;
  }
}

// Jalankan SEKALI dari editor Apps Script (pilih fungsi ini lalu klik Jalankan).
// Membuat pemicu harian pembersihan akun dan sekaligus meminta izin yang
// dibutuhkan notifikasi push (akses ke layanan eksternal).
function aktifkanOtomatisasiTT2() {
  const handler = 'jalankanPembersihanAkunHarian';
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === handler) ScriptApp.deleteTrigger(trigger);
  });
  ScriptApp.newTrigger(handler).timeBased().everyDays(1).atHour(2).inTimezone('Asia/Jakarta').create();
  const fcm = getFcmConfig_();
  let fcmStatus = 'belum diatur (Script Property FCM_SERVICE_ACCOUNT kosong)';
  if (fcm) {
    try { getFcmAccessToken_(true); fcmStatus = 'tersambung ke proyek ' + fcm.project_id; }
    catch (err) { fcmStatus = 'GAGAL: ' + err.message; }
  }
  const message = 'Pemicu pembersihan harian aktif (sekitar 02.00 WIB), mode: ' + getCleanupMode_() + '. Notifikasi push: ' + fcmStatus + '.';
  console.log(message);
  return message;
}

// ===================================================================
// v12 — NOTIFIKASI PUSH (Firebase Cloud Messaging HTTP v1)
// -------------------------------------------------------------------
// • Token perangkat disimpan di sheet tersembunyi PushTokens.
// • Kunci service account Firebase disimpan di Script Properties dengan nama
//   FCM_SERVICE_ACCOUNT (isi file JSON utuh). Tidak pernah di repo/sheet.
//   Bila belum diatur, semua fungsi tetap berjalan; notifikasi tidak terkirim.
// • queuePush_ hanya mengantrekan; pengiriman terjadi setelah kunci skrip
//   dilepas (withScriptLock_) atau lewat flushPushQueue_.
// • Kegagalan kirim tidak pernah menggagalkan aksi utama (simpan aspirasi dll.).
// ===================================================================
const SHEET_PUSH_TOKENS = 'PushTokens';
const PUSH_TOKEN_HEADERS = ['Token', 'Username', 'Platform', 'UpdatedAt'];
const PUSH_MAX_TOKENS_PER_USER = 5;
const PUSH_CHANNEL_ID = 'tt2_umum';
let PUSH_QUEUE_ = [];
let PUSH_FLUSHING_ = false;

function getPushTokenSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_PUSH_TOKENS);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PUSH_TOKENS);
    sheet.getRange(1, 1, 1, PUSH_TOKEN_HEADERS.length).setValues([PUSH_TOKEN_HEADERS]);
    sheet.setFrozenRows(1);
    try { sheet.hideSheet(); } catch (ignore) {}
  }
  return sheet;
}

function readPushTokens_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PUSH_TOKENS);
  if (!sheet || sheet.getLastRow() < 2) return [];
  return sheet.getRange(2, 1, sheet.getLastRow() - 1, PUSH_TOKEN_HEADERS.length).getValues()
    .filter(function (row) { return row[0]; })
    .map(function (row) { return { token: String(row[0]), username: String(row[1] || ''), platform: String(row[2] || '') }; });
}

// Tanpa kunci: pemanggil yang menentukan (lihat catatan kunci bersarang di atas).
function removePushTokensWhere_(predicate) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PUSH_TOKENS);
  if (!sheet || sheet.getLastRow() < 2) return 0;
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, PUSH_TOKEN_HEADERS.length).getValues();
  let removed = 0;
  for (let i = values.length - 1; i >= 0; i--) {
    if (predicate(values[i])) { sheet.deleteRow(i + 2); removed++; }
  }
  return removed;
}
function removePushTokensForUser_(username) {
  const target = String(username || '').toLowerCase();
  if (!target) return 0;
  return removePushTokensWhere_(function (row) { return String(row[1] || '').toLowerCase() === target; });
}

function validatePushToken_(token) {
  const value = String(token || '').trim();
  if (value.length < 20 || value.length > 4096 || !/^[A-Za-z0-9:_\-]+$/.test(value)) throw new Error('Token notifikasi tidak valid.');
  return value;
}

// Dipanggil aplikasi setelah login & izin notifikasi diberikan.
function registerPushToken(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  const token = validatePushToken_(payload && payload.token);
  const platform = String(payload && payload.platform || 'android').toLowerCase() === 'ios' ? 'ios' : (String(payload && payload.platform || '').toLowerCase() === 'web' ? 'web' : 'android');
  return withScriptLock_(function () {
    const sheet = getPushTokenSheet_();
    // Satu perangkat = satu token. Bila perangkat dipakai akun lain, pemiliknya diganti.
    removePushTokensWhere_(function (row) { return String(row[0]) === token; });
    sheet.appendRow([token, sheetText_(session.username), platform, new Date()]);
    // Batasi jumlah perangkat per akun: hapus yang paling lama.
    const mine = readPushTokens_().filter(function (item) { return item.username.toLowerCase() === session.username.toLowerCase(); });
    if (mine.length > PUSH_MAX_TOKENS_PER_USER) {
      const drop = mine.slice(0, mine.length - PUSH_MAX_TOKENS_PER_USER).map(function (item) { return item.token; });
      removePushTokensWhere_(function (row) { return drop.indexOf(String(row[0])) >= 0; });
    }
    return { success: true };
  });
}

// Dipanggil aplikasi saat keluar, agar perangkat tidak menerima notifikasi akun itu lagi.
function unregisterPushToken(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['resident', 'admin', 'super_admin']);
  const token = validatePushToken_(payload && payload.token);
  return withScriptLock_(function () {
    removePushTokensWhere_(function (row) {
      return String(row[0]) === token && String(row[1] || '').toLowerCase() === session.username.toLowerCase();
    });
    return { success: true };
  });
}

// target: { all: true } | { admins: true } | { usernames: ['a','b'] }
// message: { title, body, page }
function queuePush_(target, message) {
  PUSH_QUEUE_.push({ target: target || {}, message: message || {} });
  if (SCRIPT_LOCK_DEPTH_ === 0) flushPushQueue_();
}

function getFcmConfig_() {
  const raw = PropertiesService.getScriptProperties().getProperty('FCM_SERVICE_ACCOUNT');
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed.client_email || !parsed.private_key || !parsed.project_id) return null;
    return parsed;
  } catch (err) { return null; }
}

function base64UrlJson_(value) {
  return Utilities.base64EncodeWebSafe(JSON.stringify(value)).replace(/=+$/, '');
}

// Token akses OAuth untuk FCM, disimpan di cache 50 menit (berlaku 60 menit).
function getFcmAccessToken_(forceRefresh) {
  const cache = CacheService.getScriptCache();
  if (!forceRefresh) {
    const cached = cache.get('fcm-access-token');
    if (cached) return cached;
  }
  const config = getFcmConfig_();
  if (!config) throw new Error('FCM_SERVICE_ACCOUNT belum diatur.');
  const nowSec = Math.floor(Date.now() / 1000);
  const tokenUri = config.token_uri || 'https://oauth2.googleapis.com/token';
  const unsigned = base64UrlJson_({ alg: 'RS256', typ: 'JWT' }) + '.' + base64UrlJson_({
    iss: config.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: tokenUri, iat: nowSec, exp: nowSec + 3600
  });
  const signature = Utilities.base64EncodeWebSafe(Utilities.computeRsaSha256Signature(unsigned, config.private_key)).replace(/=+$/, '');
  const response = UrlFetchApp.fetch(tokenUri, {
    method: 'post', muteHttpExceptions: true,
    payload: { grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: unsigned + '.' + signature }
  });
  if (response.getResponseCode() !== 200) throw new Error('Gagal mendapat token Firebase: HTTP ' + response.getResponseCode() + ' ' + response.getContentText().substring(0, 200));
  const accessToken = JSON.parse(response.getContentText()).access_token;
  cache.put('fcm-access-token', accessToken, 3000);
  return accessToken;
}

function resolvePushRecipients_(target, allTokens, adminSet) {
  if (target.all) return allTokens;
  if (target.admins) return allTokens.filter(function (item) { return adminSet[item.username.toLowerCase()]; });
  const wanted = {};
  (target.usernames || []).forEach(function (name) { wanted[String(name || '').toLowerCase()] = true; });
  return allTokens.filter(function (item) { return wanted[item.username.toLowerCase()]; });
}

function buildFcmMessage_(token, message) {
  const data = { page: String(message.page || 'beranda') };
  return {
    message: {
      token: token,
      notification: { title: String(message.title || 'Teras Tower 2').substring(0, 100), body: String(message.body || '').substring(0, 400) },
      data: data,
      android: { priority: 'HIGH', notification: { channel_id: PUSH_CHANNEL_ID, icon: 'ic_stat_tt2', color: '#0E9CBF' } },
      apns: { payload: { aps: { sound: 'default' } } }
    }
  };
}

// Mengirim semua notifikasi yang diantrekan. Tidak pernah melempar error.
function flushPushQueue_() {
  if (PUSH_FLUSHING_ || !PUSH_QUEUE_.length) return { sent: 0, failed: 0 };
  PUSH_FLUSHING_ = true;
  const queue = PUSH_QUEUE_;
  PUSH_QUEUE_ = [];
  const result = { sent: 0, failed: 0, removed: 0 };
  try {
    const config = getFcmConfig_();
    if (!config) return result;
    const allTokens = readPushTokens_();
    if (!allTokens.length) return result;
    const needsAdmins = queue.some(function (item) { return item.target.admins; });
    const adminSet = needsAdmins ? getAdminUsernameSet_() : {};
    const accessToken = getFcmAccessToken_();
    const url = 'https://fcm.googleapis.com/v1/projects/' + encodeURIComponent(config.project_id) + '/messages:send';
    const jobs = [];
    queue.forEach(function (item) {
      const seen = {};
      resolvePushRecipients_(item.target, allTokens, adminSet).forEach(function (recipient) {
        if (seen[recipient.token]) return;
        seen[recipient.token] = true;
        jobs.push({ token: recipient.token, body: buildFcmMessage_(recipient.token, item.message) });
      });
    });
    const invalid = [];
    for (let start = 0; start < jobs.length; start += 100) {
      const batch = jobs.slice(start, start + 100);
      const responses = UrlFetchApp.fetchAll(batch.map(function (job) {
        return { url: url, method: 'post', contentType: 'application/json', muteHttpExceptions: true,
          headers: { Authorization: 'Bearer ' + accessToken }, payload: JSON.stringify(job.body) };
      }));
      responses.forEach(function (response, index) {
        const code = response.getResponseCode();
        if (code === 200) { result.sent++; return; }
        result.failed++;
        const text = response.getContentText();
        if (code === 404 || /UNREGISTERED|registration-token-not-registered/.test(text) ||
            (code === 400 && /INVALID_ARGUMENT/.test(text) && /token/i.test(text))) invalid.push(batch[index].token);
        if (code === 401) CacheService.getScriptCache().remove('fcm-access-token');
      });
    }
    if (invalid.length) {
      withScriptLock_(function () {
        result.removed = removePushTokensWhere_(function (row) { return invalid.indexOf(String(row[0])) >= 0; });
      });
    }
  } catch (err) {
    try { writeApplicationError_('flushPushQueue_', err, 'sistem'); } catch (ignore) {}
  } finally {
    PUSH_FLUSHING_ = false;
  }
  return result;
}

// ===================================================================
// v12 — PENGUMUMAN PENGURUS
// Disimpan di sheet Pengumuman, dikirim sebagai notifikasi ke semua perangkat,
// dan tampil di Beranda selama 3 hari (untuk warga tanpa APK/notifikasi).
// ===================================================================
const SHEET_PENGUMUMAN = 'Pengumuman';
const PENGUMUMAN_HEADERS = ['ID', 'DikirimPada', 'Judul', 'Isi', 'Oleh', 'Perangkat'];
const PENGUMUMAN_HOME_DAYS = 3;
const PENGUMUMAN_MAX_PER_HOUR = 10;

function getPengumumanSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_PENGUMUMAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PENGUMUMAN);
    sheet.getRange(1, 1, 1, PENGUMUMAN_HEADERS.length).setValues([PENGUMUMAN_HEADERS]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function readPengumuman_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PENGUMUMAN);
  if (!sheet || sheet.getLastRow() < 2) return [];
  return sheet.getRange(2, 1, sheet.getLastRow() - 1, PENGUMUMAN_HEADERS.length).getValues()
    .filter(function (row) { return row[0]; })
    .map(function (row) {
      const sentAt = new Date(row[1]);
      return { id: String(row[0]), dikirimPada: isNaN(sentAt.getTime()) ? '' : sentAt.toISOString(), judul: String(row[2] || ''),
        isi: String(row[3] || ''), oleh: String(row[4] || ''), perangkat: Number(row[5] || 0) };
    })
    .sort(function (a, b) { return String(b.dikirimPada).localeCompare(String(a.dikirimPada)); });
}

function sendPengumuman(payload) {
  const session = requireSession_(payload && payload.sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) return { success: false, message: 'Anda tidak memiliki akses.' };
  try {
    const judul = validateString_(payload.judul, 'Judul pengumuman', 3, 80);
    const isi = validateString_(payload.isi, 'Isi pengumuman', 3, 500);
    return withScriptLock_(function () {
      if (isHourlyLimitReached_('pengumuman', PENGUMUMAN_MAX_PER_HOUR)) {
        return { success: false, message: 'Batas ' + PENGUMUMAN_MAX_PER_HOUR + ' pengumuman per jam tercapai. Coba lagi nanti.' };
      }
      const deviceCount = readPushTokens_().length;
      const id = 'PGM-' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 1000);
      getPengumumanSheet_().appendRow([id, new Date(), sheetText_(judul), sheetText_(isi), sheetText_(session.username), deviceCount]);
      countHourlyEvent_('pengumuman');
      writeAuditLog_('KIRIM_PENGUMUMAN', session.username, id, judul);
      queuePush_({ all: true }, { title: '📢 ' + judul, body: isi, page: 'beranda' });
      return { success: true, id: id, perangkat: deviceCount, pushAktif: !!getFcmConfig_() };
    });
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function getPengumumanTerbaru(sessionToken) {
  requireSession_(sessionToken, ['resident', 'admin', 'super_admin']);
  const latest = readPengumuman_()[0];
  if (!latest || !latest.dikirimPada) return { success: true, pengumuman: null };
  const age = Date.now() - new Date(latest.dikirimPada).getTime();
  return { success: true, pengumuman: age <= PENGUMUMAN_HOME_DAYS * DAY_MS_ ? latest : null };
}

function getPengumumanAdmin(sessionToken) {
  const session = requireSession_(sessionToken, ['admin', 'super_admin']);
  if (!isAdminUsername_(session.username)) return { success: false, message: 'Anda tidak memiliki akses.' };
  return { success: true, daftar: readPengumuman_().slice(0, 20), perangkat: readPushTokens_().length, pushAktif: !!getFcmConfig_() };
}

function formatAgendaDateForPush_(date, startTime) {
  const parsed = date instanceof Date ? date : new Date(String(date || '') + 'T00:00:00+07:00');
  const label = isNaN(parsed.getTime()) ? String(date || '') : Utilities.formatDate(parsed, 'Asia/Jakarta', 'dd/MM/yyyy');
  const time = String(startTime || '').trim();
  return label + (time ? ' pukul ' + time : '');
}
